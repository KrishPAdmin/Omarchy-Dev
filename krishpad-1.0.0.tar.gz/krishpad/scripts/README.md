# scripts/ — Omarchy + Surface + MyDay setup scripts

System scripts for the `krishadmin` Microsoft Surface laptop running **Omarchy**
(Arch + Hyprland). They are meant to run **on the laptop**. They were written on
a separate build VM and could not be executed there, so every script is:

- `#!/usr/bin/env bash` + `set -euo pipefail`
- **idempotent** (safe to re-run; edits are marked/backed up)
- **defensive** (checks before it acts; degrades to guidance instead of guessing)
- **never auto-reboots**, and **asks before any `sudo` package install** (`--yes` to skip prompts)
- has `--help` and clear echoes of what it does

Run `doctor.sh` first to see current state, then use the setup scripts as needed.

> All scripts back up any file they edit to `<file>.bak.<timestamp>` (hypridle
> keeps backups under `~/.config/hypr/.screen-off-never-backups/`).

---

## Index

| Script | What it does | When to run |
|---|---|---|
| `doctor.sh` | **Read-only** green/red table: OS is Arch/Omarchy?, Hyprland running?, hypridle present?, Nerd Font installed?, python3 + MyDay launcher present?, touchscreen detected?, surface kernel running?, DPMS/blank state. Makes no changes. | Any time, first. Non-zero exit only on hard failures. |
| `screen-off-never.sh` | Set display power-off to **NEVER** by commenting out hypridle's DPMS/screen-off listener (`--never`), or put it back (`--restore`), or inspect (`--status`). Optionally stop/mask the hypridle user service. | When you want the screen to stay on (e.g. a wall dashboard). |
| `surface-touch-setup.sh` | Add the `linux-surface` pacman repo + signing key, install the Surface **kernel + headers**, `iptsd`, `libwacom-surface`, firmware, and enable `iptsd`. Detects the Surface model. Prints manual follow-ups. | Once, on a fresh Surface, to get touch/pen/hardware working. |
| `touch-hyprland.sh` | Touch UX for Hyprland: trackpad tap-to-click + natural scroll, an on-screen keyboard (`wvkbd-mobintl`) toggled by **SUPER+K**, and optional `hyprgrass` gestures. Writes `~/.config/hypr/touch.conf`. | After the Surface kernel is running and touch works. |
| `myday-autostart.sh` | Run the MyDay planner always-on: `--dashboard` (full app on login), `--widget` (small floating window), `--waybar` (module steps), `--remove`. Hyprland `exec-once` or `systemd --user`. | To pin MyDay to a workspace / status bar. |

---

## Recommended order on a fresh laptop

1. `./doctor.sh` — baseline.
2. `./surface-touch-setup.sh` — Surface repo/kernel/iptsd. **Then do the printed
   manual follow-ups and REBOOT into the surface kernel** (see below).
3. `./doctor.sh` — confirm `Surface kernel running` = PASS and touchscreen detected.
4. `./touch-hyprland.sh --gestures` — on-screen keyboard + gestures.
5. `./myday-autostart.sh --dashboard --workspace 3` (and/or `--widget`).
6. `./screen-off-never.sh --never` — only if you want the panel to never sleep.

---

## Manual follow-ups you MUST do yourself

### Surface (`surface-touch-setup.sh`) — the important one
The script installs the kernel but **cannot safely finish the boot wiring for
you**. After it runs it prints, and you must do:

1. **Regenerate the initramfs / UKI** for `linux-surface`:
   - **Omarchy = Limine + UKI**: `sudo limine-mkinitcpio` (or `sudo limine-update`).
     The `limine-mkinitcpio-hook` usually adds the menu entry automatically;
     verify with `grep -i surface /boot/limine.conf`.
   - systemd-boot: `sudo mkinitcpio -p linux-surface` then create
     `/boot/loader/entries/linux-surface.conf` (copy `options=` from `linux.conf`).
   - GRUB: `sudo mkinitcpio -p linux-surface && sudo grub-mkconfig -o /boot/grub/grub.cfg`.
2. **(LUKS only)** add Surface modules to `MODULES=()` in `/etc/mkinitcpio.conf`
   (e.g. `surface_aggregator surface_aggregator_registry surface_hid ...`) so the
   type-cover works at the unlock prompt, then rebuild again.
3. **Secure Boot / MOK**: Arch linux-surface kernels are pre-signed for the
   linux-surface key. If Secure Boot is ON with your own keys (`sbctl`), sign the
   new kernel/UKI and enroll the cert **before** rebooting, or it won't boot.
4. **REBOOT** and pick the `linux-surface` entry. Verify: `uname -r` contains
   `surface`; `systemctl | grep iptsd`; `libinput list-devices | grep -i touch`.

> Known Omarchy gotcha: if you ever get a `limine.conf not synced` panic after an
> update, run `sudo cp /boot/limine.conf /boot/EFI/Limine/limine.conf`.

### Touch UX (`touch-hyprland.sh`)
- Config is written to `~/.config/hypr/touch.conf`. Add **one line** to
  `~/.config/hypr/hyprland.conf` (the script offers to do it):
  `source = ~/.config/hypr/touch.conf`
- `hyprgrass` is installed via `hyprpm` and is alpha: the first time you enable
  gestures, **keep a physical keyboard handy** in case touch input misbehaves.
- The on-screen keyboard cannot appear over the **hyprlock** lock screen (upstream
  limitation) — unlock with the hardware/type-cover keyboard.

### MyDay autostart (`myday-autostart.sh`)
- Default is a Hyprland `exec-once` in `~/.config/hypr/myday-autostart.conf`
  (sourced from `hyprland.conf`). Use `--systemd` for a `systemd --user` service
  that restarts on crash and survives Hyprland restarts.
- Waybar: `--waybar` prints the module. It references
  `../omarchy/waybar/myday-module.jsonc` (relative to this folder). If that file
  does not exist yet, create it from the printed snippet; the module runs
  `myday status --json` and shows a MyDay summary in the bar.
- Terminal is auto-detected (ghostty / alacritty / kitty / foot / wezterm). If
  `myday` is not on `PATH`, the scripts fall back to `python -m myday` from the
  repo root (`MYDAY_REPO` overrides the repo path).

### Screen-off (`screen-off-never.sh`)
- `--never` comments out only the DPMS/screen-off listener in
  `hypridle.conf`; idle **lock** and **suspend** still work unless you accept the
  optional prompt to stop+mask the whole hypridle service.
- **Tradeoff**: a screen that never blanks costs battery and risks OLED burn-in.
  Prefer locked-but-off for unattended idle. `--restore` puts it back.

---

## Notes / assumptions to verify on the real laptop

- Config paths assume the standard Omarchy layout (`~/.config/hypr/…`).
- Package names (`linux-surface`, `linux-surface-headers`, `iptsd`,
  `libwacom-surface`, `wvkbd`) are probed before install; anything missing from
  the repos is reported, not force-installed. `wvkbd` may be in the AUR on some
  setups — the script tells you the `yay -S wvkbd` fallback.
- The linux-surface signing key ID is `56C464BAAC421453`; verify the fingerprint
  when prompted.
- These scripts are **not** in GitHub by design (local system scripts).

## Sources

- Omarchy hypridle / DPMS: <https://github.com/basecamp/omarchy/issues/1147>,
  <https://wiki.hypr.land/Hypr-Ecosystem/hypridle/>
- linux-surface install + repo/key: <https://github.com/linux-surface/linux-surface/wiki/Installation-and-Setup>,
  <https://github.com/linux-surface/linux-surface/wiki/Package-Repositories>
- Omarchy Limine + UKI boot stack: <https://deepwiki.com/basecamp/omarchy/2.2-boot-management-and-snapshots>,
  <https://wiki.archlinux.org/title/Limine>
- Hyprland touch input / binds: <https://wiki.hypr.land/Configuring/Basics/Binds/>
- wvkbd + hyprgrass: <https://github.com/horriblename/hyprgrass>,
  <https://github.com/horriblename/hyprgrass/blob/main/docs/configuration.md>
