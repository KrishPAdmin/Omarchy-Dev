#!/usr/bin/env bash
#
# doctor.sh - read-only environment check for the Omarchy/Surface + MyDay setup
# ---------------------------------------------------------------------------
# Prints a green/red table of the things this laptop needs. Makes NO changes.
# Run it any time to see what's healthy and what still needs a setup script.
#
# Checks: Arch/Omarchy?, Hyprland running?, hypridle present?, a Nerd Font
# installed?, python3 + the MyDay launcher present?, a touchscreen device
# detected?, the surface kernel running?, and the current DPMS / screen-blank
# state.
#
# Usage:
#   doctor.sh          Run all checks.
#   doctor.sh --help   This help.
#
set -euo pipefail

REPO_ROOT="${MYDAY_REPO:-$(cd "$(dirname "$0")/.." && pwd)}"

# colors
G="\033[1;32m"; R="\033[1;31m"; Y="\033[1;33m"; C="\033[1;36m"; Z="\033[0m"; B="\033[1m"
have() { command -v "$1" >/dev/null 2>&1; }
usage() { sed -n '2,20p' "$0" | sed 's/^# \{0,1\}//'; }

PASS=0; FAIL=0; WARN=0

# row STATE "label" "detail"
#   STATE: ok | bad | warn
row() {
  local state="$1" label="$2" detail="${3:-}"
  local mark col
  case "$state" in
    ok)   mark="PASS"; col="$G"; PASS=$((PASS+1)) ;;
    bad)  mark="FAIL"; col="$R"; FAIL=$((FAIL+1)) ;;
    warn) mark="WARN"; col="$Y"; WARN=$((WARN+1)) ;;
    *)    mark="????"; col="$Z" ;;
  esac
  printf "  %b%-4s%b  %-26s %s\n" "$col" "$mark" "$Z" "$label" "$detail"
}

hr() { printf '  %s\n' "------------------------------------------------------------"; }

# ----------------------------------------------------------------------------
# Individual checks (all read-only)
# ----------------------------------------------------------------------------
check_os() {
  local pretty=""
  [ -r /etc/os-release ] && pretty="$(. /etc/os-release 2>/dev/null; echo "${PRETTY_NAME:-$NAME}")"
  local is_arch=0
  { [ -f /etc/arch-release ] || have pacman || printf '%s' "$pretty" | grep -qi arch; } && is_arch=1
  local is_omarchy=0
  { printf '%s' "$pretty" | grep -qi omarchy || [ -d /etc/omarchy ] || have omarchy || have omarchy-restart-hypridle || [ -d "$HOME/.local/share/omarchy" ]; } && is_omarchy=1

  if [ "$is_arch" -eq 1 ] && [ "$is_omarchy" -eq 1 ]; then
    row ok  "OS is Arch/Omarchy" "$pretty"
  elif [ "$is_arch" -eq 1 ]; then
    row warn "OS is Arch/Omarchy" "Arch detected, Omarchy markers not found ($pretty)"
  else
    row bad "OS is Arch/Omarchy" "${pretty:-unknown} (not Arch)"
  fi
}

check_hyprland() {
  if [ -n "${HYPRLAND_INSTANCE_SIGNATURE:-}" ] && have hyprctl && hyprctl version >/dev/null 2>&1; then
    local v; v="$(hyprctl version 2>/dev/null | awk 'NR==1{print}' | sed 's/^[[:space:]]*//')"
    row ok "Hyprland running" "${v:-live session}"
  elif have hyprctl; then
    row warn "Hyprland running" "hyprctl present but no live session (\$HYPRLAND_INSTANCE_SIGNATURE unset)"
  else
    row bad "Hyprland running" "hyprctl not found"
  fi
}

check_hypridle() {
  if have hypridle; then
    local running="not running"
    have pgrep && pgrep -x hypridle >/dev/null 2>&1 && running="running"
    row ok "hypridle present" "$running; conf: $( [ -f "$HOME/.config/hypr/hypridle.conf" ] && echo present || echo MISSING )"
  else
    row bad "hypridle present" "hypridle binary not found"
  fi
}

check_nerdfont() {
  if ! have fc-list; then
    row warn "Nerd Font installed" "fontconfig/fc-list not available to check"
    return
  fi
  local hits
  hits="$(fc-list 2>/dev/null | grep -iE 'nerd font|nerd-font|nerdfont' | head -1 || true)"
  if [ -n "$hits" ]; then
    local name; name="$(printf '%s' "$hits" | sed -E 's/^[^:]*:[[:space:]]*//; s/:.*$//')"
    row ok "Nerd Font installed" "${name:-detected}"
  else
    row bad "Nerd Font installed" "no *Nerd Font* family found via fc-list"
  fi
}

check_python_myday() {
  if have python3; then
    row ok "python3 present" "$(python3 --version 2>&1)"
  else
    row bad "python3 present" "python3 not found"
  fi
  # MyDay launcher: `myday` on PATH, or the package importable from the repo.
  if have myday; then
    row ok "MyDay launcher" "'myday' on PATH"
  elif [ -d "$REPO_ROOT/myday" ] && [ -f "$REPO_ROOT/myday/__main__.py" ]; then
    if have python3 && ( cd "$REPO_ROOT" && python3 -c 'import importlib,sys; sys.exit(0 if importlib.util.find_spec("myday") else 1)' ) >/dev/null 2>&1; then
      row ok "MyDay launcher" "python -m myday (repo: $REPO_ROOT)"
    else
      row warn "MyDay launcher" "package at $REPO_ROOT/myday but not importable (deps? venv?)"
    fi
  else
    row bad "MyDay launcher" "no 'myday' on PATH and no package under $REPO_ROOT/myday"
  fi
}

check_touchscreen() {
  local found=""
  if have libinput; then
    # libinput list-devices needs root for full detail but often lists w/o.
    found="$(libinput list-devices 2>/dev/null | awk '
      /^Device:/{dev=$0}
      /Capabilities:.*touch/{print dev}
    ' | head -1 || true)"
  fi
  if [ -z "$found" ] && [ -r /proc/bus/input/devices ]; then
    found="$(awk 'BEGIN{RS=""} /[Tt]ouch/ && /Name=/{
      for(i=1;i<=NF;i++) if($i ~ /Name=/){ }
      print; exit }' /proc/bus/input/devices 2>/dev/null | grep -oiE 'Name="[^"]*touch[^"]*"' | head -1 || true)"
  fi
  # Also glance at sysfs for an IPTS/touchscreen input node name.
  if [ -z "$found" ]; then
    found="$(grep -rilE 'touchscreen|ipts|ithc' /sys/class/input/*/device/name 2>/dev/null | head -1 || true)"
  fi
  if [ -n "$found" ]; then
    row ok "Touchscreen detected" "$(printf '%s' "$found" | sed 's/^Device:[[:space:]]*//' | cut -c1-48)"
  else
    row warn "Touchscreen detected" "none found (may need surface kernel + iptsd, or run as root)"
  fi
}

check_surface_kernel() {
  local kr; kr="$(uname -r)"
  if printf '%s' "$kr" | grep -qi surface; then
    row ok "Surface kernel running" "$kr"
  else
    row warn "Surface kernel running" "$kr (not a linux-surface kernel; run surface-touch-setup.sh)"
  fi
}

check_dpms_state() {
  # Report both the hypridle config intent and the live monitor DPMS status.
  local conf="$HOME/.config/hypr/hypridle.conf" cfg="unknown"
  if [ -f "$conf" ]; then
    if grep -q 'screen-off-never: disabled by script' "$conf"; then
      cfg="screen-off DISABLED (never blanks)"
    elif grep -Eq '^[[:space:]]*on-timeout[[:space:]]*=.*(dpms|monitorpower|dpms\()' "$conf"; then
      cfg="screen-off ACTIVE (blanks on idle)"
    else
      cfg="no dpms listener in config"
    fi
  else
    cfg="no hypridle.conf"
  fi
  local live=""
  if have hyprctl && [ -n "${HYPRLAND_INSTANCE_SIGNATURE:-}" ]; then
    # dpmsStatus true == on
    local off_count
    off_count="$(hyprctl monitors 2>/dev/null | grep -c 'dpmsStatus: false' || true)"
    [ "${off_count:-0}" -gt 0 ] && live=" | live: $off_count monitor(s) currently OFF" || live=" | live: all monitors ON"
  fi
  row ok "DPMS / blank state" "$cfg$live"
}

# ----------------------------------------------------------------------------
# Main
# ----------------------------------------------------------------------------
main() {
  case "${1:-}" in -h|--help) usage; exit 0 ;; "" ) ;; *) printf 'Unknown option: %s\n' "$1" >&2; usage; exit 2 ;; esac

  printf "\n%b%bMyDay / Omarchy / Surface - environment doctor%b\n" "$B" "$C" "$Z"
  printf "  repo: %s\n\n" "$REPO_ROOT"
  hr
  check_os
  check_hyprland
  check_hypridle
  check_nerdfont
  check_python_myday
  check_touchscreen
  check_surface_kernel
  check_dpms_state
  hr
  printf "  %b%d pass%b  %b%d warn%b  %b%d fail%b\n\n" "$G" "$PASS" "$Z" "$Y" "$WARN" "$Z" "$R" "$FAIL" "$Z"

  # Exit non-zero only on hard failures, so this is CI/script friendly but
  # still "read-only".
  [ "$FAIL" -eq 0 ]
}

main "$@"
