#!/usr/bin/env bash
#
# touch-hyprland.sh - basic touch UX for Hyprland on Omarchy
# ---------------------------------------------------------------------------
# Wires up a touch-friendly Hyprland session:
#   * ensures touch input is enabled and the trackpad has tap-to-click +
#     natural scroll,
#   * installs an on-screen keyboard (wvkbd-mobintl preferred) and a
#     SUPER+K keybind that toggles it,
#   * OPTIONALLY installs the hyprgrass touch-gesture plugin (swipe to change
#     workspace, etc.) with sane defaults.
#
# Everything is written to a dedicated include file (~/.config/hypr/touch.conf)
# so your main hyprland.conf stays clean. The script prints the ONE `source=`
# line you add to hyprland.conf (and offers to add it for you). Idempotent.
#
# Sources (see README.md): Hyprland wiki (input/binds/plugins), wvkbd,
# horriblename/hyprgrass.
#
# Usage:
#   touch-hyprland.sh                 Set up touch input + OSK (asks before installs).
#   touch-hyprland.sh --yes           Non-interactive; assume yes to installs.
#   touch-hyprland.sh --gestures      Also install + configure hyprgrass gestures.
#   touch-hyprland.sh --no-osk        Skip the on-screen keyboard.
#   touch-hyprland.sh --status        Show what's installed / configured.
#   touch-hyprland.sh --help          This help.
#
set -euo pipefail

HYPR_DIR="${HYPR_DIR:-$HOME/.config/hypr}"
MAIN_CONF="$HYPR_DIR/hyprland.conf"
TOUCH_CONF="$HYPR_DIR/touch.conf"
SOURCE_LINE="source = ~/.config/hypr/touch.conf"

ASSUME_YES=0
WANT_GESTURES=0
WANT_OSK=1

info() { printf '\033[1;36m::\033[0m %s\n' "$*"; }
ok()   { printf '\033[1;32mok\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m!!\033[0m %s\n' "$*" >&2; }
err()  { printf '\033[1;31mxx\033[0m %s\n' "$*" >&2; }
step() { printf '\n\033[1;35m==>\033[0m \033[1m%s\033[0m\n' "$*"; }
have() { command -v "$1" >/dev/null 2>&1; }
usage() { sed -n '2,26p' "$0" | sed 's/^# \{0,1\}//'; }

SUDO=""
setup_sudo() { [ "$(id -u)" -eq 0 ] && SUDO="" || { have sudo && SUDO="sudo" || SUDO=""; }; }

confirm() { [ "$ASSUME_YES" -eq 1 ] && return 0; local a; read -r -p "$1 [y/N] " a || a=""; case "${a:-}" in [yY]|[yY][eE][sS]) return 0;; *) return 1;; esac; }

# ----------------------------------------------------------------------------
# Package install (Arch). Best-effort; skips if already present.
# ----------------------------------------------------------------------------
ensure_pkg() {
  # ensure_pkg <pkg> [human-name]
  local pkg="$1" name="${2:-$1}"
  if pacman -Qq "$pkg" >/dev/null 2>&1; then ok "$name already installed."; return 0; fi
  if ! have pacman; then warn "pacman not found; install '$pkg' manually."; return 1; fi
  if ! pacman -Ssq "^${pkg}\$" >/dev/null 2>&1; then
    warn "'$pkg' not in official repos. It may be an AUR package."
    warn "Install it with your AUR helper, e.g.: yay -S $pkg"
    return 1
  fi
  if confirm "Install $name ($pkg) with pacman?"; then
    $SUDO pacman -S --needed --noconfirm "$pkg" && ok "Installed $pkg." || { warn "Failed to install $pkg."; return 1; }
  else
    warn "Skipped installing $pkg."
    return 1
  fi
}

# ----------------------------------------------------------------------------
# On-screen keyboard
# ----------------------------------------------------------------------------
OSK_CMD=""       # command to launch the OSK hidden at startup
OSK_TOGGLE=""    # command a keybind runs to toggle it
detect_or_install_osk() {
  step "On-screen keyboard"
  if have wvkbd-mobintl; then
    ok "wvkbd-mobintl present."
  elif have squeekboard; then
    ok "squeekboard present (fallback)."
  else
    info "Preferred OSK is wvkbd-mobintl."
    ensure_pkg wvkbd "wvkbd (on-screen keyboard)" || true
  fi

  if have wvkbd-mobintl; then
    # wvkbd honors real-time signals: SIGUSR1 hide, SIGUSR2 show, SIGRTMIN toggle.
    OSK_CMD='wvkbd-mobintl -L 260 --hidden'
    OSK_TOGGLE='pkill -RTMIN wvkbd-mobintl'
  elif have squeekboard; then
    OSK_CMD='squeekboard'
    # squeekboard toggles via its DBus interface.
    OSK_TOGGLE='busctl --user call sm.puri.OSK0 /sm/puri/OSK0 sm.puri.OSK0 SetVisible b true'
  else
    warn "No on-screen keyboard available; the SUPER+K bind will be a no-op reminder."
    OSK_CMD=''
    OSK_TOGGLE='hyprctl notify 1 3000 0 "Install wvkbd for an on-screen keyboard"'
  fi
}

# ----------------------------------------------------------------------------
# hyprgrass gesture plugin (optional)
# ----------------------------------------------------------------------------
setup_hyprgrass() {
  step "hyprgrass touch gestures (optional)"
  if ! have hyprpm; then
    warn "hyprpm (Hyprland plugin manager) not found; cannot install hyprgrass."
    warn "It ships with Hyprland >= 0.34. Skipping gesture plugin."
    return 0
  fi
  warn "SAFETY: the first time a touch-gesture plugin loads it can, rarely, make"
  warn "the touch device unresponsive until Hyprland restarts. Keep the keyboard"
  warn "handy the first time you enable gestures."
  if ! confirm "Add + enable the hyprgrass plugin via hyprpm now?"; then
    warn "Skipped hyprgrass install. Gesture config will still be written but inert."
    return 0
  fi
  info "hyprpm update (build headers)..."
  hyprpm update || warn "hyprpm update failed; plugin may not build."
  if hyprpm list 2>/dev/null | grep -qi hyprgrass; then
    ok "hyprgrass repo already added."
  else
    hyprpm add https://github.com/horriblename/hyprgrass || warn "hyprpm add failed."
  fi
  hyprpm enable hyprgrass || warn "hyprpm enable hyprgrass failed."
  ok "hyprgrass enabled (a 'exec-once = hyprpm reload -n' line is added to touch.conf)."
}

# ----------------------------------------------------------------------------
# Write the include file
# ----------------------------------------------------------------------------
write_touch_conf() {
  step "Writing $TOUCH_CONF"
  mkdir -p "$HYPR_DIR"
  [ -f "$TOUCH_CONF" ] && cp -a -- "$TOUCH_CONF" "$TOUCH_CONF.bak.$(date +%Y%m%d-%H%M%S)" && info "Backed up existing touch.conf."

  {
    cat <<EOF
# touch.conf - generated by touch-hyprland.sh on $(date -Iseconds)
# Touch UX for Hyprland (Omarchy). Regenerate by re-running touch-hyprland.sh.
# Add this line to ~/.config/hypr/hyprland.conf (the script can do it for you):
#     $SOURCE_LINE

# --- Input: trackpad + touchscreen -----------------------------------------
input {
    # Trackpad: tap-to-click + natural scrolling.
    touchpad {
        natural_scroll = true
        tap-to-click   = true
        disable_while_typing = true
    }
    # Touchscreen: make sure Hyprland processes touch as input.
    touchdevice {
        enabled = true
        # transform = 0   # set 0/1/2/3 if your panel is rotated
    }
}

# Optional: emulate a scroll gesture with a long two-finger touch drag, etc.
# gestures {
#     workspace_swipe = true                # 3-finger touchpad swipe (touchpad)
#     workspace_swipe_fingers = 3
# }
EOF

    if [ -n "$OSK_CMD" ]; then
      cat <<EOF

# --- On-screen keyboard (wvkbd/squeekboard) --------------------------------
# Launch the OSK hidden at login; SUPER+K toggles it.
exec-once = $OSK_CMD
bind = SUPER, K, exec, $OSK_TOGGLE
EOF
    else
      cat <<EOF

# --- On-screen keyboard (none installed) -----------------------------------
# Install wvkbd (wvkbd-mobintl) then re-run touch-hyprland.sh to wire this up.
bind = SUPER, K, exec, $OSK_TOGGLE
EOF
    fi

    if [ "$WANT_GESTURES" -eq 1 ]; then
      cat <<'EOF'

# --- hyprgrass touch gestures ----------------------------------------------
# Load the plugin at startup (safe no-op if hyprgrass is not installed).
exec-once = hyprpm reload -n

# Built-in touch workspace swipe (two/three-finger) made easier to trigger.
gestures {
    workspace_swipe = true
}

plugin {
    touch_gestures {
        # Default sensitivity is low for tablets; 4.0 is a good starting point.
        sensitivity = 4.0
        long_press_delay = 400
        # Distance (px) from a screen edge that counts as an "edge" gesture.
        edge_margin = 32
        # Easier workspace switching with touch swipes.
        workspace_swipe_fingers = 3
        experimental {
            send_cancel = 0
        }
    }
}

# Example gesture binds (uncomment / tweak to taste):
# 3-finger horizontal swipe -> move between workspaces
# bind = , swipe:3:l, workspace, +1
# bind = , swipe:3:r, workspace, -1
# Long-press with 4 fingers -> toggle the on-screen keyboard
# bind = , longpress:4, exec, pkill -RTMIN wvkbd-mobintl
EOF
    fi
  } > "$TOUCH_CONF"

  ok "Wrote $TOUCH_CONF"
}

# ----------------------------------------------------------------------------
# Ensure the source= line is present in hyprland.conf
# ----------------------------------------------------------------------------
wire_source_line() {
  step "Hooking touch.conf into hyprland.conf"
  if [ ! -f "$MAIN_CONF" ]; then
    warn "Main config $MAIN_CONF not found. Add this line to your Hyprland config yourself:"
    printf '    %s\n' "$SOURCE_LINE"
    return 0
  fi
  if grep -qF 'hypr/touch.conf' "$MAIN_CONF"; then
    ok "hyprland.conf already sources touch.conf (skip)."
    return 0
  fi
  info "hyprland.conf does not yet source touch.conf."
  printf '    Add this ONE line to %s:\n\n        %s\n\n' "$MAIN_CONF" "$SOURCE_LINE"
  if confirm "Append that source= line to hyprland.conf now?"; then
    cp -a -- "$MAIN_CONF" "$MAIN_CONF.bak.$(date +%Y%m%d-%H%M%S)"
    printf '\n# Touch UX (added by touch-hyprland.sh)\n%s\n' "$SOURCE_LINE" >> "$MAIN_CONF"
    ok "Added source line + backed up hyprland.conf."
  else
    warn "Not modified. Add the line above manually so touch.conf takes effect."
  fi
}

reload_hypr() {
  if have hyprctl && [ -n "${HYPRLAND_INSTANCE_SIGNATURE:-}" ]; then
    hyprctl reload >/dev/null 2>&1 && ok "Reloaded Hyprland config." || warn "hyprctl reload failed."
  else
    warn "Not in a live Hyprland session; reload with 'hyprctl reload' after logging in."
  fi
}

do_status() {
  step "touch-hyprland status"
  have wvkbd-mobintl && ok "wvkbd-mobintl: installed" || warn "wvkbd-mobintl: not installed"
  have squeekboard && ok "squeekboard: installed" || true
  if have hyprpm && hyprpm list 2>/dev/null | grep -qi hyprgrass; then ok "hyprgrass: added"; else warn "hyprgrass: not added"; fi
  [ -f "$TOUCH_CONF" ] && ok "touch.conf: present ($TOUCH_CONF)" || warn "touch.conf: missing"
  if [ -f "$MAIN_CONF" ] && grep -qF 'hypr/touch.conf' "$MAIN_CONF"; then ok "hyprland.conf sources touch.conf"; else warn "hyprland.conf does NOT source touch.conf"; fi
}

# ----------------------------------------------------------------------------
# Main
# ----------------------------------------------------------------------------
main() {
  local status_only=0
  while [ $# -gt 0 ]; do
    case "$1" in
      --yes|-y)     ASSUME_YES=1 ;;
      --gestures)   WANT_GESTURES=1 ;;
      --no-osk)     WANT_OSK=0 ;;
      --status)     status_only=1 ;;
      -h|--help)    usage; exit 0 ;;
      *) err "Unknown option: $1"; usage; exit 2 ;;
    esac
    shift
  done

  [ "$status_only" -eq 1 ] && { do_status; exit 0; }

  setup_sudo
  if [ "$WANT_OSK" -eq 1 ]; then detect_or_install_osk; else
    step "On-screen keyboard"; warn "--no-osk: skipping OSK."; OSK_CMD=''; OSK_TOGGLE='true'
  fi
  [ "$WANT_GESTURES" -eq 1 ] && setup_hyprgrass
  write_touch_conf
  wire_source_line
  reload_hypr

  step "Summary"
  ok "Touch UX configured in $TOUCH_CONF."
  [ "$WANT_OSK" -eq 1 ] && [ -n "$OSK_CMD" ] && info "Toggle the keyboard with SUPER+K."
  [ "$WANT_GESTURES" -eq 1 ] && info "Gestures via hyprgrass; edit $TOUCH_CONF to bind more."
  info "If touch.conf was not auto-sourced, add: $SOURCE_LINE"
}

main "$@"
