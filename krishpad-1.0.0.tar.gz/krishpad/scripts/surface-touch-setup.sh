#!/usr/bin/env bash
#
# surface-touch-setup.sh - set up Microsoft Surface hardware on Arch/Omarchy
# ---------------------------------------------------------------------------
# Adds the official `linux-surface` pacman repository (with its signing key),
# installs the Surface kernel + headers, the `iptsd` touchscreen daemon,
# `libwacom-surface` (pen/tablet quirks) and Surface firmware, then enables
# `iptsd`. It DETECTS the Surface model, is idempotent (skips finished steps),
# NEVER reboots for you, and prints the MANUAL follow-ups (initramfs rebuild,
# bootloader entry, Secure Boot/MOK, reboot) at the end.
#
# Omarchy's bootloader is Limine with Unified Kernel Images (UKI) built by
# mkinitcpio; installing a second kernel there is handled by
# `limine-mkinitcpio` / `limine-update`, which we call if present. If your box
# instead uses systemd-boot or GRUB, we print the exact manual entry to add.
#
# Sources (see README.md):
#   linux-surface wiki: Installation-and-Setup, Package-Repositories
#   Omarchy Limine/UKI boot stack
#
# Usage:
#   surface-touch-setup.sh            Detect + show a plan, then prompt to run.
#   surface-touch-setup.sh --yes      Assume "yes" to package installs (non-interactive).
#   surface-touch-setup.sh --detect   Only detect the Surface model + state; make no changes.
#   surface-touch-setup.sh --help     This help.
#
# You must run this on the Surface itself, as a user with sudo. It touches:
#   /etc/pacman.conf   (adds a [linux-surface] repo block, backed up first)
#   pacman keyring     (imports + locally signs the linux-surface key)
#   installs packages  (kernel, headers, iptsd, firmware, libwacom-surface)
#   systemd            (enables iptsd.service)
#
set -euo pipefail

# ----------------------------------------------------------------------------
# Constants (from the linux-surface project)
# ----------------------------------------------------------------------------
SURFACE_REPO_URL="https://pkg.surfacelinux.com/arch/"
SURFACE_KEY_URL="https://raw.githubusercontent.com/linux-surface/linux-surface/master/pkg/keys/surface.asc"
SURFACE_KEY_ID="56C464BAAC421453"          # documented linux-surface signing key
PACMAN_CONF="/etc/pacman.conf"
REPO_NAME="linux-surface"

ASSUME_YES=0
DETECT_ONLY=0

info() { printf '\033[1;36m::\033[0m %s\n' "$*"; }
ok()   { printf '\033[1;32mok\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m!!\033[0m %s\n' "$*" >&2; }
err()  { printf '\033[1;31mxx\033[0m %s\n' "$*" >&2; }
step() { printf '\n\033[1;35m==>\033[0m \033[1m%s\033[0m\n' "$*"; }
have() { command -v "$1" >/dev/null 2>&1; }

usage() { sed -n '2,29p' "$0" | sed 's/^# \{0,1\}//'; }

# Wrapper: run a privileged command, honoring detect-only.
SUDO=""
setup_sudo() {
  if [ "$(id -u)" -eq 0 ]; then SUDO=""; else
    have sudo || { err "sudo not found and not running as root."; exit 1; }
    SUDO="sudo"
  fi
}

confirm() {
  # confirm "prompt" -> 0 if yes
  [ "$ASSUME_YES" -eq 1 ] && return 0
  local ans
  read -r -p "$1 [y/N] " ans || ans=""
  case "${ans:-}" in [yY]|[yY][eE][sS]) return 0 ;; *) return 1 ;; esac
}

# ----------------------------------------------------------------------------
# Preconditions
# ----------------------------------------------------------------------------
check_arch() {
  if ! have pacman; then
    err "pacman not found. This script only supports Arch-based systems (Omarchy)."
    exit 1
  fi
}

# ----------------------------------------------------------------------------
# Detection
# ----------------------------------------------------------------------------
DMI_VENDOR=""; DMI_PRODUCT=""; DMI_FAMILY=""
detect_surface() {
  # Prefer sysfs (no root needed); fall back to dmidecode.
  local base="/sys/class/dmi/id"
  if [ -r "$base/sys_vendor" ]; then
    DMI_VENDOR="$(cat "$base/sys_vendor" 2>/dev/null || true)"
    DMI_PRODUCT="$(cat "$base/product_name" 2>/dev/null || true)"
    DMI_FAMILY="$(cat "$base/product_family" 2>/dev/null || true)"
  elif have dmidecode; then
    DMI_VENDOR="$($SUDO dmidecode -s system-manufacturer 2>/dev/null || true)"
    DMI_PRODUCT="$($SUDO dmidecode -s system-product-name 2>/dev/null || true)"
    DMI_FAMILY="$($SUDO dmidecode -s system-family 2>/dev/null || true)"
  fi
  info "Detected system:"
  printf '    vendor:  %s\n' "${DMI_VENDOR:-unknown}"
  printf '    product: %s\n' "${DMI_PRODUCT:-unknown}"
  printf '    family:  %s\n' "${DMI_FAMILY:-unknown}"

  if printf '%s %s %s' "$DMI_VENDOR" "$DMI_PRODUCT" "$DMI_FAMILY" | grep -qi 'surface'; then
    ok "This looks like a Microsoft Surface device."
    return 0
  fi
  if printf '%s' "$DMI_VENDOR" | grep -qi 'microsoft'; then
    warn "Vendor is Microsoft but 'Surface' not in the model string. Proceeding cautiously."
    return 0
  fi
  warn "This does NOT look like a Surface (no 'Surface' in DMI)."
  warn "The linux-surface kernel is only useful on Surface hardware."
  return 1
}

running_surface_kernel() { uname -r | grep -qi 'surface'; }

# ----------------------------------------------------------------------------
# Step 1: signing key
# ----------------------------------------------------------------------------
setup_key() {
  step "Step 1/5: linux-surface signing key"
  if $SUDO pacman-key --list-keys "$SURFACE_KEY_ID" >/dev/null 2>&1; then
    ok "Signing key $SURFACE_KEY_ID already in the pacman keyring (skip)."
    return 0
  fi
  have curl || { err "curl is required to fetch the signing key."; exit 1; }
  info "Importing linux-surface key from $SURFACE_KEY_URL"
  # Pipe the ASCII key straight into pacman-key --add.
  curl -fsSL "$SURFACE_KEY_URL" | $SUDO pacman-key --add - \
    || { err "Failed to import signing key."; exit 1; }
  info "Fingerprint (verify against linux-surface docs):"
  $SUDO pacman-key --finger "$SURFACE_KEY_ID" 2>/dev/null || true
  info "Locally signing the key so pacman trusts the repo..."
  $SUDO pacman-key --lsign-key "$SURFACE_KEY_ID" \
    || { err "Failed to locally sign key."; exit 1; }
  ok "Signing key imported and locally signed."
}

# ----------------------------------------------------------------------------
# Step 2: repository in pacman.conf
# ----------------------------------------------------------------------------
setup_repo() {
  step "Step 2/5: [linux-surface] pacman repository"
  if grep -qE "^\[$REPO_NAME\]" "$PACMAN_CONF"; then
    ok "[$REPO_NAME] already present in $PACMAN_CONF (skip)."
    return 0
  fi
  info "Backing up $PACMAN_CONF -> $PACMAN_CONF.bak.$(date +%Y%m%d-%H%M%S)"
  $SUDO cp -a -- "$PACMAN_CONF" "$PACMAN_CONF.bak.$(date +%Y%m%d-%H%M%S)"
  info "Appending [$REPO_NAME] repo block..."
  # Append via a here-doc through tee (needs privilege to write /etc).
  printf '\n[%s]\nServer = %s\n' "$REPO_NAME" "$SURFACE_REPO_URL" | $SUDO tee -a "$PACMAN_CONF" >/dev/null
  ok "Added [$REPO_NAME] -> $SURFACE_REPO_URL"
}

# ----------------------------------------------------------------------------
# Step 3: install packages
# ----------------------------------------------------------------------------
pkg_installed() { pacman -Qq "$1" >/dev/null 2>&1; }

setup_packages() {
  step "Step 3/5: install Surface kernel, headers, iptsd, firmware"
  info "Refreshing package databases (pacman -Sy)..."
  $SUDO pacman -Sy --noconfirm >/dev/null 2>&1 || { err "pacman -Sy failed (network / repo?)."; exit 1; }

  # Core set. libwacom-surface is optional (pen quirks); firmware pkg name
  # can vary, so we probe. We install what exists and skip the rest.
  local core=(linux-surface linux-surface-headers iptsd)
  local optional=(libwacom-surface linux-firmware)

  # Some Surface builds ship a specifically-named firmware package; add it if
  # the repo advertises it. This is best-effort.
  if pacman -Ssq '^linux-surface-firmware$' >/dev/null 2>&1; then
    optional+=(linux-surface-firmware)
  fi

  local to_install=()
  local p
  for p in "${core[@]}" "${optional[@]}"; do
    if pkg_installed "$p"; then
      ok "$p already installed (skip)."
    elif pacman -Ssq "^${p}\$" >/dev/null 2>&1; then
      to_install+=("$p")
    else
      warn "Package '$p' not found in any repo; skipping."
    fi
  done

  if [ "${#to_install[@]}" -eq 0 ]; then
    ok "Nothing to install; all target packages already present."
    return 0
  fi

  info "Will install: ${to_install[*]}"
  if ! confirm "Proceed with 'pacman -S ${to_install[*]}'?"; then
    warn "Skipped package installation at user request."
    return 0
  fi
  $SUDO pacman -S --needed --noconfirm "${to_install[@]}" \
    || { err "Package installation failed."; exit 1; }
  ok "Installed: ${to_install[*]}"
}

# ----------------------------------------------------------------------------
# Step 4: enable iptsd (touchscreen daemon)
# ----------------------------------------------------------------------------
setup_iptsd() {
  step "Step 4/5: enable iptsd (touchscreen daemon)"
  if ! have systemctl; then warn "systemctl not found; enable iptsd manually."; return 0; fi
  # iptsd historically shipped a system service; newer builds use a
  # udev-launched user unit (iptsd@.service). Handle both, non-fatally.
  if systemctl list-unit-files 2>/dev/null | grep -q '^iptsd\.service'; then
    if systemctl is-enabled iptsd.service >/dev/null 2>&1; then
      ok "iptsd.service already enabled (skip)."
    else
      $SUDO systemctl enable --now iptsd.service >/dev/null 2>&1 \
        && ok "Enabled and started iptsd.service." \
        || warn "Could not enable iptsd.service; check 'systemctl status iptsd'."
    fi
  else
    warn "No plain iptsd.service found. On recent iptsd, touch devices are"
    warn "auto-started via a udev rule (iptsd@<device>). No manual enable needed;"
    warn "verify after reboot with: systemctl | grep iptsd"
  fi
}

# ----------------------------------------------------------------------------
# Step 5: bootloader / initramfs guidance (manual follow-ups)
# ----------------------------------------------------------------------------
detect_bootloader() {
  # Return: limine | systemd-boot | grub | unknown
  if [ -d /boot/EFI/Limine ] || [ -f /boot/limine.conf ] || have limine-update || have limine-mkinitcpio; then
    echo limine
  elif have bootctl && bootctl status >/dev/null 2>&1 && [ -d /boot/loader/entries ]; then
    echo systemd-boot
  elif [ -f /boot/grub/grub.cfg ] || have grub-mkconfig; then
    echo grub
  else
    echo unknown
  fi
}

print_followups() {
  step "Step 5/5: MANUAL follow-ups (this script will NOT do these for you)"
  local bl; bl="$(detect_bootloader)"
  info "Detected bootloader: $bl"
  cat <<'EOF'

  1) REGENERATE INITRAMFS / UKI for the new kernel:
EOF
  case "$bl" in
    limine)
      cat <<'EOF'
     Omarchy uses Limine + Unified Kernel Images (UKI). Rebuild with the
     Limine wrappers so a boot entry is generated for linux-surface:

         sudo limine-mkinitcpio        # (preferred on mkinitcpio systems)
         # or, if that command is absent:
         sudo limine-update

     The limine-mkinitcpio-hook normally auto-adds a menu entry when the
     linux-surface package is installed. Verify the entry exists:

         grep -i surface /boot/limine.conf 2>/dev/null || \
             sudo cat /boot/limine.conf | grep -i surface

     If you ever see a "config not synced" panic, sync the ESP copy:
         sudo cp /boot/limine.conf /boot/EFI/Limine/limine.conf
EOF
      ;;
    systemd-boot)
      cat <<'EOF'
     Rebuild the initramfs, then ADD a boot entry (systemd-boot does NOT
     auto-detect new kernels):

         sudo mkinitcpio -p linux-surface
         sudoedit /boot/loader/entries/linux-surface.conf

     Put this in linux-surface.conf (copy options= from your existing
     linux.conf, e.g. root=..., rw, etc.):

         title    Arch Linux (linux-surface)
         linux    /vmlinuz-linux-surface
         initrd   /initramfs-linux-surface.img
         options  <copy from your existing linux.conf>
EOF
      ;;
    grub)
      cat <<'EOF'
     Rebuild the initramfs, then regenerate the GRUB menu:

         sudo mkinitcpio -p linux-surface
         sudo grub-mkconfig -o /boot/grub/grub.cfg
EOF
      ;;
    *)
      cat <<'EOF'
     Could not identify the bootloader. Rebuild the initramfs for the new
     kernel (sudo mkinitcpio -p linux-surface) and add/select a boot entry
     for vmlinuz-linux-surface + initramfs-linux-surface.img in whatever
     bootloader you use.
EOF
      ;;
  esac

  cat <<'EOF'

  2) (Surface + LUKS only) Add Surface modules so the type-cover keyboard
     works early enough to unlock disks. Edit MODULES=() in
     /etc/mkinitcpio.conf per the linux-surface "Disk Encryption" wiki, e.g.:
         MODULES=(pinctrl_tigerlake surface_aggregator surface_aggregator_registry \
                  surface_hid_core surface_hid 8250_dw)
     then rebuild the initramfs again (see step 1).

  3) SECURE BOOT / MOK:
     The Arch linux-surface kernels are pre-signed for the linux-surface key.
     * If Secure Boot is OFF, nothing to do.
     * If Secure Boot is ON and you use your OWN keys (sbctl), you must sign
       the new kernel/UKI: `sudo sbctl sign -s <path-to-vmlinuz-or-UKI>` and
       ensure the linux-surface signing cert is enrolled, or the machine
       will refuse to boot it.
     * Enroll the linux-surface key / your MOK BEFORE rebooting.

  4) REBOOT and pick the linux-surface entry in the boot menu.
     THIS SCRIPT WILL NOT REBOOT FOR YOU. Verify afterward with:
         uname -r        # must contain "surface"
         systemctl --no-pager status iptsd    # or: systemctl | grep iptsd
         libinput list-devices | grep -i touch
EOF
  if running_surface_kernel; then
    ok "You are ALREADY running a surface kernel ($(uname -r)). Good."
  else
    warn "You are currently on kernel $(uname -r) (not surface). Reboot to switch."
  fi
}

# ----------------------------------------------------------------------------
# Main
# ----------------------------------------------------------------------------
main() {
  while [ $# -gt 0 ]; do
    case "$1" in
      --yes|-y)   ASSUME_YES=1 ;;
      --detect)   DETECT_ONLY=1 ;;
      -h|--help)  usage; exit 0 ;;
      *) err "Unknown option: $1"; usage; exit 2 ;;
    esac
    shift
  done

  check_arch
  setup_sudo

  step "Detecting hardware"
  if ! detect_surface; then
    if [ "$DETECT_ONLY" -eq 1 ]; then exit 0; fi
    if ! confirm "Hardware does not look like a Surface. Continue anyway?"; then
      warn "Aborting at user request."
      exit 0
    fi
  fi

  if [ "$DETECT_ONLY" -eq 1 ]; then
    info "Current kernel: $(uname -r)"
    info "Bootloader:     $(detect_bootloader)"
    running_surface_kernel && ok "Surface kernel is active." || warn "Surface kernel NOT active."
    exit 0
  fi

  setup_key
  setup_repo
  setup_packages
  setup_iptsd
  print_followups

  step "Summary"
  ok "linux-surface setup steps complete."
  warn "Do the MANUAL follow-ups above (initramfs/bootloader/Secure Boot), then REBOOT."
}

main "$@"
