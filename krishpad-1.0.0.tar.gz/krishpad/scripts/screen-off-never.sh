#!/usr/bin/env bash
#
# screen-off-never.sh - control display power-off / DPMS blanking on Omarchy
# ---------------------------------------------------------------------------
# Omarchy (Arch + Hyprland) idles and locks the screen with `hypridle`
# (config: ~/.config/hypr/hypridle.conf) + `hyprlock`. A `listener {}` block in
# that file runs `hyprctl dispatch dpms off` on a timeout, which powers the
# panel off. This script lets you set that power-off to NEVER, restore it, or
# just inspect the current state.
#
# It edits ONLY hypridle's DPMS/screen listeners; it does NOT touch the lock
# (`loginctl lock-session`) or suspend listeners, so security-relevant locking
# still happens. Every edit is backed up first and the operation is idempotent.
#
# TRADEOFF (why "never" is opt-in):
#   * Battery: a panel that never sleeps drains the battery noticeably faster.
#   * Burn-in: OLED/AMOLED panels (some Surface models) can retain a static
#     image if left on for very long periods. Prefer a locked-but-off screen
#     for unattended idle unless you specifically need the display to stay lit.
#   There is also a known Omarchy/hyprlock crash when DPMS toggles under a lock
#   screen; disabling the DPMS listener sidesteps that too.
#
# Usage:
#   screen-off-never.sh --never     Disable hypridle screen-off/DPMS listeners
#                                    (comment them out) and force the display on
#                                    now. Optionally stop/mask hypridle entirely.
#   screen-off-never.sh --restore   Restore the most recent backup and restart
#                                    hypridle (and unmask it if masked).
#   screen-off-never.sh --status    Show current DPMS/listener/service state.
#   screen-off-never.sh --help      This help.
#
set -euo pipefail

# ----------------------------------------------------------------------------
# Config / constants
# ----------------------------------------------------------------------------
CONF="${HYPRIDLE_CONF:-$HOME/.config/hypr/hypridle.conf}"
BACKUP_DIR="${HOME}/.config/hypr/.screen-off-never-backups"
TS="$(date +%Y%m%d-%H%M%S)"
SENTINEL="# screen-off-never: disabled by script"

log()  { printf '  %s\n' "$*"; }
info() { printf '\033[1;36m::\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m!!\033[0m %s\n' "$*" >&2; }
err()  { printf '\033[1;31mxx\033[0m %s\n' "$*" >&2; }

usage() { sed -n '2,44p' "$0" | sed 's/^# \{0,1\}//'; }

have() { command -v "$1" >/dev/null 2>&1; }

# Are we actually in a Hyprland session we can talk to?
hyprctl_ok() {
  have hyprctl && [ -n "${HYPRLAND_INSTANCE_SIGNATURE:-}" ]
}

# ----------------------------------------------------------------------------
# hyprctl helpers (best-effort; never fatal)
# ----------------------------------------------------------------------------
force_display_on() {
  if hyprctl_ok; then
    if hyprctl dispatch dpms on >/dev/null 2>&1; then
      log "Forced all displays ON via 'hyprctl dispatch dpms on'."
    else
      warn "hyprctl dispatch dpms on failed (continuing)."
    fi
  else
    warn "Not inside a live Hyprland session (HYPRLAND_INSTANCE_SIGNATURE unset)."
    warn "Skipping live 'hyprctl dispatch dpms on'; config edits still applied."
  fi
}

restart_hypridle() {
  # Omarchy ships a helper; prefer it, then fall back to systemd --user.
  if have omarchy-restart-hypridle; then
    omarchy-restart-hypridle >/dev/null 2>&1 && { log "Ran omarchy-restart-hypridle."; return 0; }
  fi
  if have systemctl && systemctl --user list-unit-files 2>/dev/null | grep -q '^hypridle\.service'; then
    systemctl --user restart hypridle.service >/dev/null 2>&1 && { log "Restarted hypridle.service (user)."; return 0; }
  fi
  # Last resort: kick the process directly.
  if have hypridle; then
    pkill -x hypridle >/dev/null 2>&1 || true
    sleep 1
    ( setsid hypridle >/dev/null 2>&1 & ) || true
    log "Restarted hypridle process directly."
    return 0
  fi
  warn "Could not restart hypridle automatically. Restart it manually."
}

# ----------------------------------------------------------------------------
# Backup
# ----------------------------------------------------------------------------
make_backup() {
  mkdir -p "$BACKUP_DIR"
  local dest="$BACKUP_DIR/hypridle.conf.$TS.bak"
  cp -a -- "$CONF" "$dest"
  log "Backed up $CONF -> $dest"
  printf '%s' "$dest"
}

latest_backup() {
  ls -1t "$BACKUP_DIR"/hypridle.conf.*.bak 2>/dev/null | head -n1 || true
}

# ----------------------------------------------------------------------------
# Core edit: comment out any listener block whose on-timeout mentions dpms/
# screen power. Uses awk to find `listener {` ... `}` blocks and, if the block
# contains a dpms/monitor-power directive, prefix every line with `#`.
# Idempotent: lines already carrying our sentinel are left alone.
# ----------------------------------------------------------------------------
disable_dpms_listeners() {
  local out
  out="$(mktemp)"
  awk -v S="$SENTINEL" '
    BEGIN { inblk=0; n=0 }
    # Buffer a listener block, then decide whether to comment it.
    /^[[:space:]]*listener[[:space:]]*\{/ && inblk==0 {
      inblk=1; n=0; buf[n++]=$0; hasdpms=0; already=0; next
    }
    inblk==1 {
      buf[n++]=$0
      if ($0 ~ /dpms|monitorpower|monitor[[:space:]]*power|hl\.dsp\.dpms|dpms\(/) hasdpms=1
      if ($0 ~ S) already=1
      if ($0 ~ /^[[:space:]]*\}/) {
        # end of block: flush
        if (hasdpms && !already) {
          print S
          for (i=0;i<n;i++) {
            line=buf[i]
            # comment the line if not already commented
            if (line ~ /^[[:space:]]*#/) print line
            else {
              # preserve leading indentation before the #
              match(line, /^[[:space:]]*/)
              indent=substr(line,1,RLENGTH)
              rest=substr(line,RLENGTH+1)
              print indent "# " rest
            }
          }
        } else {
          for (i=0;i<n;i++) print buf[i]
        }
        inblk=0; n=0
      }
      next
    }
    { print }
  ' "$CONF" > "$out"

  if cmp -s "$CONF" "$out"; then
    log "No active DPMS/screen-off listener found to change (already disabled?)."
    rm -f "$out"
    return 1
  fi
  cat "$out" > "$CONF"
  rm -f "$out"
  log "Commented out DPMS/screen-off listener block(s) in $CONF."
  return 0
}

# ----------------------------------------------------------------------------
# Actions
# ----------------------------------------------------------------------------
do_never() {
  [ -f "$CONF" ] || { err "hypridle config not found: $CONF"; err "Is this an Omarchy/Hyprland machine?"; exit 1; }
  info "Setting screen power-off to NEVER."
  make_backup >/dev/null
  if disable_dpms_listeners; then
    info "hypridle config updated."
  else
    info "hypridle config already had no active screen-off listener."
  fi
  force_display_on
  restart_hypridle

  # Offer to fully stop+mask hypridle (also stops the lock-on-idle behaviour).
  if have systemctl && systemctl --user list-unit-files 2>/dev/null | grep -q '^hypridle\.service'; then
    printf '\n'
    warn "Optional: fully STOP + MASK the hypridle user service."
    warn "This also disables idle-LOCK and idle-SUSPEND, not just screen-off."
    read -r -p "Stop and mask hypridle.service now? [y/N] " ans || ans=""
    case "${ans:-}" in
      [yY]|[yY][eE][sS])
        systemctl --user stop hypridle.service >/dev/null 2>&1 || true
        systemctl --user mask hypridle.service >/dev/null 2>&1 || true
        log "hypridle.service stopped and masked. (Undo with --restore.)"
        ;;
      *) log "Left hypridle service running (only the screen-off listener is disabled)." ;;
    esac
  fi
  info "Done. Your screen should no longer power off on idle."
}

do_restore() {
  local bk
  bk="$(latest_backup)"
  # Unmask hypridle if we masked it.
  if have systemctl && systemctl --user list-unit-files 2>/dev/null | grep -q '^hypridle\.service'; then
    if systemctl --user is-enabled hypridle.service 2>/dev/null | grep -q masked; then
      systemctl --user unmask hypridle.service >/dev/null 2>&1 || true
      log "Unmasked hypridle.service."
    fi
  fi
  if [ -z "$bk" ]; then
    warn "No backup found in $BACKUP_DIR."
    warn "Nothing to restore. If you disabled listeners manually, re-enable them by hand."
    restart_hypridle
    exit 0
  fi
  info "Restoring hypridle config from backup: $bk"
  # Keep a safety copy of the current (disabled) file before overwriting.
  [ -f "$CONF" ] && cp -a -- "$CONF" "$BACKUP_DIR/hypridle.conf.pre-restore.$TS.bak"
  cp -a -- "$bk" "$CONF"
  log "Restored $CONF"
  restart_hypridle
  info "Done. hypridle's original screen-off behaviour is back."
}

do_status() {
  info "screen-off-never status"
  printf '\n'
  # Config
  if [ -f "$CONF" ]; then
    log "config: $CONF"
    if grep -q "$SENTINEL" "$CONF"; then
      printf '    state:   \033[1;33mDISABLED by this script\033[0m (screen-off listener commented out)\n'
    elif grep -Eq '^[[:space:]]*on-timeout[[:space:]]*=.*(dpms|monitorpower|dpms\()' "$CONF"; then
      printf '    state:   \033[1;32mACTIVE\033[0m (a live DPMS/screen-off listener is present)\n'
    else
      printf '    state:   no DPMS/screen-off listener detected in config\n'
    fi
  else
    warn "config not found: $CONF"
  fi
  printf '\n'
  # Backups
  local bk; bk="$(latest_backup)"
  [ -n "$bk" ] && log "latest backup: $bk" || log "latest backup: (none)"
  printf '\n'
  # Service
  if have systemctl && systemctl --user list-unit-files 2>/dev/null | grep -q '^hypridle\.service'; then
    log "hypridle.service (user): $(systemctl --user is-active hypridle.service 2>/dev/null || echo unknown) / enable=$(systemctl --user is-enabled hypridle.service 2>/dev/null || echo unknown)"
  else
    have pgrep && { pgrep -x hypridle >/dev/null 2>&1 && log "hypridle: running (no user unit)" || log "hypridle: not running / not installed"; }
  fi
  # Live monitor DPMS state
  if hyprctl_ok; then
    printf '\n'
    log "live monitors (hyprctl monitors -> dpmsStatus):"
    hyprctl monitors 2>/dev/null | awk '/^Monitor/{m=$2} /dpmsStatus/{printf "      %s: %s\n", m, $0}' || true
  fi
}

# ----------------------------------------------------------------------------
# Arg parsing
# ----------------------------------------------------------------------------
main() {
  local action=""
  [ $# -eq 0 ] && { usage; exit 0; }
  while [ $# -gt 0 ]; do
    case "$1" in
      --never)   action="never" ;;
      --restore) action="restore" ;;
      --status)  action="status" ;;
      -h|--help) usage; exit 0 ;;
      *) err "Unknown option: $1"; usage; exit 2 ;;
    esac
    shift
  done
  case "$action" in
    never)   do_never ;;
    restore) do_restore ;;
    status)  do_status ;;
    *) usage; exit 0 ;;
  esac
}

main "$@"
