#!/usr/bin/env bash
#
# myday-autostart.sh - run the MyDay planner always-on
# ---------------------------------------------------------------------------
# Wires the MyDay terminal planner to launch automatically:
#   --dashboard   full app in a terminal on login, on a chosen workspace
#                 (Hyprland exec-once OR a systemd --user service)
#   --widget      compact `myday widget` in a small floating/scratchpad window
#   --waybar      print the steps to add the `myday status --json` waybar module
#   --remove      undo the dashboard + widget autostart entries this script added
#
# It auto-detects your terminal (ghostty / alacritty / kitty / foot / wezterm)
# and the MyDay launcher (`myday` on PATH, else `python -m myday` from the repo).
# All edited configs are backed up. Idempotent (marked blocks, re-run safe).
#
# Usage:
#   myday-autostart.sh --dashboard [--systemd] [--workspace N]
#   myday-autostart.sh --widget    [--workspace N]
#   myday-autostart.sh --waybar
#   myday-autostart.sh --remove
#   myday-autostart.sh --status
#   myday-autostart.sh --help
#
# Notes:
#   * Default mechanism is a Hyprland exec-once (simplest on Omarchy). Pass
#     --systemd to install a `systemd --user` service instead (survives Hypr
#     restarts, auto-restarts on crash).
#   * NEVER reboots or logs you out. Changes take effect next login or after
#     `hyprctl reload` / `systemctl --user start`.
#
set -euo pipefail

HYPR_DIR="${HYPR_DIR:-$HOME/.config/hypr}"
MAIN_CONF="$HYPR_DIR/hyprland.conf"
AUTO_CONF="$HYPR_DIR/myday-autostart.conf"          # our own include file
SRC_LINE="source = ~/.config/hypr/myday-autostart.conf"
USER_UNIT_DIR="${XDG_CONFIG_HOME:-$HOME/.config}/systemd/user"
REPO_ROOT="${MYDAY_REPO:-$(cd "$(dirname "$0")/.." && pwd)}"   # scripts/.. == repo root
WORKSPACE=""
USE_SYSTEMD=0
WAYBAR_MODULE_REF="../omarchy/waybar/myday-module.jsonc"

info() { printf '\033[1;36m::\033[0m %s\n' "$*"; }
ok()   { printf '\033[1;32mok\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m!!\033[0m %s\n' "$*" >&2; }
err()  { printf '\033[1;31mxx\033[0m %s\n' "$*" >&2; }
step() { printf '\n\033[1;35m==>\033[0m \033[1m%s\033[0m\n' "$*"; }
have() { command -v "$1" >/dev/null 2>&1; }
usage() { sed -n '2,34p' "$0" | sed 's/^# \{0,1\}//'; }

# ----------------------------------------------------------------------------
# Detect the MyDay launcher.
#   Prefer a `myday` on PATH. Otherwise use `python -m myday`, cd-ing into the
#   repo so the package imports. We emit an absolute, login-safe command.
# ----------------------------------------------------------------------------
MYDAY_BASE=""     # base command that runs the app (no subcommand)
detect_myday() {
  if have myday; then
    MYDAY_BASE="myday"
    ok "MyDay launcher: 'myday' (on PATH)."
    return 0
  fi
  # find a python
  local py=""
  for cand in python3 python; do have "$cand" && { py="$cand"; break; }; done
  [ -n "$py" ] || { err "No python found and no 'myday' on PATH."; exit 1; }
  if [ -d "$REPO_ROOT/myday" ]; then
    # Use a subshell cd so it works regardless of login CWD.
    MYDAY_BASE="bash -lc 'cd \"$REPO_ROOT\" && exec $py -m myday'"
    ok "MyDay launcher: '$py -m myday' from $REPO_ROOT"
  else
    err "Could not find the myday package under $REPO_ROOT/myday and no 'myday' on PATH."
    err "Set MYDAY_REPO=/path/to/repo and re-run."
    exit 1
  fi
}

# The full command MyDay should run for a given subcommand ("" = full app).
myday_cmd() {
  local sub="${1:-}"
  if [ "$MYDAY_BASE" = "myday" ]; then
    [ -n "$sub" ] && printf 'myday %s' "$sub" || printf 'myday'
  else
    # MYDAY_BASE is 'bash -lc ...exec python -m myday'; inject the subcommand.
    if [ -n "$sub" ]; then
      printf "bash -lc 'cd \"%s\" && exec %s -m myday %s'" "$REPO_ROOT" "$(pymarker)" "$sub"
    else
      printf '%s' "$MYDAY_BASE"
    fi
  fi
}
pymarker() { have python3 && echo python3 || echo python; }

# ----------------------------------------------------------------------------
# Detect a terminal emulator + how it runs a command / sets an app-id (class).
# Sets: TERM_BIN, and helpers term_exec / term_class_flag.
# ----------------------------------------------------------------------------
TERM_BIN=""
detect_terminal() {
  local cands=(ghostty alacritty kitty foot wezterm)
  # honor an explicit $TERMINAL if it points at something runnable
  if [ -n "${TERMINAL:-}" ] && have "${TERMINAL%% *}"; then TERM_BIN="${TERMINAL%% *}"; fi
  if [ -z "$TERM_BIN" ]; then
    for t in "${cands[@]}"; do have "$t" && { TERM_BIN="$t"; break; }; done
  fi
  [ -n "$TERM_BIN" ] || { warn "No known terminal found (ghostty/alacritty/kitty/foot/wezterm)."; return 1; }
  ok "Terminal: $TERM_BIN"
}

# Build a full terminal command that (a) sets a window class/app-id we can match
# in Hyprland rules and (b) runs the given shell command.
# $1 = app-id/class, $2 = command string
term_exec() {
  local cls="$1" cmd="$2"
  case "$TERM_BIN" in
    ghostty)   printf "ghostty --class=%s -e %s" "$cls" "$cmd" ;;
    alacritty) printf "alacritty --class %s -e %s" "$cls" "$cmd" ;;
    kitty)     printf "kitty --class %s %s" "$cls" "$cmd" ;;
    foot)      printf "foot --app-id=%s %s" "$cls" "$cmd" ;;
    wezterm)   printf "wezterm start --class %s -- %s" "$cls" "$cmd" ;;
    *)         printf "%s -e %s" "$TERM_BIN" "$cmd" ;;
  esac
}

# ----------------------------------------------------------------------------
# Include-file plumbing
# ----------------------------------------------------------------------------
ensure_include_sourced() {
  mkdir -p "$HYPR_DIR"
  [ -f "$AUTO_CONF" ] || : > "$AUTO_CONF"
  if [ -f "$MAIN_CONF" ]; then
    if ! grep -qF 'hypr/myday-autostart.conf' "$MAIN_CONF"; then
      cp -a -- "$MAIN_CONF" "$MAIN_CONF.bak.$(date +%Y%m%d-%H%M%S)"
      printf '\n# MyDay autostart (added by myday-autostart.sh)\n%s\n' "$SRC_LINE" >> "$MAIN_CONF"
      ok "Added source line to hyprland.conf (backed up)."
    else
      ok "hyprland.conf already sources myday-autostart.conf."
    fi
  else
    warn "hyprland.conf not found; add this line to your Hyprland config: $SRC_LINE"
  fi
}

# Replace a marked block in AUTO_CONF (idempotent). $1=tag, $2=content
put_block() {
  local tag="$1" content="$2"
  local begin="# >>> myday:$tag >>>" end="# <<< myday:$tag <<<"
  mkdir -p "$HYPR_DIR"
  [ -f "$AUTO_CONF" ] && cp -a -- "$AUTO_CONF" "$AUTO_CONF.bak.$(date +%Y%m%d-%H%M%S)"
  local tmp; tmp="$(mktemp)"
  # strip any existing block with this tag
  if [ -f "$AUTO_CONF" ]; then
    awk -v b="$begin" -v e="$end" '
      $0==b {skip=1} !skip {print} $0==e {skip=0}
    ' "$AUTO_CONF" > "$tmp"
  fi
  {
    printf '%s\n' "$begin"
    printf '%s\n' "$content"
    printf '%s\n' "$end"
  } >> "$tmp"
  mv -- "$tmp" "$AUTO_CONF"
}

remove_block() {
  local tag="$1"
  local begin="# >>> myday:$tag >>>" end="# <<< myday:$tag <<<"
  [ -f "$AUTO_CONF" ] || return 0
  cp -a -- "$AUTO_CONF" "$AUTO_CONF.bak.$(date +%Y%m%d-%H%M%S)"
  local tmp; tmp="$(mktemp)"
  awk -v b="$begin" -v e="$end" '$0==b {skip=1} !skip {print} $0==e {skip=0}' "$AUTO_CONF" > "$tmp"
  mv -- "$tmp" "$AUTO_CONF"
}

reload_hypr() {
  if have hyprctl && [ -n "${HYPRLAND_INSTANCE_SIGNATURE:-}" ]; then
    hyprctl reload >/dev/null 2>&1 && ok "Reloaded Hyprland." || warn "hyprctl reload failed."
  fi
}

# ----------------------------------------------------------------------------
# systemd --user service (alternative to exec-once)
# ----------------------------------------------------------------------------
install_systemd_service() {
  # $1 = unit basename (e.g. myday-dashboard), $2 = ExecStart command string
  local unit="$1" execcmd="$2"
  mkdir -p "$USER_UNIT_DIR"
  local path="$USER_UNIT_DIR/$unit.service"
  cat > "$path" <<EOF
# Generated by myday-autostart.sh. 'systemctl --user edit' to override.
[Unit]
Description=MyDay planner ($unit)
After=graphical-session.target
PartOf=graphical-session.target

[Service]
Type=simple
# Run inside a terminal so the TUI has a tty; Hyprland must be running.
ExecStart=$execcmd
Restart=on-failure
RestartSec=3

[Install]
WantedBy=graphical-session.target
EOF
  ok "Wrote $path"
  if have systemctl; then
    systemctl --user daemon-reload >/dev/null 2>&1 || true
    systemctl --user enable "$unit.service" >/dev/null 2>&1 && ok "Enabled $unit.service (starts next login)." \
      || warn "Could not enable $unit.service."
    info "Start it now with: systemctl --user start $unit.service"
  else
    warn "systemctl not found; the unit was written but not enabled."
  fi
}

# ----------------------------------------------------------------------------
# Actions
# ----------------------------------------------------------------------------
do_dashboard() {
  step "MyDay dashboard autostart"
  detect_myday
  detect_terminal || { err "Need a terminal emulator for the dashboard."; exit 1; }
  local cmd; cmd="$(myday_cmd "")"
  local run;  run="$(term_exec "myday-dashboard" "$cmd")"

  if [ "$USE_SYSTEMD" -eq 1 ]; then
    install_systemd_service "myday-dashboard" "$run"
    # Add a Hyprland window rule to pin it to a workspace, if requested.
    if [ -n "$WORKSPACE" ]; then
      ensure_include_sourced
      put_block "dashboard-rule" "windowrulev2 = workspace $WORKSPACE, class:^(myday-dashboard)\$"
      reload_hypr
    fi
  else
    ensure_include_sourced
    local block="exec-once = $run"
    if [ -n "$WORKSPACE" ]; then
      block="$block
windowrulev2 = workspace $WORKSPACE, class:^(myday-dashboard)\$"
    fi
    put_block "dashboard" "$block"
    reload_hypr
  fi
  ok "Dashboard will launch on login${WORKSPACE:+ on workspace $WORKSPACE}."
  info "Command: $run"
}

do_widget() {
  step "MyDay widget autostart"
  detect_myday
  detect_terminal || { err "Need a terminal emulator for the widget."; exit 1; }
  local cmd; cmd="$(myday_cmd "widget")"
  local run;  run="$(term_exec "myday-widget" "$cmd")"
  ensure_include_sourced
  # Float it small; optionally pin to a workspace. Class 'myday-widget'.
  local block
  block="exec-once = $run
windowrulev2 = float, class:^(myday-widget)\$
windowrulev2 = size 480 320, class:^(myday-widget)\$
windowrulev2 = move 100%-500 60, class:^(myday-widget)\$
windowrulev2 = pin, class:^(myday-widget)\$"
  [ -n "$WORKSPACE" ] && block="$block
windowrulev2 = workspace $WORKSPACE silent, class:^(myday-widget)\$"
  put_block "widget" "$block"
  reload_hypr
  ok "Widget will launch on login as a small floating window."
  info "Command: $run"
}

do_waybar() {
  step "MyDay waybar module"
  detect_myday
  local statuscmd; statuscmd="$(myday_cmd "status --json")"
  local ref_abs="$REPO_ROOT/omarchy/waybar/myday-module.jsonc"
  cat <<EOF
Add a custom module to your Waybar config (~/.config/waybar/config or
config.jsonc). Reference module lives at:
    $WAYBAR_MODULE_REF
    (absolute: $ref_abs)

1) Add "custom/myday" to a modules list, e.g.:
       "modules-right": ["custom/myday", "clock", "battery"],

2) Add the module definition:
       "custom/myday": {
           "exec": "$statuscmd",
           "return-type": "json",
           "interval": 60,
           "on-click": "$(term_exec myday-dashboard "$(myday_cmd "")" 2>/dev/null || echo "myday")",
           "tooltip": true
       }

   'myday status --json' prints Waybar-shaped JSON: {"text","tooltip","class"}.

3) Reload Waybar:  killall -SIGUSR2 waybar   (or restart it)
EOF
  if [ -f "$ref_abs" ]; then
    ok "Reference module file exists: $ref_abs"
  else
    warn "Reference module file not found at $ref_abs."
    warn "Create it from the snippet above (a waybar build-agent may add it)."
  fi
}

do_remove() {
  step "Removing MyDay autostart entries"
  remove_block "dashboard"
  remove_block "dashboard-rule"
  remove_block "widget"
  ok "Removed exec-once/rule blocks from $AUTO_CONF (backed up)."
  if have systemctl; then
    for unit in myday-dashboard myday-widget; do
      if [ -f "$USER_UNIT_DIR/$unit.service" ]; then
        systemctl --user disable --now "$unit.service" >/dev/null 2>&1 || true
        rm -f "$USER_UNIT_DIR/$unit.service"
        ok "Removed systemd user unit $unit.service"
      fi
    done
    systemctl --user daemon-reload >/dev/null 2>&1 || true
  fi
  reload_hypr
  info "The 'source=' line in hyprland.conf was left in place (harmless if the include is empty)."
}

do_status() {
  step "myday-autostart status"
  detect_myday || true
  detect_terminal || true
  [ -f "$AUTO_CONF" ] && { ok "include: $AUTO_CONF"; grep -E '^# >>> myday:' "$AUTO_CONF" 2>/dev/null | sed 's/^/    /' || true; } || warn "no include file yet"
  if [ -f "$MAIN_CONF" ] && grep -qF 'hypr/myday-autostart.conf' "$MAIN_CONF"; then ok "hyprland.conf sources the include"; else warn "hyprland.conf does NOT source the include"; fi
  if have systemctl; then
    for unit in myday-dashboard myday-widget; do
      [ -f "$USER_UNIT_DIR/$unit.service" ] && ok "systemd unit: $unit.service ($(systemctl --user is-enabled "$unit.service" 2>/dev/null || echo '?'))"
    done
  fi
}

# ----------------------------------------------------------------------------
# Main
# ----------------------------------------------------------------------------
main() {
  local action=""
  [ $# -eq 0 ] && { usage; exit 0; }
  while [ $# -gt 0 ]; do
    case "$1" in
      --dashboard) action="dashboard" ;;
      --widget)    action="widget" ;;
      --waybar)    action="waybar" ;;
      --remove)    action="remove" ;;
      --status)    action="status" ;;
      --systemd)   USE_SYSTEMD=1 ;;
      --workspace) shift; WORKSPACE="${1:-}"; [ -n "$WORKSPACE" ] || { err "--workspace needs a value"; exit 2; } ;;
      --workspace=*) WORKSPACE="${1#*=}" ;;
      -h|--help)   usage; exit 0 ;;
      *) err "Unknown option: $1"; usage; exit 2 ;;
    esac
    shift
  done
  case "$action" in
    dashboard) do_dashboard ;;
    widget)    do_widget ;;
    waybar)    do_waybar ;;
    remove)    do_remove ;;
    status)    do_status ;;
    *) err "Pick one of --dashboard/--widget/--waybar/--remove/--status"; usage; exit 2 ;;
  esac
}

main "$@"
