# SCREENSAVER.md

The MyDay idle screensaver: after 5 minutes idle the planner morphs into rotating neon-green pixel effects, and from 10pm to 6am the screen stays on but goes almost black.

## Table of contents

- [What it does](#what-it-does)
- [1. The two behaviors](#1-the-two-behaviors)
- [2. The effects (what rotates)](#2-the-effects-what-rotates)
- [3. Preview it: `myday screensaver`](#3-preview-it-myday-screensaver)
- [4. Configure it: config.toml](#4-configure-it-configtoml)
- [5. Configure it: MYDAY_* env vars](#5-configure-it-myday_-env-vars)
- [6. How it relates to Omarchy idle (hypridle) and screen-off-never.sh](#6-how-it-relates-to-omarchy-idle-hypridle-and-screen-off-neversh)
- [7. Quick recipes](#7-quick-recipes)
- [Sources](#sources)

---

## What it does

This is an **in-app** screensaver that lives inside the MyDay TUI, not a system compositor feature. `MyDayApp` tracks input; after `idle_seconds` with no key or mouse activity it pushes a full-screen overlay (`myday/screensaver/engine.py`) that animates pixel effects at ~13 fps. Any key, click, or real mouse move dismisses it and returns you to the planner. A separate nightly window dims the whole thing to near-black so a planner left open overnight does not glow.

Because it is part of the app, it only runs while `myday` is the focused foreground program. System-level blanking of the whole desktop is a different layer - see section 6.

---

## 1. The two behaviors

### Idle screensaver

- Trigger: `idle_seconds` (default **300** = 5 minutes) of no input while the app is on its main screen.
- It picks a random effect, animates it, and **rotates to a different random effect every `rotate_seconds`** (default **60** = 1 minute).
- A faint green clock sits at the bottom.
- Dismiss: any key, mouse-down, click, or genuine mouse move (a resting cursor in the first 0.4s after it appears will not dismiss it).
- Robustness: a buggy effect can never crash the app - the render loop degrades to a solid dark field.

### Nightly blackout ("screen on but dark")

- Window: `night_start` (default **22:00**) to `night_end` (default **06:00**), wrapping past midnight.
- When active and `night_dark` is true, animation **stops** and the field becomes almost black with a single, barely-visible dim clock line near the center. The screen is still on - it is just intentionally dark so the room stays dark.
- This is evaluated by `config.in_night_window()` and applies both when the saver is already up and when it kicks in during the night.

---

## 2. The effects (what rotates)

Defined in `myday/screensaver/effects.py`; all render in the brand green ramp (`palette.GREEN_RAMP`, dark to bright). The registry `ALL_EFFECTS` currently holds eight, addressed by these short names:

| Name | Effect |
| --- | --- |
| `matrix` | Matrix-style falling green code rain |
| `pipes` | Growing/turning pipes that wander the screen |
| `life` | Conway's Game of Life cellular automaton |
| `starfield` | Flying-through-stars warp field |
| `dvd` | Bouncing logo ("dvd" style) ricocheting off the edges |
| `plasma` | Smooth animated plasma gradient |
| `balls` | Bouncing metaballs / balls |
| `rain` | Pixel rain (falling droplets) |

Use these exact names in the `effects` setting to restrict which ones are eligible. An empty list (the default) means "all of them". Unknown names are ignored, and if nothing valid remains it falls back to all effects so the saver always has something to show.

---

## 3. Preview it: `myday screensaver`

Run the screensaver by itself, without waiting 5 minutes, to test effects/timing/night mode:

```bash
myday screensaver          # opens the saver immediately in a throwaway app
# press any key or click to exit
```

This is the fast feedback loop for config changes. To preview the nightly blackout during the day, force the night window with env vars (section 5), for example:

```bash
# make "night" = right now, for a 10-minute window, then preview
MYDAY_NIGHT_START=00:00 MYDAY_NIGHT_END=23:59 myday screensaver
```

To preview a single effect only:

```bash
MYDAY_EFFECTS=plasma myday screensaver
```

---

## 4. Configure it: config.toml

User settings live at `~/.config/myday/config.toml` (or `$XDG_CONFIG_HOME/myday/config.toml`). Keys map to `myday/config.py`'s `Settings`. Both a `[myday]` table and flat keys are accepted. Friendly `HH:MM` aliases exist for the night window.

```toml
[myday]
# Idle screensaver
idle_seconds   = 300        # seconds of no input before the saver starts (0 disables)
rotate_seconds = 60         # switch to a different effect every N seconds (min 5)

# Which effects are eligible (empty/omit = all). Names from section 2.
effects = ["matrix", "plasma", "starfield"]

# Nightly blackout - screen stays on but goes near-black
night_start = "22:00"       # alias -> night_start_min
night_end   = "06:00"       # alias -> night_end_min
night_dark  = true          # set false to disable the blackout entirely

# Clock format used by the saver's dim clock and the app
clock_24h = false
```

Notes on the exact keys (from `config.py`):
- `night_start` / `night_end` are friendly aliases; internally they become `night_start_min` / `night_end_min` (minutes from local midnight, e.g. 1320 and 360). You may set either form.
- `night_dark = false` makes the app never blackout at night; the normal idle screensaver still runs.
- `idle_seconds = 0` disables the idle trigger (you can still open it manually with the `s` key or `myday screensaver`).
- If `night_start == night_end`, the blackout never triggers (degenerate case).

---

## 5. Configure it: MYDAY_* env vars

Env vars override `config.toml` for a single launch - handy for tests and one-off previews. Recognized by `config.py`:

| Env var | Maps to | Example |
| --- | --- | --- |
| `MYDAY_IDLE_SECONDS` | `idle_seconds` | `MYDAY_IDLE_SECONDS=10` |
| `MYDAY_ROTATE_SECONDS` | `rotate_seconds` | `MYDAY_ROTATE_SECONDS=5` |
| `MYDAY_NIGHT_START` | `night_start_min` (accepts `HH:MM` or minutes) | `MYDAY_NIGHT_START=22:00` |
| `MYDAY_NIGHT_END` | `night_end_min` (accepts `HH:MM` or minutes) | `MYDAY_NIGHT_END=06:00` |
| `MYDAY_NIGHT_DARK` | `night_dark` (`1/true/yes/on`) | `MYDAY_NIGHT_DARK=false` |
| `MYDAY_CLOCK_24H` | `clock_24h` | `MYDAY_CLOCK_24H=true` |
| `MYDAY_THEME` | `theme` | `MYDAY_THEME=krishadmin` |

> Note: there is a `MYDAY_EFFECTS` convention used in previews above; the reliable, always-supported way to pin effects is the `effects` key in `config.toml`. If `MYDAY_EFFECTS` does not take effect on your build, use the toml key (flagged - the env override for effects is not in the `config.py` env map).

Fast idle demo:

```bash
# saver after 10s idle, new effect every 5s
MYDAY_IDLE_SECONDS=10 MYDAY_ROTATE_SECONDS=5 myday
```

---

## 6. How it relates to Omarchy idle (hypridle) and screen-off-never.sh

There are three independent idle layers. They complement rather than replace each other:

| Layer | Owner | What it controls | Config |
| --- | --- | --- | --- |
| MyDay screensaver | the app | In-app pixel effects + nightly near-black **while `myday` is focused** | `~/.config/myday/config.toml`, `MYDAY_*` |
| hypridle / hyprlock | Omarchy/Hyprland | Desktop-wide: dim, lock, DPMS screen-off, suspend after longer idle | `~/.config/hypr/hypridle.conf` |
| `scripts/screen-off-never.sh` | the kit | Toggles hypridle's DPMS/screen-off listener so the panel never powers off | edits `hypridle.conf` (backed up) |

How they interact:

- The MyDay screensaver only paints inside the terminal running `myday`. If hypridle later powers the whole panel off (DPMS) or locks with hyprlock, that wins over the app - the display is off regardless of what the app is drawing.
- For a wall-display / always-on planner, you usually want: MyDay's nightly blackout **on** (dark but visible), and the system DPMS screen-off **disabled** so hypridle does not black the panel out from under it. That is exactly what `scripts/screen-off-never.sh --never` does:

```bash
# Stop Omarchy from powering the panel off on idle (panel stays lit; lock/suspend untouched)
scripts/screen-off-never.sh --never
scripts/screen-off-never.sh --status     # inspect current DPMS/listener/service state
scripts/screen-off-never.sh --restore    # put Omarchy's original behavior back
```

`screen-off-never.sh` edits only the DPMS/screen listeners in `hypridle.conf` (every change is backed up and idempotent); it does not disable idle-lock or suspend unless you opt in to fully masking the hypridle service when prompted. See the script's own `--help`.

- If you want the planner readable at night on a wall, combine: `night_dark = true` (so MyDay itself dims) with `screen-off-never.sh --never` (so the panel does not sleep). If instead you want the panel fully off overnight, leave hypridle's DPMS listener alone and let it power off - MyDay's blackout is redundant then.

> Battery/burn-in caveat (from the script): a panel that never sleeps drains battery faster and can burn in static images on OLED/AMOLED Surface panels. Prefer locked-but-off for unattended idle unless you specifically want the display lit.

---

## 7. Quick recipes

```bash
# Calmer saver: only smooth effects, rotate every 2 minutes
cat >> ~/.config/myday/config.toml <<'EOF'
[myday]
effects = ["plasma", "starfield", "matrix"]
rotate_seconds = 120
EOF

# Later blackout (11pm to 5am)
#   in config.toml:  night_start = "23:00"   night_end = "05:00"

# Disable the nightly blackout but keep the idle effects
#   in config.toml:  night_dark = false

# Kiosk/wall planner: dim at night, never let the panel sleep
#   config.toml: night_dark = true
scripts/screen-off-never.sh --never
```

You can also open the screensaver on demand from inside the app with the `s` key (see KEYBINDINGS.md).

---

## Sources

- Repo files read for accuracy: `myday/config.py`, `myday/app.py`, `myday/screensaver/engine.py`, `myday/screensaver/effects.py`, `myday/__main__.py`, `scripts/screen-off-never.sh`, `CONTRACT.md`
- Hyprland idle daemon (hypridle) reference: https://wiki.hypr.land/Hypr-Ecosystem/hypridle/
- Omarchy manual (idle/lock/screen power context): https://learn.omacom.io/2/the-omarchy-manual

> Unverified / flagged: `MYDAY_EFFECTS` is used in preview examples but is not in `config.py`'s documented env map; the guaranteed way to pin effects is the `effects` key in `config.toml`. The effect list reflects the eight effects currently registered in `effects.py` and may grow.
