# Getting the Most from Claude on Your Omarchy Laptop

> One-line summary: Install Claude Code (Anthropic's terminal coding agent), sign in with your existing Claude Pro/Max subscription (no extra cost, no API key), and use it right here in the terminal to edit dotfiles, write Hyprland/waybar config, debug Arch, and script your machine.

Your paid claude.ai plan already includes Claude Code usage. That means the same subscription you use for chat in the browser also powers an agent that can read and edit files, run commands, and fix things on this laptop, from the terminal. This guide gets you set up and productive without burning through your usage.

## Table of Contents

1. [What Claude Code Is (and claude.ai vs Claude Code)](#what-claude-code-is)
2. [Installing Claude Code on Arch/Omarchy](#installing-claude-code-on-archomarchy)
3. [First-Run Authentication (Pro/Max)](#first-run-authentication-promax)
4. [Running It in the Terminal](#running-it-in-the-terminal)
5. [Useful Built-in Slash Commands](#useful-built-in-slash-commands)
6. [Using Claude to Manage THIS Laptop](#using-claude-to-manage-this-laptop)
7. [Permissions and Safety](#permissions-and-safety)
8. [MCP in One Minute](#mcp-in-one-minute)
9. [Tips to Avoid Burning Usage](#tips-to-avoid-burning-usage)
10. [When to Use the Browser (claude.ai) Instead](#when-to-use-the-browser-claudeai-instead)
11. [10 Things to Try First](#10-things-to-try-first)
12. [Sources](#sources)

---

## What Claude Code Is

Claude Code is a command-line agent from Anthropic. You run `claude` in a terminal, describe what you want in plain English, and it can read your files, propose and make edits, run shell commands (with your permission), and iterate. It is not a chat window that hands you snippets to paste; it actually does the work in your project or on your system.

claude.ai (browser) vs Claude Code (terminal):

| Use claude.ai (browser) | Use Claude Code (terminal) |
| --- | --- |
| Brainstorming, explaining concepts, reading long docs | Editing real files on this laptop |
| Pasting a log to ask "what does this mean?" | Running commands and fixing the machine directly |
| Drafting text, images, general questions | Writing/testing Hyprland, waybar, scripts in place |
| No local access needed | Access to your filesystem and shell |

Both draw from the same subscription, and Pro/Max share one usage pool across chat and Claude Code, so you can check combined usage in one place (see [/usage](#useful-built-in-slash-commands)).

---

## Installing Claude Code on Arch/Omarchy

Arch is not on Anthropic's official supported-distro list, but the native installer and the other methods work fine on standard (glibc) Arch, which Omarchy is. Pick one:

### Option 1: Official native installer (recommended)

```bash
curl -fsSL https://claude.ai/install.sh | bash
```

Why this one: single self-contained binary at `~/.local/bin/claude`, and it auto-updates in the background. Simplest path.

Make sure `~/.local/bin` is on your `PATH`. Test:

```bash
claude --version    # if "command not found", add ~/.local/bin to PATH and reopen the terminal
```

If needed, add it (bash):

```bash
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc && source ~/.bashrc
```

### Option 2: AUR (if you prefer pacman/yay management)

```bash
yay -S claude-code            # latest
# or: yay -S claude-code-stable   # a bit behind, more conservative
```

Trade-offs: AUR packages are community-maintained (not official Anthropic builds), they do NOT auto-update, and installing this way disables Claude Code's built-in auto-update, so you update it with `yay -Syu` yourself.

### Option 3: npm (works, but deprecated)

```bash
npm install -g @anthropic-ai/claude-code    # needs Node.js 22+
```

Notes: Anthropic has deprecated the npm method in favor of the native installer; it still works for now. Do NOT use `sudo npm install -g` (causes permission and security problems); configure a user-level npm prefix instead if you hit `EACCES`.

Recommendation for you: use Option 1 (native installer) unless you specifically want everything under pacman, in which case use the AUR.

To confirm the exact, current flags for any of this, run `claude --help` after install.

---

## First-Run Authentication (Pro/Max)

1. Start it in any folder:

```bash
claude
```

2. On first run it prompts you to log in. Choose the "Claude account with subscription" option (Pro, Max, Team, or Enterprise). It opens a browser to authenticate; approve, and you are done. No API key required on a paid claude.ai plan.

3. You can re-run auth anytime from inside Claude Code:
   - `/login` - sign in or switch to your subscription account.
   - `/logout` - sign out.
   - `/status` - check which account/plan you are currently on.

Common pitfall: if the environment variable `ANTHROPIC_API_KEY` is set, Claude Code will use pay-as-you-go API billing instead of your subscription. If you want your Pro/Max plan, make sure that variable is not set:

```bash
echo "$ANTHROPIC_API_KEY"    # should print nothing; if it prints a key, unset it:
unset ANTHROPIC_API_KEY      # and remove it from ~/.bashrc / ~/.config if it persists
```

Then `/logout` and `/login` again, choosing the subscription option only.

---

## Running It in the Terminal

Basic loop:

```bash
cd ~/.config/hypr        # start Claude where the files you care about live
claude                   # opens an interactive session in this folder
```

Then just talk to it: "explain what monitors.conf does", or "add a keybinding SUPER+B to open the browser". It shows you proposed edits/commands and (by default) asks before doing anything that changes files or runs commands.

Other ways to launch (verify exact syntax with `claude --help`):

```bash
claude "summarize what's in this directory"   # one-shot: ask, get an answer, and it stays interactive
claude --help                                  # authoritative list of flags for your version
```

Inside a session, useful keys and behaviors (may vary by version, check the on-screen hints):

- Type your request and press Enter.
- Slash commands start with `/` (see next section).
- `Ctrl + C` to interrupt; ask it to "stop" in plain English too.

---

## Useful Built-in Slash Commands

Type these inside a Claude Code session. This is a practical subset; run `/help` for the full, current list on your version.

- `/help` - list available commands and get help.
- `/login`, `/logout`, `/status` - manage and check your account/plan.
- `/usage` - see your usage breakdown; Pro/Max share one pool across chat + Claude Code.
- `/clear` - clear the current conversation context (start fresh, saves tokens).
- `/init` - have Claude scan the project and create a `CLAUDE.md` notes file it will remember.
- `/mcp` - view and manage MCP servers (external tools/data, see [MCP](#mcp-in-one-minute)).
- `/config` - open settings (model, theme, and similar).

If any command above is not present on your build, `/help` is the source of truth. Where you are unsure of a detail, verify with `claude --help` or `/help` rather than assuming.

---

## Using Claude to Manage THIS Laptop

This is where Claude Code shines on Omarchy. Concrete examples to try (run `claude` from the relevant folder first):

Edit dotfiles and Hyprland config:

```bash
cd ~/.config/hypr && claude
# then: "Add a keybinding: SUPER+SHIFT+B opens Chromium. Put it in bindings.conf and explain what you changed."
```

Then reload Hyprland (`SUPER + Shift + C`) to apply.

Write/adjust waybar:

```bash
cd ~/.config/waybar && claude
# then: "Add a CPU temperature module to the bar and style it to match the current theme."
```

Debug an Arch issue (let it read the logs):

```bash
claude
# then: "My bluetooth headset connects but has no audio. Look at journalctl and systemctl for pipewire/bluetooth and suggest a fix."
```

Script routine tasks:

```bash
claude
# then: "Write a bash script that backs up ~/.config to ~/backups with a timestamp, and make it executable."
```

Learn while you go: ask "explain this file line by line" on any config you do not understand. Because Claude Code can see the actual file, its explanations are about your real setup, not a generic example.

Good habit: run `/init` once in a project (or in `~/.config`) so Claude records a `CLAUDE.md` with notes about your setup and preferences, which it reuses in later sessions.

---

## Permissions and Safety

By default Claude Code asks before it edits files or runs shell commands, and it shows you exactly what it wants to do. Keep it that way while you are learning.

- Read the diff/command it proposes before approving. You are the reviewer.
- Be extra careful approving anything with `sudo`, `rm`, `pacman -R`, or that touches system files. When unsure, say "explain what this command does first".
- You can allow-list routine safe commands so it stops asking for them; do this deliberately, not blanket-approving everything.
- Your snapshots are still your backstop: if a change to system state goes wrong, you can roll back (see the ARCH-GUIDE snapshots section). For personal config, keep a `~/.config.bak`.
- There is a broader auto-approve/"yolo" style mode; avoid it on your daily machine until you are comfortable. Check `claude --help` for the exact flag name and behavior on your version rather than trusting a remembered name.

---

## MCP in One Minute

MCP (Model Context Protocol) lets Claude Code connect to external tools and data sources through small "servers", for example a filesystem, a GitHub integration, or a documentation source. Once connected, Claude can use those tools during a session.

- Manage them with the `/mcp` command inside Claude Code.
- You do not need MCP to get value from Claude Code on this laptop; it is an add-on for when you want Claude to reach specific external systems.
- Add servers only from sources you trust, since they extend what Claude can access.

Treat this as "nice to know" for now. Start with plain Claude Code, add MCP later if a real need appears. For current setup steps, see the official docs (linked in Sources) or `claude --help`.

---

## Tips to Avoid Burning Usage

Your Pro/Max plan has usage limits shared with browser chat, so spend tokens where they count:

- Use `/clear` between unrelated tasks. A long, stale conversation is re-sent each turn and wastes tokens.
- Keep sessions scoped: `cd` into the specific folder so Claude is not pulling in your whole home directory.
- Be specific in requests ("edit bindings.conf to add X") rather than vague ("fix my setup"); fewer back-and-forth turns.
- Let it read the exact file/log rather than pasting huge blobs repeatedly.
- Check `/usage` occasionally so limits do not surprise you.
- Prefer the default model for routine edits; save the heaviest model for genuinely hard problems (choose via `/config` or `/model` if present, verify with `/help`).
- Do quick conceptual Q&A in the browser (see next section) and save Claude Code for actual file/command work.

---

## When to Use the Browser (claude.ai) Instead

Reach for browser chat when:

- You just want to understand a concept, compare options, or draft text, with no need to touch local files.
- You are away from this laptop.
- You want to paste a screenshot or a snippet and think out loud.

Reach for Claude Code when:

- The task is "change something on this machine" (dotfiles, config, scripts, debugging with real logs).
- You want commands actually run and verified, not just suggested.

They share your subscription, so use whichever fits the task; there is no separate bill for Claude Code on a paid plan.

---

## 10 Things to Try First

Geared for a new Arch/Omarchy user:

1. Install and verify: run the native installer, then `claude --version`.
2. `claude` then `/login` and choose the subscription option; confirm with `/status`.
3. Run `/help` and skim the available slash commands.
4. In `~/.config/hypr`, ask Claude to "explain monitors.conf and bindings.conf in plain English".
5. Ask it to add one harmless keybinding, then reload Hyprland (`SUPER + Shift + C`) to see it work.
6. Ask it to "add a small module to my waybar and match the current theme".
7. Debugging drill: "read journalctl for the last boot and tell me if anything looks wrong".
8. Have it write a timestamped `~/.config` backup script and make it executable.
9. Run `/init` in `~/.config` so Claude remembers your setup next time.
10. Check `/usage` to see how much of your plan a session actually used.

Whenever a detail here does not match what you see, trust `claude --help` and `/help` over this document; Claude Code updates frequently.

---

## Sources

- [Anthropic: Use Claude Code with your Pro or Max plan](https://support.claude.com/en/articles/11145838-use-claude-code-with-your-pro-or-max-plan)
- [Claude Code Docs: Authentication](https://code.claude.com/docs/en/authentication)
- [Claude Code Docs: Advanced setup](https://code.claude.com/docs/en/setup)
- [Installing Claude on Arch Linux (AUR + official installer)](https://www.clauder-navi.com/en/claude-linux-arch)
- [Claude Code on Linux install guide (Morph)](https://www.morphllm.com/claude-code-linux)
- [Install or Update Claude Code 2026 (NxCode)](https://www.nxcode.io/resources/news/install-claude-code-setup-guide-2026)
- [npm install Claude Code guide (Morph)](https://www.morphllm.com/npm-install-claude-code)
- [Claude Code CLI cheat sheet (Shipyard)](https://shipyard.build/blog/claude-code-cheat-sheet/)
