# Arch + Omarchy: A Friendly New-User Guide

> One-line summary: You are running Omarchy, an opinionated Arch Linux desktop built around the Hyprland tiling window manager. This guide teaches you the day-to-day skills to use it, keep it updated safely, and recover when something breaks.

Welcome. Arch has a scary reputation, but Omarchy does most of the hard parts for you. This guide is written for someone brand new to Arch. Every command is copy-pasteable, and each one comes with a short "why". Take it slow, and remember: you have snapshots, so you can almost always undo a bad change (see [Snapshots and Recovery](#snapshots-and-recovery)).

## Table of Contents

1. [What Omarchy Is](#what-omarchy-is)
2. [The Keyboard Is Your Friend (SUPER shortcuts)](#the-keyboard-is-your-friend-super-shortcuts)
3. [The Omarchy Menu](#the-omarchy-menu)
4. [Package Management: pacman and yay](#package-management-pacman-and-yay)
5. [Updating Safely with omarchy-update](#updating-safely-with-omarchy-update)
6. [Where Configs Live](#where-configs-live)
7. [Installing Fonts, Apps, Themes, and Web Apps](#installing-fonts-apps-themes-and-web-apps)
8. [systemd and systemctl Basics](#systemd-and-systemctl-basics)
9. [Reading Logs with journalctl](#reading-logs-with-journalctl)
10. [Snapshots and Recovery](#snapshots-and-recovery)
11. [How to Experiment Safely](#how-to-experiment-safely)
12. [Troubleshooting](#troubleshooting)
13. [First Day on Arch Checklist](#first-day-on-arch-checklist)
14. [Sources](#sources)

---

## What Omarchy Is

Omarchy is an "omakase" (chef's-choice) Arch Linux desktop created by David Heinemeier Hansson (DHH) of 37signals. It takes a bare Arch install and layers on:

- Hyprland, a keyboard-driven tiling window manager (windows auto-arrange instead of floating like Windows/macOS).
- A curated set of apps, fonts, themes, and sensible defaults, so you skip the 4-8 hours of manual Arch + Hyprland setup.
- Its own tooling: an app/command menu, an updater (`omarchy-update`), automatic snapshots, and theme management.

How it differs from vanilla Arch:

| Vanilla Arch | Omarchy |
| --- | --- |
| You pick and configure everything (WM, fonts, bar, audio) | Comes preconfigured with Hyprland + a full desktop |
| You update with `pacman -Syu` yourself | You update with `omarchy-update` (snapshots + migrations + packages together) |
| No snapshots unless you set them up | Btrfs + Snapper + Limine snapshots on by default |
| Mostly mouse-optional but not designed for it | Designed keyboard-first; the SUPER key drives everything |

Key mindset shift: Omarchy is keyboard-first. When it boots you may feel stuck with just a mouse. Do not panic. Press `SUPER + K` to see every shortcut for your exact version (this is the single most useful key to remember).

Note on versions: Omarchy changes fast (Omarchy 2, 3, and 4 all shipped notable changes). This guide flags where behavior varies by version. When in doubt, trust `SUPER + K` and the Omarchy menu over any written guide, including this one.

---

## The Keyboard Is Your Friend (SUPER shortcuts)

"SUPER" is the Windows/Command key. These are the common Omarchy defaults. Your version may differ slightly, so verify with `SUPER + K`.

Launchers and menus:

- `SUPER + K` - show the keybindings reference (your version's live cheat sheet). Learn this first.
- `SUPER + Return` - open a terminal.
- `SUPER + Space` - open the app launcher / Omarchy menu (see note below).
- `SUPER + Alt + Space` - open a launcher scoped to just your apps.
- `SUPER + Shift + Return` - open a browser.

Windows and workspaces:

- `SUPER + W` - close the focused window.
- `SUPER + Arrow keys` - move between workspaces.
- `SUPER + H / J / K / L` - move focus left / down / up / right (Vim-style, newer versions).
- `SUPER + Shift + H / J / K / L` - swap windows in that direction.
- `SUPER + J` (older bindings) - toggle horizontal/vertical split layout.
- `SUPER + left/right mouse drag` - move (left) or resize (right) a floating window.

System and config:

- `SUPER + Escape` then Relaunch - restart Hyprland.
- `SUPER + Shift + C` - reload the Hyprland config after you edit it.
- `Ctrl + Shift + SUPER + Space` - open the theme picker.
- `SUPER + /` and `SUPER + Alt + /` - step display scaling up / down (handy on HiDPI).

Note on the menu shortcut: In the newest Omarchy the old "Walker" launcher was merged into one native menu, and `SUPER + Space` opens it. On older versions `SUPER + Space` was the app launcher and the Omarchy menu was `SUPER + Alt + Space`. Both are worth trying. Again, `SUPER + K` shows the truth for your install.

You customize keybindings by editing `~/.config/hypr/bindings.conf` (never the system files under `~/.local/share/omarchy/`, which get overwritten on update). More on that in [Where Configs Live](#where-configs-live).

---

## The Omarchy Menu

The Omarchy menu is a filterable command palette that launches apps and runs almost every Omarchy action (install things, change themes, reload hardware, manage updates). Open it with `SUPER + Space` (or `SUPER + Alt + Space` on Omarchy 3). Start typing to fuzzy-search.

Common paths you will use:

- `Install > Web App` - turn a website into a frameless desktop app.
- `Install > Style > Font` - install a programming font.
- `Style > Theme` - switch themes (or `Install > Theme` for a third-party one).
- `Update > Hardware` - reload Wi-Fi / Bluetooth / Audio / Trackpad (fixes most "it worked a minute ago" glitches).
- `Setup > Direct Boot` - boot straight into Omarchy instead of stopping at the boot menu.

The menu is the friendly front door to features you would otherwise run as terminal commands. When you are new, prefer the menu.

---

## Package Management: pacman and yay

Software on Arch comes from two places: the official repositories (via `pacman`) and the Arch User Repository or AUR (community build recipes, via a helper like `yay`).

### pacman (official packages)

`pacman` needs `sudo` for anything that changes the system. Flags are terse; here is the cheat sheet:

```bash
# Search for a package
pacman -Ss firefox            # -S sync, -s search

# Show info about a package
pacman -Si firefox            # not installed yet
pacman -Qi firefox            # already installed (-Q query local db)

# Install a package
sudo pacman -S firefox        # why: -S installs from official repos

# Remove a package (and its now-unneeded deps and config)
sudo pacman -Rns firefox      # why: -R remove, n=drop configs, s=drop orphan deps

# List what you have installed
pacman -Q                     # all packages
pacman -Qe                    # only ones you explicitly installed

# Find which package owns a file
pacman -Qo /usr/bin/firefox
```

Important: on Omarchy, do NOT run `sudo pacman -Syu` by itself to update (see the next section). `pacman -Sy` alone (refresh without full upgrade) is a classic way to break an Arch system - always pair a sync with a full upgrade, and on Omarchy let `omarchy-update` do it.

### yay (AUR packages)

`yay` wraps `pacman` and adds AUR support. It builds AUR packages from source on your machine. Do NOT run `yay` with `sudo`; it elevates itself when needed.

```bash
# Search including the AUR
yay -Ss some-tool

# Install an AUR (or official) package
yay -S some-aur-tool          # why: builds from the AUR recipe if not in official repos

# Remove
yay -Rns some-aur-tool
```

AUR safety: AUR packages are user-submitted build scripts, not vetted by Arch. Only install AUR packages you recognize, and when `yay` shows you a PKGBUILD, actually skim it before answering yes. This matters because Omarchy's auto-update runs AUR upgrades non-interactively.

---

## Updating Safely with omarchy-update

This is the most important habit on this machine.

Do this:

```bash
omarchy-update
```

Or click the circular-arrow icon that appears to the right of the clock in the top bar when an update is available.

Why not `pacman -Syu` or `yay -Syu`? Because `omarchy-update` does more than install packages. In one safe sequence it:

1. Takes a Btrfs snapshot first, so you can roll back if the update breaks something.
2. Checks you have enough free space (about 10 GiB on root) and holds a lock so two updates cannot collide.
3. Refreshes signing keys, then upgrades official packages (`pacman -Syu`) and any AUR packages (`yay`).
4. Runs Omarchy "migrations" that adjust your config to match the new release.
5. Logs the whole run to `/tmp/omarchy-update.log`.

If you update with plain `pacman`/`yay`, you skip the snapshot, the migrations, and the config updates - which is exactly how people end up with a half-broken system and no easy way back.

Update channels: New installs are on `stable` (about a month behind upstream, for safety). You can move to `RC`, `edge`, or `dev` via the Omarchy menu (`Update > Channel`) or `omarchy-channel-set` in the terminal. As a new user, stay on `stable`.

---

## Where Configs Live

The golden rule: your changes go in `~/.config/`; never edit Omarchy's system files under `~/.local/share/omarchy/` because updates overwrite them.

Key locations:

- `~/.config/hypr/` - Hyprland config. Common files:
  - `bindings.conf` - your keybinding overrides.
  - `monitors.conf` or `monitors.lua` - display resolution and scaling (name depends on Omarchy version).
  - `input.conf` / `input.lua` - keyboard and trackpad.
- `~/.config/waybar/` - the top bar (modules, layout, styling).
- `~/.config/omarchy/themes/` - your own themes.
- `~/.local/share/omarchy/` - Omarchy's own defaults and themes. Read-only for you; copy from here into `~/.config/` when you want a starting point, then edit the copy.

After editing Hyprland config, reload it with `SUPER + Shift + C` (no reboot needed).

Tip: back up your `~/.config` before big experiments:

```bash
cp -r ~/.config ~/.config.bak    # why: instant local backup you can restore by hand
```

---

## Installing Fonts, Apps, Themes, and Web Apps

Prefer the Omarchy menu for these; it wires everything up correctly.

- Regular apps: install with `sudo pacman -S <app>` (official) or `yay -S <app>` (AUR). They appear in the launcher automatically.
- Fonts: Omarchy menu `Install > Style > Font`. This updates your terminals and system monospace font together. (Under the hood it uses `omarchy-font-set`.)
- Themes: `Style > Theme` to switch, `Install > Theme` (with a Git URL) for third-party ones. Theme switch also restyles the terminal, editor, bar, notifications, and lock screen.
- Web apps: `Install > Web App`. Give it a name, URL, and optional icon; it opens as a clean frameless window. Tip: log into that site in your normal browser first, since the thin wrapper does not play well with some password managers.
- Terminal (TUI) apps: Omarchy can wrap terminal tools (like lazydocker) so they launch like native apps from the launcher.

For a manual, non-packaged app (a GitHub release binary, say), you create a `.desktop` file in `~/.local/share/applications/`. The format is picky; the menu-based installers exist so you rarely have to hand-write these.

---

## systemd and systemctl Basics

systemd starts and supervises background services (networking, bluetooth, audio helpers). You talk to it with `systemctl`. Two scopes:

- System services (need `sudo`): things like NetworkManager, bluetooth.
- User services (`--user`, no sudo): things running as you, like the audio stack (PipeWire).

```bash
# System services
systemctl status NetworkManager      # is it running? why: shows state + recent logs
sudo systemctl restart NetworkManager
sudo systemctl enable  bluetooth      # start automatically at boot
sudo systemctl disable bluetooth
systemctl list-units --type=service --state=running   # what is running now

# User services (your session)
systemctl --user status pipewire      # audio server status
systemctl --user restart pipewire pipewire-pulse wireplumber   # fix crackly/dead audio
```

Handy distinction: `start`/`stop` act now; `enable`/`disable` control whether it comes back at next boot. You often want both (`sudo systemctl enable --now <service>`).

---

## Reading Logs with journalctl

When something misbehaves, the logs usually say why. systemd collects them; you read them with `journalctl`.

```bash
# Follow the whole system log live (like tail -f)
journalctl -f                          # why: watch errors appear as you reproduce them

# Logs since this boot, most useful when debugging a boot/hardware issue
journalctl -b

# Only errors and worse, this boot
journalctl -b -p err

# Logs for one service
journalctl -u NetworkManager -b
journalctl --user -u pipewire -b

# Kernel/hardware messages (wifi, gpu, usb)
journalctl -k -b     # or: dmesg
```

Press `q` to quit the pager, arrow keys or `PgUp`/`PgDn` to scroll, `/` to search inside it.

Omarchy also ships `omarchy-debug`, which bundles diagnostics for asking for help in the community.

---

## Snapshots and Recovery

This is your safety net, and it is why you can afford to experiment.

How it works: Omarchy uses Btrfs + Snapper + the Limine bootloader. Every `omarchy-update` takes a bootable snapshot of the system (root) first. If an update breaks your machine, you can boot an earlier snapshot.

To roll back after a bad update:

1. Reboot. At startup, press your firmware's boot-menu key (often `Esc` or `Del`, varies by laptop) and choose "Limine".
2. In the Limine menu, pick an earlier snapshot (each entry shows a date and the Omarchy version at bottom-left).
3. Once booted, a notification offers to start the restore. Click it, or run:

```bash
omarchy-snapshot restore
```

Important limits, know these:

- Restore only affects the root/system, NOT your `~/home`. Your personal files and `~/.config` are not rolled back automatically. That is usually what you want (you keep your documents), but it means a broken personal config is not fixed by a snapshot restore - fix those by hand or from your own `~/.config.bak`.
- Snapshots require the Limine bootloader (default since Omarchy 2.0). Not available on GRUB/systemd-boot installs.

If the boot menu itself looks broken or snapshots do not appear:

```bash
omarchy-refresh-limine     # rebuilds the boot menu and re-syncs snapshot entries
```

If all else fails, `omarchy-reinstall` restores the default configs and packages.

---

## How to Experiment Safely

You learn Arch by tinkering. Do it with a net:

- Change one thing at a time, then reload (`SUPER + Shift + C` for Hyprland) and see the effect.
- Back up before editing: `cp file file.bak`, or snapshot your whole `~/.config`.
- Keep a second terminal or workspace open so a broken config does not lock you out.
- Prefer the Omarchy menu and `~/.config/` overrides over editing system files.
- Update via `omarchy-update` only, so you always have a fresh pre-update snapshot.
- Skim AUR PKGBUILDs before installing. When unsure, do not install it.
- Note what you changed (a scratch file works) so you can undo it.

---

## Troubleshooting

First move for most hardware glitches: open the Omarchy menu, `Update > Hardware`, and reload Wi-Fi, Bluetooth, Audio, or Trackpad. This clears the majority of "it worked five minutes ago" problems (a headset that will not reconnect, dead trackpad after suspend, sound gone after unplugging a monitor).

Wi-Fi:

```bash
nmcli device wifi list            # scan networks
nmcli device wifi connect "SSID" password "yourpass"
systemctl status NetworkManager   # confirm the service is up
journalctl -u NetworkManager -b   # read errors if it will not connect
```

Bluetooth:

```bash
bluetoothctl                      # interactive: 'scan on', 'pair <MAC>', 'connect <MAC>', 'trust <MAC>'
systemctl status bluetooth
```

If a Bluetooth device shows connected but has no audio, reload Audio and Bluetooth from `Update > Hardware`; this is a known class of issue.

Audio (PipeWire):

- Click the speaker icon in the top-right of the bar to pick the correct output device. Set a default with `d` in the mixer.
- Restart the user audio stack if sound dies:

```bash
systemctl --user restart pipewire pipewire-pulse wireplumber
```

Display scaling on a HiDPI screen (like a Surface): Omarchy defaults to 2x scaling, assuming a very high-density "retina" panel (218+ PPI). On a normal 1080p/1440p external monitor things look huge; on a dense laptop panel 2x may be right.

- Quick way: step scaling with `SUPER + /` (up) and `SUPER + Alt + /` (down). On the default config this persists across reboots.
- Config way (varies by version):
  - Newer Omarchy uses `~/.config/hypr/monitors.lua`. For a 1080p/1440p display set `omarchy_gdk_scale = 1` and `omarchy_monitor_scale = 1`.
  - Older Omarchy uses `~/.config/hypr/monitors.conf`. Change `env = GDK_SCALE,2` to `env = GDK_SCALE,1`.
- After changing scale, close and reopen oversized windows (GDK_SCALE only affects apps started after the change), or relaunch Hyprland via the menu (`System > Relaunch`), or reboot.

Escalation ladder if reloads do not help: roll back to the pre-update snapshot; if still broken run `omarchy-debug` and ask in the Omarchy community; as a last resort `omarchy-reinstall`.

---

## First Day on Arch Checklist

- [ ] Press `SUPER + K` and skim the keybindings. This is your map.
- [ ] Open a terminal (`SUPER + Return`) and a browser (`SUPER + Shift + Return`).
- [ ] Open the Omarchy menu (`SUPER + Space`) and look through Install / Style / Update.
- [ ] Run your first update the right way: `omarchy-update`.
- [ ] Fix display scaling if things look too big/small (`SUPER + /`).
- [ ] Set your monospace font: menu `Install > Style > Font`.
- [ ] Pick a theme you like: `Style > Theme`.
- [ ] Connect Wi-Fi (`nmcli device wifi list`) and a Bluetooth device (`bluetoothctl`).
- [ ] Confirm audio output by clicking the speaker in the bar.
- [ ] Learn to roll back: read the [Snapshots and Recovery](#snapshots-and-recovery) section so you are not scared to experiment.
- [ ] Back up your config once: `cp -r ~/.config ~/.config.bak`.
- [ ] Learn to read logs: run `journalctl -f` and watch it while you click around.

You do not need to memorize pacman flags on day one. Keep this file open, use the Omarchy menu, and lean on snapshots. Have fun.

---

## Sources

- [Omarchy overview (It's FOSS)](https://itsfoss.com/news/omarchy/)
- [The Omarchy 3 Manual](https://learn.omacom.io/2/the-omarchy-manual)
- [Omarchy 3.x Cheat Sheet for Devs (gist)](https://gist.github.com/iagooar/e161ac5a2564b82a25a209076a38a503)
- [Omarchy Manual: Updates](https://omarchy.org/manual/updates/)
- [Omarchy Updates (learn.omacom.io)](https://learn.omacom.io/2/the-omarchy-manual/68/updates)
- [DeepWiki: Omarchy Update System](https://deepwiki.com/basecamp/omarchy/6.4-update-system)
- [DeepWiki: Omarchy Package Repositories](https://deepwiki.com/basecamp/omarchy/6.1-package-repositories)
- [Omarchy Manual: System snapshots](https://omarchy.org/manual/system-snapshots/)
- [DeepWiki: Boot Management and Snapshots](https://deepwiki.com/basecamp/omarchy/2.2-boot-management-and-snapshots)
- [Omarchy Manual: Web Apps](https://omarchy.org/manual/web-apps/)
- [Omarchy Manual: Themes](https://learn.omacom.io/2/the-omarchy-manual/52/themes)
- [Omarchy Manual: Monitors](https://omarchy.org/manual/monitors/)
- [Omarchy Manual: Troubleshooting](https://omarchy.org/manual/troubleshooting/)
- [Omarchy v4.0.0 release notes](https://github.com/omacom/omarchy/releases/tag/v4.0.0)
- [Arch Wiki: Snapper](https://wiki.archlinux.org/title/Snapper)
- [Arch Wiki: Limine](https://wiki.archlinux.org/title/Limine)
