# THEME.md

How the whole laptop - the MyDay TUI and the Omarchy desktop - is themed to match krishadmin.com: neon green on pure black, with maroon and glass-panel accents.

## Table of contents

- [Why one palette everywhere](#why-one-palette-everywhere)
- [1. The palette (canonical hexes)](#1-the-palette-canonical-hexes)
- [2. The TUI theme: palette.py + theme.tcss](#2-the-tui-theme-palettepy--themetcss)
- [3. The Omarchy theme: files and how it is applied](#3-the-omarchy-theme-files-and-how-it-is-applied)
- [4. Regenerating the wallpaper](#4-regenerating-the-wallpaper)
- [5. Tweaking colors and fonts](#5-tweaking-colors-and-fonts)
- [6. Make another app match (mini-guide)](#6-make-another-app-match-mini-guide)
- [Sources](#sources)

---

## Why one palette everywhere

The brand is a single, memorable look: signature neon green `#20fd14` on pure black `#000000`, with translucent dark "glass" panels and a deep maroon as the danger/secondary accent. Both the terminal planner and the desktop shell read from the same set of hexes so the machine feels like one product, not a terminal app dropped onto someone else's desktop.

There are two independent surfaces that must be kept in sync:

- The **MyDay TUI** - styled by `myday/palette.py` (Rich/Python side) and `myday/theme.tcss` (Textual CSS side).
- The **Omarchy desktop** - styled by the theme under `omarchy/themes/krishadmin/`, which feeds Hyprland, Waybar, Walker, the terminal, btop, mako, hyprlock, and more.

---

## 1. The palette (canonical hexes)

Lifted straight from krishadmin.com's CSS custom properties:

| Role | Hex | Site variable / note |
| --- | --- | --- |
| Accent (neon green) | `#20fd14` | `--accent`, the hero color |
| Accent dim | `#12a00c` | muted green for inactive / trails |
| Accent deep | `#0a5406` | darkest green for faint trails |
| Background | `#000000` | `--bg`, pure black |
| Panel (glass) | `#0c0e10` | `--glassBg` flattened on black |
| Panel lifted | `#14181b` | slightly raised panel |
| Border | `#2a2f33` | `--glassBorder` flattened on black |
| Text | `#eeeeee` | `--textOnGlass` |
| Text soft | `#bebebe` | `--textSoft` |
| Text sub | `#959595` | `--textSub` |
| Maroon (secondary) | `#69021b` | deep maroon accent |
| Maroon hi | `#a4102f` | brighter maroon = errors/danger |
| Warn | `#e0b020` | amber |
| Info | `#3aa0c9` | cyan-blue |

Semantic greens ramp (screensaver / meters), dark to bright:
`#031d02 -> #0a5406 -> #0e7a08 -> #12a00c -> #18cf10 -> #20fd14 -> #9dffa0`.

These exact values live in three files that must agree:
- `myday/palette.py` (the Python source of truth for the TUI)
- `myday/theme.tcss` (the Textual CSS, hardcoded to the same hexes)
- `omarchy/themes/krishadmin/colors.toml` (the Omarchy source of truth for the desktop)

---

## 2. The TUI theme: palette.py + theme.tcss

### palette.py - the Python color source

`myday/palette.py` is the single import for any Python/Rich rendering in the app. It exposes named constants (`ACCENT`, `BG`, `PANEL`, `MAROON`, ...), category colors, habit colors, mood colors, intensity colors, and the `GREEN_RAMP`, plus helpers `category_color()`, `habit_color()`, `mood_color()`. Screensaver effects, category chips, and any widget that renders through Rich import from here so their colors match the CSS exactly.

### theme.tcss - the Textual CSS

`myday/theme.tcss` is loaded globally by `MyDayApp` (`CSS_PATH` in `myday/app.py`). It hardcodes the same hexes and defines the reusable class vocabulary the whole UI is built on:

```
.panel .panel-title .card .muted .subtle .accent .danger .warn .done
.now .selected .chip .pill .key    #topbar #clock #statusbar
```

plus styled defaults for `DataTable`, `ListView`, `Input`, `Button`, `Select`, `Toast`, dialogs, and the `#screensaver` overlay layer.

### How it maps to the site

| Site element | TUI equivalent |
| --- | --- |
| Neon green links/headings | `.accent`, `.panel-title`, `#clock`, `#topbar .brand`, focused borders |
| Black page background | `Screen { background: #000000 }` |
| Translucent glass cards | `.panel` / `.card` on `#0c0e10` / `#14181b` with `#2a2f33` borders |
| Green focus ring | `.panel:focus-within { border: round #20fd14 }` |
| Maroon danger buttons | `.danger`, `Button.-danger { background: #69021b }` |

Rule of thumb from `CONTRACT.md`: build with the shared classes; only add widget-specific rules in a screen's `DEFAULT_CSS`, reusing the same hexes.

### Keep the two in sync

If you change a brand color, edit it in **both** `palette.py` and `theme.tcss` (Textual CSS cannot import Python constants). A quick consistency check:

```bash
cd /home/virt/krishpad
grep -n '20fd14\|0c0e10\|69021b' myday/palette.py myday/theme.tcss
```

---

## 3. The Omarchy theme: files and how it is applied

The desktop theme lives at `omarchy/themes/krishadmin/`. Files present:

| File | Themes |
| --- | --- |
| `colors.toml` | Canonical color keys (accent + 16 terminal colors); newer Omarchy renders every app config from these |
| `hyprland.conf` | Window borders (neon-green active), gaps, rounding, green-tinted shadow, dim-inactive |
| `hyprlock.conf` | Lock screen colors |
| `walker.css` | Walker launcher / menu styling |
| `waybar.css` | Top bar styling |
| `alacritty.toml` | Terminal colors (fallback source if `colors.toml` is absent) |
| `btop.theme` | System monitor palette |
| `mako.ini` | Notification daemon colors |
| `neovim.lua` | Editor colorscheme overrides |
| `backgrounds/` | Wallpaper(s) - the theme's `background` symlink target |

### How Omarchy applies a theme

Omarchy keeps installed themes in `~/.config/omarchy/themes/<name>/` and points a symlink `~/.config/omarchy/current/theme` at the active one. Component configs `source`/`import` through that symlink, so switching theme = swapping the symlink and reloading components. `hyprland.conf` above is meant to be pulled in with:

```conf
# in ~/.config/hypr/hyprland.conf
source = ~/.config/omarchy/current/theme/hyprland.conf
```

### Install and select the krishadmin theme

Two ways, depending on whether the kit's installer script is present:

```bash
# Preferred: the kit wrapper copies the theme into place and reloads components
/home/virt/krishpad/omarchy/apply-theme.sh          # theme only
/home/virt/krishpad/omarchy/apply-theme.sh --waybar # also install waybar bits
# (this is what `install.sh --theme` / `--all` runs)
```

Manual equivalent (portable, no script needed):

```bash
# 1. Copy the theme into Omarchy's user theme dir
mkdir -p ~/.config/omarchy/themes
cp -a /home/virt/krishpad/omarchy/themes/krishadmin ~/.config/omarchy/themes/

# 2. Activate it by name (atomic swap of the current/theme symlink + reloads)
omarchy-theme-set krishadmin

# 3. If you prefer the interactive picker instead of the direct set:
omarchy-theme-menu     # choose "krishadmin"
```

`omarchy-theme-set krishadmin` swaps the symlink and refreshes Hyprland, Waybar, Walker, mako, hyprlock, and the terminal so the new colors take effect without a logout.

> Status flag: `omarchy/apply-theme.sh` is referenced by `install.sh` (the `--theme`/`--waybar` steps) but may not be present in every checkout yet. The manual `cp` + `omarchy-theme-set` path always works.

---

## 4. Regenerating the wallpaper

The wallpaper is the `backgrounds/` folder inside the theme; Omarchy symlinks `~/.config/omarchy/current/background` to a file in there. To refresh it:

```bash
# 1. Drop a new image into the theme's backgrounds folder
cp my-new-wall.png /home/virt/krishpad/omarchy/themes/krishadmin/backgrounds/01.png
#    (and into the installed copy if already deployed)
cp my-new-wall.png ~/.config/omarchy/themes/krishadmin/backgrounds/01.png

# 2. Re-apply so Omarchy re-points the background symlink and reloads the wallpaper daemon
omarchy-theme-set krishadmin
```

To generate a fresh on-brand wallpaper from scratch (neon-green-on-black), any of these work; keep it dark so the green pops:

```bash
# Solid brand black with a subtle green vignette using ImageMagick:
magick -size 2880x1920 xc:'#000000' \
  -fill '#0a5406' -draw "circle 1440,960 1440,300" -blur 0x180 \
  omarchy/themes/krishadmin/backgrounds/01.png
```

> The kit does not ship a dedicated wallpaper generator script; the above is a suggested recipe. Match the Surface panel's native resolution (read it from `hyprctl monitors`).

---

## 5. Tweaking colors and fonts

### Colors - TUI side

1. Edit the constant in `myday/palette.py`.
2. Edit the same hex in `myday/theme.tcss` (search-and-replace the old hex).
3. Relaunch `myday`. No build step - Textual reads the CSS at startup.

### Colors - Omarchy side

1. Edit `omarchy/themes/krishadmin/colors.toml` (accent + `color0..color15`). On template-based Omarchy builds this alone re-themes every app.
2. On older builds, also edit the specific per-app file (e.g. `waybar.css`, `hyprland.conf`, `alacritty.toml`).
3. Re-apply: `omarchy-theme-set krishadmin`.

### Fonts - TUI side

The TUI uses whatever font your terminal renders. Set your terminal's font (see below); Textual has no font of its own. Keep a Nerd Font if you want the glyphs (mood emojis fall back to ASCII in `palette.py` via `MOOD_ASCII`).

### Fonts - Omarchy side

Set the terminal font in `omarchy/themes/krishadmin/alacritty.toml` (`[font] normal.family = "..."`, `size = ...`), and the bar font in `waybar.css` (`font-family`). Omarchy's global font is usually set in `~/.config/omarchy/` config; a Nerd Font (e.g. `CaskaydiaMono Nerd Font`, `JetBrainsMono Nerd Font`) gives you icons in Waybar and the terminal. Re-apply the theme after changing.

---

## 6. Make another app match (mini-guide)

To bring a new app onto the krishadmin look, reuse the same hexes:

1. Background pure black `#000000`; surfaces/cards `#0c0e10`, raised `#14181b`; borders `#2a2f33`.
2. Primary accent (buttons, active states, links, focus rings) neon green `#20fd14`; dimmed/inactive `#12a00c`.
3. Text `#eeeeee`, secondary `#bebebe`, muted `#959595`.
4. Destructive/danger = maroon `#69021b` (hover/emphasis `#a4102f`); warnings amber `#e0b020`; info cyan `#3aa0c9`.
5. Font: a Nerd Font matching your terminal so icons render.

Concrete recipes:

- **Another Textual app**: copy `myday/theme.tcss` as a starting stylesheet and set `CSS_PATH` to it; import `myday/palette.py` for any Rich rendering.
- **A web app / site**: define CSS variables `--accent:#20fd14; --bg:#000; --glassBg:#0c0e10; --glassBorder:#2a2f33; --textOnGlass:#eeeeee; --danger:#69021b;` and build components against those.
- **A CLI/terminal tool**: point it at the same 16-color set in `omarchy/themes/krishadmin/colors.toml` (or your terminal's theme), so green is `color2`, maroon is `color1`, amber `color3`, cyan `color4`.
- **A new desktop component under Omarchy**: add a per-app config file to `omarchy/themes/krishadmin/` (or a template), reference the colors from `colors.toml`, then `omarchy-theme-set krishadmin` to deploy.

---

## Sources

- Omarchy - Making your own theme: https://learn.omacom.io/2/the-omarchy-manual/92/making-your-own-theme
- Omarchy theme system architecture: https://deepwiki.com/basecamp/omarchy/7.1-theme-system-architecture
- Omarchy theming docs (templates / colors.toml): https://github.com/omacom/omarchy/blob/quattro/docs/theming.md
- Omarchy manual (themes): https://learn.omacom.io/2/the-omarchy-manual/52/themes
- Repo files read for accuracy: `myday/palette.py`, `myday/theme.tcss`, `omarchy/themes/krishadmin/colors.toml`, `omarchy/themes/krishadmin/hyprland.conf`, `CONTRACT.md`, `install.sh`

> Unverified / flagged: `omarchy/apply-theme.sh` is referenced by `install.sh` but not present in every checkout; exact Omarchy version behavior (`colors.toml` templates vs per-app files) varies by release - the manual `cp` + `omarchy-theme-set` path is the safe default. No wallpaper-generator script ships yet; the ImageMagick recipe is a suggestion.
