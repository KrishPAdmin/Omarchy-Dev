# KEYBINDINGS.md

A cheat sheet for the MyDay planner keys plus the Omarchy / Hyprland desktop shortcuts and the touch on-screen-keyboard toggle.

## Table of contents

- [How to read this](#how-to-read-this)
- [1. MyDay: global keys](#1-myday-global-keys)
- [2. MyDay: view- and panel-specific keys](#2-myday-view--and-panel-specific-keys)
- [3. MyDay command-line subcommands](#3-myday-command-line-subcommands)
- [4. Omarchy / Hyprland desktop shortcuts](#4-omarchy--hyprland-desktop-shortcuts)
- [5. Touch: on-screen keyboard and gestures](#5-touch-on-screen-keyboard-and-gestures)
- [Sources](#sources)

---

## How to read this

The MyDay keys come straight from the app's `BINDINGS` (in `myday/app.py` and the individual screens/panels), so they are exact. The Omarchy/Hyprland keys are the defaults for Omarchy 3.x and can vary by version - your machine's live, authoritative list is always **`SUPER + K`**. The touch toggles are whatever you bound during touchscreen setup (see TOUCHSCREEN.md); the values below are the kit's suggested bindings.

---

## 1. MyDay: global keys

Available from anywhere in the planner (defined in `MyDayApp.BINDINGS`):

| Key | Action |
| --- | --- |
| `q` | Quit |
| `Left` / `h` | Previous day/period (steps by the active view's unit) |
| `Right` / `l` | Next day/period |
| `t` | Jump to today |
| `g` | Go to a specific date (opens a date prompt) |
| `d` | Day view |
| `w` | Week view |
| `m` | Month view |
| `y` | Year view |
| `p` | Plan view |
| `Tab` | Cycle to next view |
| `Shift + Tab` | Cycle to previous view |
| `s` | Open the screensaver now |
| `r` | Refresh the current view |
| `?` | Help (key overview) |

The prev/next step follows the view: Day steps a day, Week steps a week, Month a month, Year a year.

---

## 2. MyDay: view- and panel-specific keys

These are active only when that view or panel is focused (in addition to the global keys above).

### Day view (`myday/screens/day.py`)

| Key | Action |
| --- | --- |
| `n` | New schedule block |
| `e` | Edit the focused block |

### Plan view (`myday/screens/plan.py`)

| Key | Action |
| --- | --- |
| `n` / `N` | Plan (add a planned item) |
| `e` | Edit the selected item |
| `x` / `Space` | Mark done / delete |
| `+` / `=` | Wider look-ahead horizon |
| `-` / `_` | Narrower look-ahead horizon |

### Food panel (`myday/panels/food.py`)

| Key | Action |
| --- | --- |
| `a` | Add a meal |
| `+` | Water + (add a cup) |
| `-` | Water - (remove a cup) |

### Fitness panel (`myday/panels/fitness.py`)

| Key | Action |
| --- | --- |
| `a` | Add a workout |

### Today, Week, Month, Year views

No extra local keys - navigate with the global keys in section 1 (arrows/`h`/`l` to move, `t` for today, `d/w/m/y/p` to switch views). Lists and tables use the standard Textual focus/scroll keys (`Up`/`Down`, `Enter` to activate, `Tab` to move focus). Everything is also tap-friendly: a touch tap equals a click.

---

## 3. MyDay command-line subcommands

Not keybindings, but the launch verbs (from `myday/__main__.py`):

| Command | What it starts |
| --- | --- |
| `myday` | The full planner (Today view) |
| `myday day` / `week` / `month` / `year` / `plan` | Start on a specific view |
| `myday widget` | Compact always-on status widget (small terminal) |
| `myday status` | Print one line of status (for waybar/tmux/scripts) |
| `myday screensaver` | Run the pixel screensaver standalone (preview/test) |
| `myday --version` | Version |
| `myday --help` | Usage |

---

## 4. Omarchy / Hyprland desktop shortcuts

Defaults for Omarchy 3.x. `SUPER` is the Windows/Command key. Press `SUPER + K` on your machine to see the live, current list (it is generated from your own config).

### Essentials

| Keys | Action |
| --- | --- |
| `SUPER + K` | Show the full keybinding cheat sheet (live) |
| `SUPER + Return` | Open a terminal |
| `SUPER + Space` | Application launcher (Walker) |
| `SUPER + Alt + Space` | Omarchy menu (system/control menu) |
| `SUPER + Escape` | System menu (lock, suspend, relaunch, restart) |

### Windows

| Keys | Action |
| --- | --- |
| `SUPER + W` | Close the focused window |
| `SUPER + T` | Toggle tiling / floating |
| `SUPER + F` | Fullscreen |
| `SUPER + J` | Toggle split orientation (horizontal/vertical) |
| `SUPER + Arrows` | Move focus between windows |

### Workspaces

| Keys | Action |
| --- | --- |
| `SUPER + 1..9` | Switch to workspace N |
| `SUPER + Shift + 1..9` | Move the focused window to workspace N |
| `SUPER + Tab` | Next workspace |
| `SUPER + Shift + Tab` | Previous workspace |

### Launch common apps

| Keys | Action |
| --- | --- |
| `SUPER + Shift + Return` | Web browser |
| `SUPER + Shift + F` | File manager |
| `SUPER + Shift + N` | Editor (Neovim) |

### System controls, clipboard, capture

| Keys | Action |
| --- | --- |
| `SUPER + Ctrl + W` | WiFi / network menu |
| `SUPER + Ctrl + A` | Audio controls |
| `SUPER + Ctrl + E` | Emoji picker (to clipboard) |
| `SUPER + C` / `SUPER + V` | Copy / paste (unified across terminal and apps) |
| `Print` | Screenshot |
| `Alt + Print` | Screen recording (toggle start/stop) |

> Version caveat: some Omarchy releases swap `SUPER + Space` and `SUPER + Alt + Space` (launcher vs menu), and newer builds moved binding config from `~/.config/hypr/bindings.conf` to `bindings.lua`. Trust `SUPER + K` over any printed sheet. Modifier logic to guess the rest: SUPER acts, SHIFT moves or launches, CTRL is system, ALT is the variant.

Restart the compositor after config changes: `SUPER + Escape` then choose **Relaunch**.

---

## 5. Touch: on-screen keyboard and gestures

These are the kit's suggested bindings from the touchscreen setup (TOUCHSCREEN.md). Adjust in `~/.config/hypr/bindings.conf`.

| Input | Action |
| --- | --- |
| `SUPER + O` | Toggle the on-screen keyboard (`wvkbd`) |
| Edge swipe up from the bottom | Toggle the on-screen keyboard (via hyprgrass) |
| 3-finger swipe left / right | Move across workspaces (via hyprgrass) |
| Tap | Click (works everywhere, including MyDay buttons and blocks) |

Under the hood the keyboard toggle sends a signal to wvkbd:

```bash
pkill -RTMIN -x wvkbd-mobintl   # show/hide the on-screen keyboard
```

> These are configured by you during setup, not Omarchy defaults - if `SUPER + O` does nothing, confirm `wvkbd-mobintl` is running (`pgrep -a wvkbd`) and the bind exists in your Hyprland config.

---

## Sources

- Repo files read for accuracy: `myday/app.py`, `myday/screens/day.py`, `myday/screens/plan.py`, `myday/panels/food.py`, `myday/panels/fitness.py`, `myday/__main__.py`, `CONTRACT.md`
- Omarchy manual - Hotkeys: https://learn.omacom.io/2/the-omarchy-manual/53/hotkeys
- Omarchy keybindings reference (DeepWiki): https://deepwiki.com/basecamp/omarchy/4.3-keybindings-reference
- Omarchy hotkeys cheat sheet (Acrogenesis): https://acrogenesis.com/omarchy-cheat-sheet/
- hyprgrass (touch gestures): https://github.com/horriblename/hyprgrass
- wvkbd (on-screen keyboard): https://git.sr.ht/~proycon/wvkbd

> Unverified / flagged: Omarchy default shortcuts vary by version (3.x assumed); `SUPER + K` is the source of truth on the actual machine. The touch/OSK binds are the kit's suggested values, not shipped Omarchy defaults.
