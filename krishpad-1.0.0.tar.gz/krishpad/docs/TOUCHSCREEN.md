# TOUCHSCREEN.md

Get the Microsoft Surface touchscreen, pen, and trackpad working on Arch / Omarchy (Hyprland), plus an on-screen keyboard and touch gestures, using the MyDay laptop kit scripts.

## Table of contents

- [Why this doc exists](#why-this-doc-exists)
- [0. Identify your exact Surface model first](#0-identify-your-exact-surface-model-first)
- [1. What the linux-surface project gives you](#1-what-the-linux-surface-project-gives-you)
- [2. Step-by-step: install the surface kernel + iptsd](#2-step-by-step-install-the-surface-kernel--iptsd)
- [3. Manual follow-ups (initramfs, bootloader, reboot)](#3-manual-follow-ups-initramfs-bootloader-reboot)
- [4. Secure Boot / MOK enrollment](#4-secure-boot--mok-enrollment)
- [5. Wire touch into Hyprland (gestures + on-screen keyboard)](#5-wire-touch-into-hyprland-gestures--on-screen-keyboard)
- [6. Verify touch, pen, and trackpad](#6-verify-touch-pen-and-trackpad)
- [7. Calibration (only if touch is inaccurate)](#7-calibration-only-if-touch-is-inaccurate)
- [8. Troubleshooting table](#8-troubleshooting-table)
- [Sources](#sources)

---

## Why this doc exists

Arch does not ship Surface-specific drivers by default. Touch, pen, the cameras, and some sensors need the community `linux-surface` kernel patches plus the `iptsd` userspace daemon. On Wayland/Hyprland you then need one more layer to make touch actually useful: gestures (`hyprgrass`) and an on-screen keyboard (`wvkbd`). This doc takes you from a stock Omarchy install to a working touch laptop.

> Status note: the kit scripts referenced below (`scripts/surface-touch-setup.sh`, `scripts/touch-hyprland.sh`) automate the repeatable parts. If a script is not present in your copy of the repo yet, follow the equivalent manual commands in the same section - they are the exact commands the script runs.

---

## 0. Identify your exact Surface model first

Everything downstream (which firmware package, whether you even need the custom kernel, calibration quirks) depends on the model. Read it from the firmware tables with `dmidecode`:

```bash
# Product name (e.g. "Surface Laptop 5", "Surface Pro 9")
sudo dmidecode -s system-product-name

# Full system block: vendor, product, version, serial, SKU
sudo dmidecode -t system

# Baseboard + BIOS/UEFI version (handy when checking firmware bugs)
sudo dmidecode -t baseboard -t bios
```

Also capture the touch controller so you know which stack you are on:

```bash
# Intel IPTS (older) vs ITHC (newer) touch host controller
lspci -nn | grep -Ei 'touch|ithc|ipts' || true
# Surface aggregator / platform (present on most modern Surface)
dmesg | grep -i -E 'surface|ipts|ithc' | head
```

Write the product name down. The rest of this doc says "your model" - substitute what `dmidecode` printed.

> Newer Surface devices on recent mainline kernels (6.11+) already carry many Surface patches, so single-touch may work before you install anything. Full multitouch, pen pressure, and cameras still need the `linux-surface` kernel plus `iptsd`. (Unverified for your specific unit until you test - see Step 6.)

---

## 1. What the linux-surface project gives you

| Piece | Package | What it does |
| --- | --- | --- |
| Patched kernel | `linux-surface`, `linux-surface-headers` | Surface drivers (touch host controller, aggregator, sensors, cameras) |
| Touch daemon | `iptsd` | Userspace daemon that turns raw IPTS/ITHC data into multitouch + pen events |
| Base firmware | `linux-firmware` | GPU/WiFi/BT firmware blobs |
| WiFi firmware (some models) | `linux-firmware-marvell` | Needed on Surface Pro 4/5/6, Book 1/2, Laptop 1/2 |
| CPU microcode | `intel-microcode` | Avoids boot issues on Intel Surface devices |
| Pen tablet data (optional) | `libwacom-surface` (AUR) | Correct stylus mapping in libwacom-aware apps |
| Secure Boot key | `linux-surface-secureboot-mok` | Enrolls the key the surface kernel is signed with (see Step 4) |

`iptsd` is the load-bearing part for the screen: no `iptsd`, no multitouch.

---

## 2. Step-by-step: install the surface kernel + iptsd

Run `scripts/surface-touch-setup.sh` if it is present (it does confirm-gated versions of all of the below and is idempotent). The install wrapper also offers this as `install.sh --touch`. The manual equivalent:

```bash
# a) Import and locally sign the linux-surface package signing key
curl -s https://raw.githubusercontent.com/linux-surface/linux-surface/master/pkg/keys/surface.asc \
  | sudo pacman-key --add -
# Verify the fingerprint against the wiki, then locally sign it:
sudo pacman-key --finger 56C464BAAC421453   # confirm it matches the wiki, then:
sudo pacman-key --lsign-key 56C464BAAC421453
```

> Verify the exact key ID/fingerprint on the linux-surface wiki before signing - do not trust the value above blindly (flagged as possibly-stale).

```bash
# b) Add the linux-surface repo to /etc/pacman.conf (append this block):
#   [linux-surface]
#   Server = https://pkg.surfacelinux.com/arch/
# Then refresh:
sudo pacman -Syu

# c) Install the kernel, headers, touch daemon, and camera libs
sudo pacman -S linux-surface linux-surface-headers iptsd libcamera libcamera-tools

# d) Firmware + microcode
sudo pacman -S linux-firmware intel-microcode
# Only if your model needs it (Pro 4/5/6, Book 1/2, Laptop 1/2):
sudo pacman -S linux-firmware-marvell

# e) Enable the touch daemon (templated per hidraw device; the wildcard is fine)
sudo systemctl enable 'iptsd@*'
```

Optional stylus mapping from the AUR:

```bash
# with your AUR helper of choice, e.g. yay/paru
paru -S libwacom-surface
```

---

## 3. Manual follow-ups (initramfs, bootloader, reboot)

Installing the kernel package usually regenerates the initramfs and adds a boot entry automatically, but on a fresh Arch/Omarchy box you should confirm both by hand.

### 3a. Regenerate the initramfs

```bash
# mkinitcpio-based systems (Arch default):
sudo mkinitcpio -P                 # -P = all presets, including linux-surface

# If your Omarchy build uses the newer unified-kernel / dracut path instead:
sudo dracut --regenerate-all --force
```

### 3b. Make the bootloader offer the surface kernel

Omarchy 3.x installs boot with **Limine**. Older or custom setups may use **systemd-boot** or **GRUB**. Pick your bootloader:

Limine (Omarchy default):
```bash
# Omarchy manages limine entries; after installing a new kernel, refresh them:
sudo limine-update 2>/dev/null || sudo limine-mkconfig -o /boot/limine.conf
# Then confirm an entry mentioning "surface" exists:
grep -i surface /boot/limine.conf
```

systemd-boot:
```bash
# Entries live here; a linux-surface entry should have been created:
ls /boot/loader/entries/
grep -ri surface /boot/loader/entries/
# Make it the default (optional) by name shown above:
sudo bootctl set-default 'arch-surface.conf'   # substitute the real filename
```

GRUB:
```bash
sudo grub-mkconfig -o /boot/grub/grub.cfg
grep -i surface /boot/grub/grub.cfg
```

### 3c. Reboot and confirm you are on the surface kernel

```bash
sudo reboot
# after login:
uname -a          # the string must contain "surface"
```

If `uname -a` does not say `surface`, you booted the wrong kernel - reboot and pick the surface entry in the boot menu (Limine/systemd-boot show a menu; hold or tap the menu key at power-on if it is hidden).

> The bootloader picker is the single most common failure. Touch will silently not work if you are on the stock `linux` kernel. Always check `uname -a` first.

---

## 4. Secure Boot / MOK enrollment

If Secure Boot is **off** (common for a personal Arch laptop), skip this section. Check with:

```bash
mokutil --sb-state    # "SecureBoot enabled" or "disabled"
```

If Secure Boot is **on**, the surface kernel must be trusted or it will not boot. The linux-surface project ships an automated enroller:

```bash
# Secure Boot must already be ENABLED when you install this package
sudo pacman -S linux-surface-secureboot-mok
sudo reboot
```

On reboot a blue **MokManager** screen appears. Choose **Enroll key** (or **Enroll MOK -> Continue**), confirm, and if prompted enter the one-time password the package set. The machine reboots once more and the surface kernel is now bootable under Secure Boot.

Manual fallback (if you have your own key/shim setup):

```bash
sudo mokutil --import /path/to/surface.cer   # set a temporary password
sudo reboot                                  # complete "Enroll key" in MokManager
```

> The linux-surface Secure Boot flow is **shim-based**. It does not configure your bootloader to pick the surface kernel for you - that is Step 3b. Do both.

---

## 5. Wire touch into Hyprland (gestures + on-screen keyboard)

Hyprland handles raw touch out of the box (a tap is a click, so MyDay and other apps are usable by finger immediately once Step 2-3 are done). To add swipe gestures and a typing surface, run `scripts/touch-hyprland.sh` if present, or do it manually:

### 5a. On-screen keyboard: wvkbd

```bash
sudo pacman -S wvkbd 2>/dev/null || paru -S wvkbd   # AUR on some setups
```

`wvkbd-mobintl` is the binary. Bind a toggle in `~/.config/hypr/bindings.conf` (Omarchy) so you can summon/dismiss it by touch or key. wvkbd hides/shows on `SIGUSR2`/`SIGUSR1` and toggles on `SIGRTMIN`:

```conf
# ~/.config/hypr/bindings.conf  (or bindings.lua on newer Omarchy)
# Launch it once, hidden, at login:
exec-once = wvkbd-mobintl -L 260 --hidden
# SUPER + O toggles the keyboard:
bind = SUPER, O, exec, pkill -RTMIN -x wvkbd-mobintl
```

`-L 260` sets landscape height in pixels; tune to taste. For a bigger desktop-style layout build/run `wvkbd-deskintl` instead.

### 5b. Touch gestures: hyprgrass

`hyprgrass` is a Hyprland plugin, installed through Hyprland's own plugin manager `hyprpm`:

```bash
hyprpm update                                   # build headers for your Hyprland
hyprpm add https://github.com/horriblename/hyprgrass
hyprpm enable hyprgrass
```

Load it at startup and add a couple of gestures in your Hyprland config:

```conf
# load plugins on login
exec-once = hyprpm reload -n

plugin {
    touch_gestures {
        sensitivity = 4.0
        # 3-finger swipe left/right = move across workspaces
        # (workspace swipe is built in; add custom binds like:)
        hyprgrass-bind = , swipe:3:l, workspace, +1
        hyprgrass-bind = , swipe:3:r, workspace, -1
        # edge swipe up from the bottom = toggle the on-screen keyboard
        hyprgrass-bind = , edge:d:u, exec, pkill -RTMIN -x wvkbd-mobintl
    }
}
```

> Caution: keep a physical keyboard attached the first time you enable `hyprgrass`. It is alpha software and has historically had bugs that can wedge the touch device until the plugin is unloaded. If touch dies, `hyprpm disable hyprgrass` and reload.

---

## 6. Verify touch, pen, and trackpad

Confirm the kernel actually sees the devices:

```bash
# You must be in a Wayland session for native touch (Hyprland is Wayland):
echo "$XDG_SESSION_TYPE"          # expect: wayland

# List every input device libinput knows about:
sudo libinput list-devices | less
#   look for a "Touchscreen" capability, a "Tablet" (the pen), and "Touchpad"
```

Watch live events from a specific device (Ctrl-C to stop):

```bash
sudo evtest
#   pick the number next to the touchscreen; touch the panel and watch ABS_MT_* events.
#   repeat for the pen (Wacom/IPTS stylus) and the touchpad.
```

Quick functional checks:
- Touch: open `myday` and tap a schedule block or a Today panel button - a tap is a click.
- Pen: hover and press in any drawing-capable app; pressure should register in `evtest` as `ABS_PRESSURE`.
- Trackpad: two-finger scroll and click should work with no extra setup on the surface kernel.

---

## 7. Calibration (only if touch is inaccurate)

Do this only if taps land off-target. Use the `iptsd` calibrator, not the old `xinput_calibrator` (which does not work with IPTS/ITHC):

```bash
sudo systemctl stop 'iptsd@*.service'
sudo iptsd-calibrate "$(sudo iptsd-find-hidraw)"
# follow the prompts: touch each corner/center with different pressures
sudo systemctl start 'iptsd@*.service'
```

---

## 8. Troubleshooting table

| Symptom | Likely cause | Fix |
| --- | --- | --- |
| Touch not detected at all | Booted the stock kernel, not surface | `uname -a` must contain `surface`; reboot and pick the surface entry (Step 3b/3c) |
| `libinput list-devices` shows no touchscreen | `iptsd` not running, or wrong kernel | `systemctl status 'iptsd@*'`; enable with `sudo systemctl enable --now 'iptsd@*'` |
| Kernel is right but still no multitouch | `iptsd` not installed / not enabled | `sudo pacman -S iptsd` then enable the template unit |
| Touch works, but on the wrong screen (external monitor) | Compositor mapped touch to the wrong output | Map it: `hyprctl keyword device[<touch-device-name>]:output eDP-1` (use the internal panel name from `hyprctl monitors`); persist in hyprland config |
| Cursor jumps / random taps (ghost touch) | Known on some older units (e.g. Pro 4) | Recalibrate (Step 7); as a last resort remove `iptsd` to fall back to single-touch |
| Palm triggers taps while using the pen | Palm rejection off / stylus not recognized as tablet | Ensure `libwacom-surface` is installed; iptsd does palm rejection when the pen is active - confirm the pen shows as a `Tablet` in `libinput list-devices` |
| On-screen keyboard never shows | wvkbd not launched, or toggle signal wrong | Start `wvkbd-mobintl -L 260 --hidden`; toggle with `pkill -RTMIN -x wvkbd-mobintl`; check it is running with `pgrep -a wvkbd` |
| Keyboard shows but hidden behind lock screen | hyprlock draws above wvkbd | Known limitation; type the password on the physical keyboard, or see hyprlock keyboard-overlay workarounds |
| Gestures do nothing | hyprgrass not loaded | `hyprpm list` should show it enabled; add `exec-once = hyprpm reload -n`; rebuild with `hyprpm update` after Hyprland upgrades |
| Touch device wedged after enabling gestures | hyprgrass alpha bug | `hyprpm disable hyprgrass` from the physical keyboard, reload Hyprland |
| Secure Boot blocks the surface kernel | MOK key not enrolled | Step 4: install `linux-surface-secureboot-mok`, reboot, Enroll key in MokManager |
| No boot menu appears to pick the kernel | Menu hidden by bootloader | Limine/systemd-boot: tap the menu/arrow key at power-on; set the surface kernel as default (Step 3b) |

---

## Sources

- linux-surface Installation and Setup wiki: https://github.com/linux-surface/linux-surface/wiki/Installation-and-Setup
- linux-surface Secure Boot wiki: https://github.com/linux-surface/linux-surface/wiki/Secure-Boot
- iptsd (touch/pen daemon) and calibration: https://github.com/linux-surface/iptsd
- hyprgrass (Hyprland touch gestures): https://github.com/horriblename/hyprgrass
- hyprgrass configuration reference: https://github.com/horriblename/hyprgrass/blob/main/docs/configuration.md
- wvkbd (wlroots on-screen keyboard): https://git.sr.ht/~proycon/wvkbd
- Arch on Surface with Secure Boot (worked example): https://chrismcleod.dev/blog/installing-arch-linux-with-secure-boot-on-a-microsoft-surface-laptop-studio/
- Omarchy manual (bootloader/Hyprland context): https://learn.omacom.io/2/the-omarchy-manual

> Unverified / flag for your machine: exact `linux-surface` signing-key fingerprint (confirm on the wiki), whether your specific model needs the custom kernel at all, the exact bootloader on your Omarchy build (Limine vs systemd-boot), and the real filenames of boot entries. The kit scripts `scripts/surface-touch-setup.sh` and `scripts/touch-hyprland.sh` may not be present in every checkout yet; the manual commands above are the fallback.
