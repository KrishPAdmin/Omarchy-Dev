# MyDay / krishpad install guide

Everything you need to get MyDay running on your Omarchy (Arch/Hyprland)
laptop, plus manual fallbacks and troubleshooting.

## Contents

1. [Summary](#summary)
2. [Prerequisites](#prerequisites)
3. [Copying the bundle to the laptop](#copying-the-bundle-to-the-laptop)
4. [Installing](#installing)
5. [install.sh flags](#installsh-flags)
6. [Manual install (fallback)](#manual-install-fallback)
7. [Updating](#updating)
8. [Uninstalling](#uninstalling)
9. [Troubleshooting](#troubleshooting)

## Summary

`install.sh` creates an isolated Python venv at
`~/.local/share/myday/venv`, installs `textual>=8,<9` into it, copies the
`myday` package to `~/.local/share/myday/app`, and writes a `myday` launcher
to `~/.local/bin`. Your data lives in `~/.local/share/myday/planner.db` and is
never touched by install or uninstall. The core install is safe to re-run and
backs up anything it replaces. Optional flags apply the Omarchy extras.

Fast path:

```bash
cd ~/krishpad
./install.sh          # core planner
./install.sh --all    # + theme, waybar, autostart
myday                 # launch
```

## Prerequisites

- **OS**: Omarchy or Arch (Hyprland) for the full experience. The planner runs
  on any Linux; use `--force` to install off Arch.
- **Python 3.11 or newer**. Check with `python3 --version`. On Arch:
  `sudo pacman -S python`.
- **venv support**. Bundled with CPython on Arch. On Debian/Ubuntu-like systems
  you would need `python3-venv`.
- **Network** for the one-time `textual` download, or a local wheel / internal
  index if you are offline (see troubleshooting).
- Roughly 60 MB of disk for the venv.

No root is required for the core install; everything lands under your home
directory. Some extras (`--touch`, `--screen-off-never`) may prompt for sudo
inside their own scripts.

## Copying the bundle to the laptop

krishpad is not on GitHub; you copy the folder over. Pick whichever is easiest.

**scp** (laptop reachable over SSH):

```bash
scp -r krishpad krishadmin@LAPTOP_IP:~/
```

**tar + copy** (smaller, preserves permissions):

```bash
# on the build machine
tar czf krishpad.tar.gz krishpad
# move krishpad.tar.gz across (scp / rsync / cloud), then on the laptop:
tar xzf krishpad.tar.gz
```

**USB stick**:

```bash
# copy the krishpad folder onto the stick, then on the laptop:
cp -r /run/media/USER/STICK/krishpad ~/
chmod +x ~/krishpad/install.sh ~/krishpad/uninstall.sh
```

After copying, make sure the scripts are executable
(`chmod +x install.sh uninstall.sh`); this is only needed if the copy method
dropped the executable bit.

## Installing

```bash
cd ~/krishpad
./install.sh
```

You will see the detected OS and Python, the venv being created, textual being
installed, the package copied, and a launcher written. At the end it prints a
"next steps" summary. Re-running is safe and idempotent.

If `~/.local/bin` is not on your PATH the installer tells you exactly what to
add to your shell rc (`.bashrc` / `.zshrc`) and how to reload it. Until then you
can launch with the full path `~/.local/bin/myday`.

Preview without changing anything:

```bash
./install.sh --dry-run
```

## install.sh flags

| Flag                 | Effect                                                                 |
| -------------------- | ---------------------------------------------------------------------- |
| (none)               | Install the core planner: venv + textual + package copy + launcher.    |
| `--theme`            | Apply the krishadmin Omarchy theme (`omarchy/apply-theme.sh`).         |
| `--autostart`        | Autostart dashboard + widget on login (`scripts/myday-autostart.sh --dashboard --widget`). |
| `--waybar`           | Install the waybar config/module from `omarchy/waybar`.                |
| `--screen-off-never` | Disable display power-off / DPMS (`scripts/screen-off-never.sh --never`). |
| `--touch`            | Surface touchscreen setup (`scripts/surface-touch-setup.sh`). Touches kernel modules, so it asks for an explicit extra confirmation. |
| `--all`              | Shorthand for `--theme --autostart --waybar`. Does **not** include `--touch` or `--screen-off-never`. |
| `--force`            | Continue even if the system is not detected as Arch/Omarchy.           |
| `--dry-run`          | Print every action without making any change.                          |
| `--uninstall`        | Hand off to `uninstall.sh`.                                            |
| `-h`, `--help`       | Full help text.                                                        |

Notes:

- The installer never reboots and never auto-enables the kernel-level extras;
  `--touch` and `--screen-off-never` are opt-in only.
- Each extra defensively checks that its script exists and, if missing, warns
  and continues rather than failing the whole install.
- Flags compose, e.g. `./install.sh --all --screen-off-never`.

## Manual install (fallback)

If you prefer not to use `install.sh`, or you are debugging it, the same result
by hand:

```bash
# 1. venv
python3 -m venv ~/.local/share/myday/venv

# 2. dependency (pinned)
~/.local/share/myday/venv/bin/python -m pip install 'textual>=8,<9'

# 3. package copy
mkdir -p ~/.local/share/myday/app
cp -a ~/krishpad/myday ~/.local/share/myday/app/

# 4. launcher
cat > ~/.local/bin/myday <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
export PYTHONPATH="$HOME/.local/share/myday/app${PYTHONPATH:+:$PYTHONPATH}"
exec "$HOME/.local/share/myday/venv/bin/python" -m myday "$@"
EOF
chmod +x ~/.local/bin/myday
```

Alternatively, install the package into the venv with pip using the bundled
`pyproject.toml` (this also creates the `myday` console script inside the venv):

```bash
python3 -m venv ~/.local/share/myday/venv
~/.local/share/myday/venv/bin/python -m pip install ~/krishpad
ln -sf ~/.local/share/myday/venv/bin/myday ~/.local/bin/myday
```

You can also skip installing entirely and use the portable launcher template
`bin/myday` from the bundle (symlink it onto your PATH); it will use the venv if
present and otherwise run straight from the bundle with a system python3.

## Updating

To update after pulling / copying a newer bundle, just re-run the installer:

```bash
cd ~/krishpad
./install.sh
```

It reuses the existing venv, refreshes the package copy (backing up the old one
as `myday.bak-<timestamp>`, keeping the two most recent), and rewrites the
launcher. Your database is untouched. To force a clean rebuild, uninstall first
(without `--purge`) and install again.

## Uninstalling

```bash
cd ~/krishpad
./uninstall.sh            # removes venv, app copy, launcher; KEEPS your data
./uninstall.sh --purge    # also deletes ~/.local/share/myday/planner.db
./uninstall.sh --dry-run  # preview
./uninstall.sh --yes      # no prompts
```

The uninstaller also offers to remove MyDay autostart entries if it finds them.
Your planner database is preserved unless you pass `--purge` and confirm.

## Troubleshooting

**`myday: command not found`** - `~/.local/bin` is not on your PATH. Add it:

```bash
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc   # or ~/.zshrc
source ~/.bashrc
```

Or launch with the full path: `~/.local/bin/myday`.

**Python too old / not found** - MyDay needs Python 3.11+. Install a newer
Python (`sudo pacman -S python` on Arch) and re-run `./install.sh`. The
installer searches `python3.14 ... python3.11` and picks the first that
qualifies.

**venv creation fails** - ensure Python's venv module is available. On Arch it
ships with `python`; on Debian-like systems install `python3-venv`.

**textual will not install (offline)** - the installer detects a no-index
situation and prints options. Either connect to a network and re-run, or install
a wheel manually:

```bash
~/.local/share/myday/venv/bin/python -m pip install /path/to/textual-8.*.whl
```

or point pip at an internal index:

```bash
~/.local/share/myday/venv/bin/python -m pip install --index-url <URL> 'textual>=8,<9'
```

`textual` pulls in `rich` and `markdown-it-py`; on a fully air-gapped box copy
those wheels across too (pip will name any missing ones).

**Permission denied running the script** - the copy dropped the executable bit:
`chmod +x install.sh uninstall.sh`. You can always run via `bash install.sh`.

**Not detected as Arch/Omarchy** - the planner runs anywhere; add `--force` to
install off Arch. The Omarchy extras are tuned for Hyprland and may not apply on
other desktops.

**An extra (`--theme`, `--waybar`, ...) is skipped** - its script was not found
in the bundle. Confirm the relevant file exists under `omarchy/` or `scripts/`.
The core planner install is unaffected.

**Colors / rendering look off** - use a truecolor terminal (Alacritty, Kitty,
Ghostty, foot). MyDay is designed for a 24-bit neon-green-on-black palette.

**Health check** - run `scripts/doctor.sh` for an environment report
(Python, venv, launcher, PATH, terminal, and extras status).
