#!/usr/bin/env bash
#
# krishpad / MyDay uninstaller
# ----------------------------
# Removes the MyDay venv, installed package copy and launcher. By default your
# planner database is KEPT so a later reinstall picks up right where you left
# off. Pass --purge to delete the database too.
#
set -euo pipefail

BUNDLE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_HOME="${HOME}/.local/share/myday"
APP_DIR="${APP_HOME}/app"
VENV_DIR="${APP_HOME}/venv"
DB_PATH="${APP_HOME}/planner.db"
LAUNCHER="${HOME}/.local/bin/myday"

PURGE=0
DRY_RUN=0
ASSUME_YES=0

if [[ -t 1 ]]; then
  C_G=$'\033[38;2;32;253;20m'; C_Y=$'\033[33m'; C_R=$'\033[31m'
  C_B=$'\033[1m'; C_D=$'\033[2m'; C_0=$'\033[0m'
else
  C_G=""; C_Y=""; C_R=""; C_B=""; C_D=""; C_0=""
fi
info() { printf '%s==>%s %s\n' "$C_G" "$C_0" "$*"; }
step() { printf '  %s-%s %s\n' "$C_D" "$C_0" "$*"; }
warn() { printf '%swarning:%s %s\n' "$C_Y" "$C_0" "$*" >&2; }
err()  { printf '%serror:%s %s\n' "$C_R" "$C_0" "$*" >&2; }

usage() {
  cat <<EOF
${C_B}krishpad / MyDay uninstaller${C_0}

USAGE
  ./uninstall.sh [options]

OPTIONS
  --purge     Also delete your planner database (${DB_PATH}).
              WITHOUT this flag your data is preserved.
  --yes, -y   Do not prompt for confirmation.
  --dry-run   Print what would be removed without deleting anything.
  -h, --help  Show this help and exit.

Removes:
  ${VENV_DIR}
  ${APP_DIR}
  ${LAUNCHER}   (and any *.bak-* copies)
Also offers to remove MyDay autostart entries if present.
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --purge)     PURGE=1 ;;
    -y|--yes)    ASSUME_YES=1 ;;
    --dry-run)   DRY_RUN=1 ;;
    -h|--help)   usage; exit 0 ;;
    *) err "unknown option: $1"; echo; usage; exit 2 ;;
  esac
  shift
done

run() {
  if [[ "$DRY_RUN" -eq 1 ]]; then
    printf '  %s[dry-run]%s %s\n' "$C_D" "$C_0" "$*"
    return 0
  fi
  "$@"
}

confirm() {
  # confirm "question"  -> 0 if yes
  [[ "$ASSUME_YES" -eq 1 ]] && return 0
  local ans=""
  printf '%s [y/N] ' "$1"
  read -r ans || ans=""
  case "$ans" in y|Y|yes|YES) return 0 ;; *) return 1 ;; esac
}

info "krishpad / MyDay uninstaller"
[[ "$DRY_RUN" -eq 1 ]] && warn "dry-run: nothing will be deleted"

if [[ ! -d "$APP_HOME" && ! -e "$LAUNCHER" ]]; then
  warn "MyDay does not appear to be installed (no ${APP_HOME}, no ${LAUNCHER})."
  exit 0
fi

if ! confirm "Remove MyDay (venv, app copy, launcher)?"; then
  step "aborted by user"
  exit 0
fi

# Launcher + backups
if [[ -e "$LAUNCHER" || -n "$(ls -1 "${LAUNCHER}".bak-* 2>/dev/null || true)" ]]; then
  step "removing launcher ${LAUNCHER}"
  run rm -f "$LAUNCHER" "${LAUNCHER}".bak-* 2>/dev/null || true
fi

# venv
if [[ -d "$VENV_DIR" ]]; then
  step "removing venv ${VENV_DIR}"
  run rm -rf "$VENV_DIR"
fi

# app dir (package copy + backups)
if [[ -d "$APP_DIR" ]]; then
  step "removing app dir ${APP_DIR}"
  run rm -rf "$APP_DIR"
fi

# Autostart entries (best-effort; created by scripts/myday-autostart.sh)
AUTO_HYPR="${HOME}/.config/hypr/autostart-myday.conf"
AUTO_DESKTOPS=(
  "${HOME}/.config/autostart/myday-dashboard.desktop"
  "${HOME}/.config/autostart/myday-widget.desktop"
  "${HOME}/.config/autostart/myday.desktop"
)
_found_auto=0
[[ -e "$AUTO_HYPR" ]] && _found_auto=1
for d in "${AUTO_DESKTOPS[@]}"; do [[ -e "$d" ]] && _found_auto=1; done
# Also detect source lines injected into hyprland.conf
HYPR_CONF="${HOME}/.config/hypr/hyprland.conf"
_hypr_src=0
if [[ -f "$HYPR_CONF" ]] && grep -q "autostart-myday.conf" "$HYPR_CONF" 2>/dev/null; then
  _hypr_src=1; _found_auto=1
fi

if [[ "$_found_auto" -eq 1 ]]; then
  if confirm "Also remove MyDay autostart entries?"; then
    [[ -e "$AUTO_HYPR" ]] && { step "removing ${AUTO_HYPR}"; run rm -f "$AUTO_HYPR"; }
    for d in "${AUTO_DESKTOPS[@]}"; do
      [[ -e "$d" ]] && { step "removing ${d}"; run rm -f "$d"; }
    done
    if [[ "$_hypr_src" -eq 1 ]]; then
      step "commenting MyDay source line in ${HYPR_CONF}"
      if [[ "$DRY_RUN" -eq 0 ]]; then
        cp -p "$HYPR_CONF" "${HYPR_CONF}.bak-$(date +%Y%m%d-%H%M%S)" 2>/dev/null || true
        sed -i 's|^\(.*autostart-myday\.conf.*\)$|# [removed by myday uninstall] \1|' "$HYPR_CONF" || \
          warn "could not edit ${HYPR_CONF}; remove the autostart-myday.conf source line manually"
      fi
    fi
  else
    step "keeping autostart entries"
  fi
fi

# Database
if [[ "$PURGE" -eq 1 ]]; then
  if [[ -e "$DB_PATH" ]]; then
    if confirm "PURGE: permanently delete your planner database ${DB_PATH}?"; then
      step "deleting database ${DB_PATH}"
      run rm -f "$DB_PATH" "${DB_PATH}"-wal "${DB_PATH}"-shm 2>/dev/null || true
    else
      step "database kept"
    fi
  fi
  # If app home is now empty, remove it.
  if [[ -d "$APP_HOME" ]]; then
    run rmdir "$APP_HOME" 2>/dev/null || true
  fi
else
  if [[ -e "$DB_PATH" ]]; then
    step "keeping your database at ${DB_PATH} (use --purge to remove it)"
  fi
fi

info "MyDay uninstalled."
[[ "$DRY_RUN" -eq 1 ]] && warn "dry-run complete - nothing was changed"

exit 0
