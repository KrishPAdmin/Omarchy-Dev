-- krishadmin - Neovim colorscheme (Omarchy / LazyVim plugin spec)
-- Base: tokyonight-night, hard-overridden to pure-black backgrounds and
-- neon-green (#20fd14) accents so Neovim reads like krishadmin.com.
-- Omarchy loads this file as a LazyVim plugin spec from the current theme.

return {
  {
    "folke/tokyonight.nvim",
    lazy = false,
    priority = 1000,
    opts = {
      style = "night",
      transparent = false,
      terminal_colors = true,
      styles = {
        sidebars = "dark",
        floats = "dark",
      },
      -- Recolor the base palette toward black + brand green.
      on_colors = function(colors)
        colors.bg = "#000000"
        colors.bg_dark = "#000000"
        colors.bg_float = "#0c0e10"
        colors.bg_sidebar = "#0c0e10"
        colors.bg_statusline = "#0c0e10"
        colors.bg_popup = "#0c0e10"
        colors.bg_visual = "#14181b"
        colors.border = "#2a2f33"
        colors.fg = "#eeeeee"
        colors.fg_dark = "#bebebe"
        colors.fg_gutter = "#2a2f33"
        colors.comment = "#959595"
        colors.green = "#20fd14"
        colors.green1 = "#5cff52"
        colors.green2 = "#12a00c"
        colors.teal = "#2fd4c4"
        colors.red = "#a4102f"
        colors.red1 = "#69021b"
        colors.cyan = "#66e6d8"
      end,
      on_highlights = function(hl, c)
        hl.CursorLineNr = { fg = c.green, bold = true }
        hl.LineNr = { fg = "#3a4147" }
        hl.Visual = { bg = "#14181b" }
        hl.Cursor = { fg = "#000000", bg = c.green }
        hl.MatchParen = { fg = "#000000", bg = c.green, bold = true }
        hl.Pmenu = { fg = c.fg_dark, bg = "#0c0e10" }
        hl.PmenuSel = { fg = "#000000", bg = c.green }
        hl.Search = { fg = "#000000", bg = c.green }
        hl.IncSearch = { fg = "#000000", bg = "#5cff52" }
        hl.Function = { fg = c.green }
        hl.String = { fg = "#5cff52" }
        hl.StatusLine = { fg = c.green, bg = "#0c0e10" }
        hl.NormalFloat = { fg = c.fg, bg = "#0c0e10" }
        hl.FloatBorder = { fg = c.green, bg = "#0c0e10" }
        hl.WinSeparator = { fg = "#2a2f33" }
      end,
    },
  },
  {
    "LazyVim/LazyVim",
    opts = {
      colorscheme = "tokyonight-night",
    },
  },
}
