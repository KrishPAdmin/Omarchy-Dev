#!/usr/bin/env python3
"""png_wallpaper.py - pure-stdlib PNG renderer for the krishadmin wallpaper.

Fallback used by generate-wallpaper.sh when ImageMagick is unavailable. No
third-party deps (zlib + struct only), fully headless and reproducible: the
same size always yields byte-identical output.

Motif: pure-black canvas, faint neon-green dot grid, faint matrix streaks, and
a large lime block "K" bottom-right echoing krishadmin.com's LimeK.
"""
from __future__ import annotations

import argparse
import struct
import zlib

BLACK = (0, 0, 0)
GREEN = (0x20, 0xFD, 0x14)
DIMGREEN = (0x0A, 0x54, 0x06)


def blend(bg, fg, alpha):
    return tuple(int(round(b + (f - b) * alpha)) for b, f in zip(bg, fg))


def render(width: int, height: int) -> bytearray:
    # One RGB row buffer per line; build the whole framebuffer.
    row_bytes = width * 3
    buf = bytearray(BLACK[0:1] * 0)  # placeholder
    fb = bytearray(BLACK * width * height)

    def put(x, y, color):
        if 0 <= x < width and 0 <= y < height:
            i = (y * width + x) * 3
            fb[i], fb[i + 1], fb[i + 2] = color

    # Faint dot grid every 48px.
    step = 48
    dot = blend(BLACK, DIMGREEN, 0.5)
    for y in range(0, height, step):
        for x in range(0, width, step):
            put(x, y, dot)

    # Deterministic matrix streaks (LCG, no randomness -> reproducible).
    seed = 1234567
    def rnd(mod):
        nonlocal seed
        seed = (1103515245 * seed + 12345) & 0x7FFFFFFF
        return seed % mod

    for cx in range(0, width, 96):
        x = cx + rnd(40)
        y0 = rnd(height)
        length = 120 + rnd(600)
        for y in range(y0, min(y0 + length, height)):
            a = 0.30 * (1 - (y - y0) / length)
            i = (y * width + x) * 3
            cur = (fb[i], fb[i + 1], fb[i + 2])
            fb[i], fb[i + 1], fb[i + 2] = blend(cur, GREEN, a)

    # Large block "K" bottom-right, low opacity watermark.
    kh = int(height * 0.7)
    kw = int(kh * 0.62)
    thick = max(6, kw // 9)
    x0 = int(width - kw - width * 0.06)
    y0 = int(height - kh - height * 0.04)
    alpha = 0.12

    def vline(px, ya, yb):
        for yy in range(ya, yb):
            for xx in range(px, px + thick):
                _paint(fb, width, height, xx, yy, GREEN, alpha)

    # vertical stem
    vline(x0, y0, y0 + kh)

    mid_y = y0 + kh // 2
    # upper arm: from mid-stem up to the top-right corner.
    span_u = mid_y - y0
    for k in range(span_u):
        yy = y0 + k
        frac = k / span_u          # 0 at top, 1 at mid
        xx = int(x0 + thick + (1 - frac) * (kw - thick))
        for t in range(thick):
            _paint(fb, width, height, xx + t, yy, GREEN, alpha)
    # lower arm: from mid-stem down to the bottom-right corner.
    span_l = kh - kh // 2
    for k in range(span_l):
        yy = mid_y + k
        frac = k / span_l          # 0 at mid, 1 at bottom
        xx = int(x0 + thick + frac * (kw - thick))
        for t in range(thick):
            _paint(fb, width, height, xx + t, yy, GREEN, alpha)

    return _encode_png(width, height, fb)


def _paint(fb, width, height, x, y, color, alpha):
    if 0 <= x < width and 0 <= y < height:
        i = (y * width + x) * 3
        cur = (fb[i], fb[i + 1], fb[i + 2])
        fb[i], fb[i + 1], fb[i + 2] = blend(cur, color, alpha)


def _encode_png(width: int, height: int, fb: bytearray) -> bytearray:
    raw = bytearray()
    stride = width * 3
    for y in range(height):
        raw.append(0)  # filter type 0 (None)
        raw.extend(fb[y * stride:(y + 1) * stride])
    compressed = zlib.compress(bytes(raw), 9)

    def chunk(tag: bytes, data: bytes) -> bytes:
        return (struct.pack(">I", len(data)) + tag + data
                + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF))

    png = bytearray(b"\x89PNG\r\n\x1a\n")
    ihdr = struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)  # RGB, 8-bit
    png += chunk(b"IHDR", ihdr)
    png += chunk(b"IDAT", compressed)
    png += chunk(b"IEND", b"")
    return png


def main() -> int:
    ap = argparse.ArgumentParser(description="Render the krishadmin wallpaper (pure stdlib).")
    ap.add_argument("--out", required=True, help="Output PNG path")
    ap.add_argument("--size", default="2560x1440", help="WxH (default 2560x1440)")
    args = ap.parse_args()
    w, h = args.size.lower().split("x")
    width, height = int(w), int(h)
    png = render(width, height)
    with open(args.out, "wb") as fh:
        fh.write(png)
    print(f"wrote {args.out} ({width}x{height}, {len(png)} bytes)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
