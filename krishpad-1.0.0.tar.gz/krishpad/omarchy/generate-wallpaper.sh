#!/usr/bin/env bash
# generate-wallpaper.sh - render the krishadmin Omarchy wallpaper(s) with
# ImageMagick. Pure-black canvas, faint neon-green dot grid, a large lime "K"
# glyph bottom-right (echoing krishadmin.com's LimeK), and soft matrix streaks.
# Reproducible, headless, shellcheck-clean.

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)"
OUT_DIR="${SCRIPT_DIR}/themes/krishadmin/backgrounds"

WIDTH=3840
HEIGHT=2160
GREEN="#20fd14"
DIMGREEN="#0a5406"
BLACK="#000000"

usage() {
  cat <<'EOF'
Usage: generate-wallpaper.sh [--help] [--out DIR] [--size WxH]

Renders two 4K wallpapers into themes/krishadmin/backgrounds/:
  0-krishadmin-grid.png  - black + faint green dot grid + lime "K"
  1-krishadmin-matrix.png - black + soft vertical matrix streaks + lime "K"

Options:
  --out DIR    Output directory (default: themes/krishadmin/backgrounds)
  --size WxH   Canvas size (default: 3840x2160)
  --help       Show this help

Requires ImageMagick (the 'magick' or 'convert' command). If neither is
installed the script prints guidance and exits without failing your build.
EOF
}

# --- arg parsing -----------------------------------------------------------
while [[ $# -gt 0 ]]; do
  case "$1" in
    --help|-h) usage; exit 0 ;;
    --out) OUT_DIR="${2:?--out needs a directory}"; shift 2 ;;
    --size)
      SPEC="${2:?--size needs WxH}"
      WIDTH="${SPEC%x*}"
      HEIGHT="${SPEC#*x}"
      shift 2
      ;;
    *) echo "Unknown option: $1" >&2; usage >&2; exit 2 ;;
  esac
done

# --- locate ImageMagick ----------------------------------------------------
IM=""
if command -v magick >/dev/null 2>&1; then
  IM="magick"
elif command -v convert >/dev/null 2>&1; then
  IM="convert"
else
  echo "ImageMagick not found; falling back to the pure-Python renderer." >&2
  echo "  (For higher-fidelity 4K art install imagemagick and re-run.)" >&2
  if command -v python3 >/dev/null 2>&1; then
    mkdir -p "$OUT_DIR"
    python3 "${SCRIPT_DIR}/lib/png_wallpaper.py" \
      --out "${OUT_DIR}/0-krishadmin-grid.png" \
      --size "${WIDTH}x${HEIGHT}"
    echo "Done (python fallback):"
    echo "  ${OUT_DIR}/0-krishadmin-grid.png"
    exit 0
  fi
  cat <<'EOF' >&2
Neither ImageMagick nor python3 is available: cannot render wallpapers.
Install one, then re-run this script:
  Arch/Omarchy : sudo pacman -S imagemagick   (or use the bundled python3 path)
  Debian/Ubuntu: sudo apt-get install imagemagick
The theme still applies without a generated wallpaper (Omarchy falls back to
any existing background). This is not a build failure.
EOF
  exit 0
fi

mkdir -p "$OUT_DIR"

# ImageMagick 7 uses `magick`; on 6 the `convert` verb is the tool itself.
run() {
  if [[ "$IM" == "magick" ]]; then
    magick "$@"
  else
    convert "$@"
  fi
}

# "K" font point size and position, scaled to the canvas.
KPT=$(( HEIGHT * 9 / 10 ))
KX=$(( WIDTH * 62 / 100 ))
KY=$(( HEIGHT * 96 / 100 ))

GRID_OUT="${OUT_DIR}/0-krishadmin-grid.png"
MATRIX_OUT="${OUT_DIR}/1-krishadmin-matrix.png"

echo "Rendering ${WIDTH}x${HEIGHT} wallpapers into ${OUT_DIR} using '${IM}'..."

# --- wallpaper 1: dot grid + K --------------------------------------------
# Faint green dot every 64px via a tile pattern, a soft vignette-free glow,
# then the big lime K bottom-right at low opacity so it reads as a watermark.
run -size "${WIDTH}x${HEIGHT}" "xc:${BLACK}" \
  \( -size 64x64 "xc:${BLACK}" -fill "${DIMGREEN}" \
     -draw "point 1,1" -write mpr:dot +delete \) \
  \( -size "${WIDTH}x${HEIGHT}" "tile:mpr:dot" -channel A -evaluate multiply 0.5 +channel \) \
  -compose over -composite \
  -fill "${GREEN}" -stroke none \
  -font "$(fc-match -f '%{file}' 'Source Sans 3:bold' 2>/dev/null || echo Helvetica)" \
  -pointsize "${KPT}" -gravity SouthEast \
  -draw "fill-opacity 0.10 text $(( WIDTH * 4 / 100 )),$(( HEIGHT * 2 / 100 )) 'K'" \
  "${GRID_OUT}"

# --- wallpaper 2: matrix streaks + K --------------------------------------
# Random-length vertical green streaks fading downward, plus the K watermark.
STREAK_ARGS=()
COLS=$(( WIDTH / 96 ))
i=0
while [[ $i -lt $COLS ]]; do
  x=$(( i * 96 + (RANDOM % 40) ))
  y0=$(( RANDOM % HEIGHT ))
  len=$(( 120 + RANDOM % 600 ))
  y1=$(( y0 + len ))
  STREAK_ARGS+=( -stroke "${DIMGREEN}" -strokewidth 2 \
    -draw "stroke-opacity 0.35 line ${x},${y0} ${x},${y1}" \
    -stroke "${GREEN}" -strokewidth 2 \
    -draw "stroke-opacity 0.55 line ${x},${y1} ${x},$(( y1 + 8 ))" )
  i=$(( i + 1 ))
done

run -size "${WIDTH}x${HEIGHT}" "xc:${BLACK}" \
  "${STREAK_ARGS[@]}" \
  -blur 0x0.6 \
  -fill "${GREEN}" -stroke none \
  -font "$(fc-match -f '%{file}' 'Source Sans 3:bold' 2>/dev/null || echo Helvetica)" \
  -pointsize "${KPT}" -gravity SouthEast \
  -draw "fill-opacity 0.10 text $(( WIDTH * 4 / 100 )),$(( HEIGHT * 2 / 100 )) 'K'" \
  "${MATRIX_OUT}"

echo "Done:"
echo "  ${GRID_OUT}"
echo "  ${MATRIX_OUT}"
