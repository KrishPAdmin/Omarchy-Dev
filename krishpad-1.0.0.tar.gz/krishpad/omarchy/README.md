# krishadmin - Omarchy theme

A dark [Omarchy](https://omarchy.org) (Arch + Hyprland) theme that makes the
laptop match **krishadmin.com**: signature neon green on pure black, with a deep
maroon accent. Built for user `krishadmin`. Not published to GitHub - it installs
as a local user theme.

## Palette (from krishadmin.com CSS)

| Role                | Hex        | Used for |
|---------------------|------------|----------|
| Accent (neon green) | `#20fd14`  | cursor, active border, clock, selection, primary accent |
| Bright green        | `#5cff52`  | hover / focused-match highlights |
| Dim green           | `#0a5406` / `#12a00c` | graph gradients, faint wallpaper motif |
| Maroon (secondary)  | `#69021b`  | terminal "red", urgent/critical states |
| Maroon bright       | `#a4102f`  | bright red, critical borders |
| Pure black          | `#000000`  | all backgrounds |
| Glass panel         | `#0c0e10`  | bar modules, floats, popups, notifications |
| Panel lifted        | `#14181b`  | selection / hover surfaces |
| Border              | `#2a2f33`  | subtle module + window borders |
| Text                | `#eeeeee`  | primary text |
| Text soft           | `#bebebe`  | secondary text |
| Text sub            | `#959595`  | muted / comments |
| Amber               | `#e0b020`  | warnings |
| Teal (cyan slot)    | `#2fd4c4`  | keeps the 16-color set distinct without breaking the green lean |

Terminal font: a Nerd Font mono (`CaskaydiaMono`/`JetBrainsMono`, both ship with
Omarchy). The website's UI font is Source Sans 3; the wallpaper "K" uses it when
rendered with ImageMagick.

## What's in the theme

`themes/krishadmin/` is a complete Omarchy theme:

| File | App | Notes |
|------|-----|-------|
| `alacritty.toml` | Alacritty | black bg, `#eeeeee` fg, green cursor, 16-color palette (maroon = red) |
| `colors.toml` | Omarchy templates | canonical key/value colors for newer template-based Omarchy builds |
| `hyprland.conf` | Hyprland | `col.active_border` neon green, inactive dim grey, rounding 8, green-tinted shadow |
| `hyprlock.conf` | Hyprlock | black bg, big green clock, glass input field |
| `waybar.css` | Waybar | black bar, glass modules, green clock/active workspace, `#custom-myday` hooks |
| `mako.ini` | Mako | black glass card, green border/progress, maroon for critical |
| `walker.css` | Walker | black glass launcher, green selection + caret |
| `btop.theme` | btop | green-on-black meters, maroon at load peaks |
| `neovim.lua` | Neovim (LazyVim) | tokyonight-night recolored to black bg + green accents |
| `backgrounds/` | wallpaper | generated 4K PNG (black + matrix streaks + lime "K") |

This is the classic per-app theme layout. It is still fully supported: current
`omarchy-theme-set` copies a user theme from `~/.config/omarchy/themes/<name>`
and even auto-derives `colors.toml` from `alacritty.toml` when absent. `colors.toml`
is included as well so the theme also works on template-driven Omarchy builds.
Because this is a dark theme there is deliberately **no `light.mode`** marker
(that file marks *light* themes).

## Repo layout

```
omarchy/
  themes/krishadmin/        the theme itself (install target)
  generate-wallpaper.sh     ImageMagick wallpaper renderer (+ pure-python fallback)
  lib/png_wallpaper.py      stdlib PNG renderer used when ImageMagick is missing
  apply-theme.sh            installer / activator
  waybar/myday-module.jsonc MyDay planner Waybar module snippet
  README.md                 this file
```

## Apply it

```bash
cd omarchy
./apply-theme.sh                 # install + activate (keeps current wallpaper)
./apply-theme.sh --set-wallpaper # also switch the wallpaper to the theme's
```

`apply-theme.sh`:
1. generates a wallpaper if `backgrounds/` is empty,
2. copies `themes/krishadmin` into `~/.config/omarchy/themes/krishadmin`
   (backing up any existing copy to `krishadmin.bak.<timestamp>`),
3. runs `omarchy-theme-set krishadmin` if present; otherwise prints manual steps.

It is idempotent and never reboots. Manual activation, if Omarchy tooling is
absent:

```bash
ln -sfn ~/.config/omarchy/themes/krishadmin ~/.config/omarchy/current/theme
hyprctl reload
```

and confirm your app configs point at `~/.config/omarchy/current/theme/*` (see the
header comment in each theme file for the exact `import`/`source`/`@import` line).

## Wallpaper

```bash
./generate-wallpaper.sh                 # default 3840x2160 into backgrounds/
./generate-wallpaper.sh --size 2560x1440
./generate-wallpaper.sh --out /tmp/wp   # render elsewhere
```

With ImageMagick it renders two 4K wallpapers (`0-krishadmin-grid.png` dot grid,
`1-krishadmin-matrix.png` streaks), each with the lime "K" watermark. Without
ImageMagick it falls back to `lib/png_wallpaper.py` (pure stdlib, deterministic)
and writes `0-krishadmin-grid.png`. If neither ImageMagick nor python3 exists it
prints guidance and exits 0 (never fails the build).

## MyDay Waybar module

`waybar/myday-module.jsonc` wires the MyDay terminal planner into Waybar via
`myday status --json` (60s interval, click launches `myday`). Paste the
`custom/myday` object into `~/.config/waybar/config.jsonc` and add `"custom/myday"`
to a module array. Styling (`#custom-myday`, `.free/.busy/.now/.overdue`) is
already in `waybar.css`.

## Tweak it

- Change an accent: edit the hex in the relevant theme file (and mirror it in
  `colors.toml` if you rely on template-driven builds). The green is `#20fd14`
  everywhere; grep the theme dir for it to retint.
- Border thickness / rounding / gaps: `hyprland.conf` (`border_size`, `rounding`,
  `gaps_in/out`).
- Neovim base scheme: swap `folke/tokyonight.nvim` + the `colorscheme` value in
  `neovim.lua` (the `on_colors`/`on_highlights` overrides keep it black+green).
- Re-apply after any edit: `./apply-theme.sh` (or `omarchy-theme-set krishadmin`).

## How it maps to krishadmin.com

The site is neon-green-on-black glass panels with faint borders and a large lime
"K". This theme reproduces that system-wide: black everywhere, `#0c0e10` glass
panels with `#2a2f33` borders for Waybar/Mako/Walker/floats, `#20fd14` as the
single hero accent (cursor, clock, active window border, workspace, selection),
the site's maroon `#69021b` reserved for "danger"/critical, and a wallpaper that
echoes the LimeK mark. The MyDay TUI already reads from the same palette
(`myday/palette.py`), so terminal and desktop stay in sync.
