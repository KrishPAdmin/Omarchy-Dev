#!/usr/bin/env bash
# apply-theme.sh - install the krishadmin Omarchy theme.
#
# Copies themes/krishadmin into ~/.config/omarchy/themes/krishadmin (backing up
# any existing copy), generates the wallpaper if missing, then activates the
# theme with `omarchy-theme-set` when available. When Omarchy tooling is not
# present it prints the manual steps. Idempotent. Never reboots.

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)"
SRC_THEME="${SCRIPT_DIR}/themes/krishadmin"
THEME_NAME="krishadmin"
DEST_ROOT="${HOME}/.config/omarchy/themes"
DEST_THEME="${DEST_ROOT}/${THEME_NAME}"
SET_WALLPAPER=0

usage() {
  cat <<'EOF'
Usage: apply-theme.sh [--help] [--set-wallpaper]

Installs the krishadmin Omarchy theme:
  1. Generates the wallpaper if backgrounds/ is empty (generate-wallpaper.sh).
  2. Copies themes/krishadmin -> ~/.config/omarchy/themes/krishadmin
     (existing copy backed up to <name>.bak.<timestamp>).
  3. Activates it with `omarchy-theme-set krishadmin` if that command exists;
     otherwise prints the manual activation steps.

Options:
  --set-wallpaper  Also set the wallpaper now (omarchy-theme-bg-next, else
                   prints the swww/hyprpaper fallback).
  --help           Show this help.

No reboot is performed. Safe to re-run.
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --help|-h) usage; exit 0 ;;
    --set-wallpaper) SET_WALLPAPER=1; shift ;;
    *) echo "Unknown option: $1" >&2; usage >&2; exit 2 ;;
  esac
done

if [[ ! -d "$SRC_THEME" ]]; then
  echo "Error: source theme not found at ${SRC_THEME}" >&2
  exit 1
fi

# --- 1. wallpaper ----------------------------------------------------------
shopt -s nullglob
bg_files=( "${SRC_THEME}/backgrounds/"*.png "${SRC_THEME}/backgrounds/"*.jpg )
shopt -u nullglob
if [[ ${#bg_files[@]} -eq 0 ]]; then
  echo "No wallpaper found; generating one..."
  bash "${SCRIPT_DIR}/generate-wallpaper.sh" || \
    echo "Wallpaper generation skipped (ImageMagick missing); continuing."
else
  echo "Wallpaper already present (${#bg_files[@]} file(s)); skipping generation."
fi

# --- 2. copy into place (with backup) -------------------------------------
mkdir -p "$DEST_ROOT"
if [[ -e "$DEST_THEME" ]]; then
  BACKUP="${DEST_THEME}.bak.$(date +%Y%m%d%H%M%S)"
  echo "Backing up existing theme -> ${BACKUP}"
  mv "$DEST_THEME" "$BACKUP"
fi
echo "Installing theme -> ${DEST_THEME}"
cp -r "$SRC_THEME" "$DEST_THEME"

# --- 3. activate -----------------------------------------------------------
if command -v omarchy-theme-set >/dev/null 2>&1; then
  echo "Activating with omarchy-theme-set..."
  if [[ "$SET_WALLPAPER" -eq 1 ]]; then
    omarchy-theme-set "$THEME_NAME"
  else
    OMARCHY_THEME_SKIP_BACKGROUND=1 omarchy-theme-set "$THEME_NAME"
  fi
  echo "Theme '${THEME_NAME}' applied."
else
  cat <<EOF
omarchy-theme-set not found. Manual activation:
  1. Open the Omarchy theme menu:  omarchy  (Menu -> Style -> Theme)
     and pick "Krishadmin".
  OR set the current-theme symlink directly:
     ln -sfn "${DEST_THEME}" "\${HOME}/.config/omarchy/current/theme"
     then restart waybar/mako/hyprland (e.g. 'hyprctl reload').
  2. Your app configs must point at ~/.config/omarchy/current/theme/* :
       alacritty:  import = ["~/.config/omarchy/current/theme/alacritty.toml"]
       hyprland :  source = ~/.config/omarchy/current/theme/hyprland.conf
       waybar   :  @import "../omarchy/current/theme/waybar.css";
       mako     :  ln -sfn ~/.config/omarchy/current/theme/mako.ini ~/.config/mako/config
EOF
fi

# --- optional wallpaper set when Omarchy tooling is absent -----------------
if [[ "$SET_WALLPAPER" -eq 1 ]] && ! command -v omarchy-theme-set >/dev/null 2>&1; then
  shopt -s nullglob
  set_bg=( "${DEST_THEME}/backgrounds/"*.png "${DEST_THEME}/backgrounds/"*.jpg )
  shopt -u nullglob
  if [[ ${#set_bg[@]} -gt 0 ]]; then
    if command -v omarchy-theme-bg-next >/dev/null 2>&1; then
      omarchy-theme-bg-next || true
    elif command -v swww >/dev/null 2>&1; then
      swww img "${set_bg[0]}" || true
    elif command -v hyprctl >/dev/null 2>&1; then
      echo "Set wallpaper manually with hyprpaper: ${set_bg[0]}"
    fi
  fi
fi

echo "Done."
