# MyDay terminal planner - BUILD CONTRACT

You are one of several agents building **MyDay**, a Textual (Python) terminal
planner for an Omarchy (Arch/Hyprland) laptop. It is a TUI port of a web
planner. Brand = **krishadmin.com**: neon green `#20fd14` on pure black.

**The foundation below is DONE, TESTED, and FROZEN. Do not edit foundation
files. Build only the files your assignment lists. Never edit another agent's
files.**

Repo root: `/home/virt/krishpad`  •  Python package: `myday/`
Test interpreter: `/tmp/mydayvenv/bin/python` (Textual 8.2.8, pytest installed).
Always run tests with an isolated DB: `export MYDAY_DB=/tmp/myday_<you>.db`.

---

## Frozen foundation (import these; do not modify)

### `myday.config`
- `load_settings() -> Settings` (fields: `week_start=1` Monday, `idle_seconds=300`,
  `rotate_seconds=60`, `night_start_min=1320` (22:00), `night_end_min=360` (06:00),
  `night_dark=True`, `effects=()`, `theme`, `clock_24h=False`).
- `in_night_window(now=None, settings=None) -> bool` (handles the 22:00->06:00 wrap).
- `data_dir()/config_dir()/state_dir()/db_path()` (XDG-aware).

### `myday.dates` (local wall-clock; **WEEK STARTS MONDAY**)
`today() parse(day) to_str(d) is_valid(day) add(day,n) add_months add_years`
`start_of_week(day,week_start=1) week_days month_matrix(day)->6x7 month_days`
`year_days in_month(day,ref) is_today weekday_abbr pretty(day,style)`
styles: `full`=“Mon, Aug 24, 2026” `md`=“Aug 24” `mdy` `dow`=“Mon” `dow_full`
`month`=“August 2026” `month_short` `year` `day`.
`to_min('HH:MM')->int to_hhmm(int)->'HH:MM' pretty_min(int,clock_24h)->'9:00 AM'`
`now_min() clock_str(clock_24h,seconds)`.

### `myday.repo` (data API - synchronous, returns dicts; raises `repo.ValidationError`/`repo.NotFound`)
- `init()` (called at app boot; you don't call it).
- Schedule: `list_schedule(day|start,end) get_block(id) create_schedule(day,start_min,end_min,title,category='other',note='',color='') update_schedule(id,**) delete_schedule(id)`
- Todos: `list_todos(day|start,end) create_todo(day,text) update_todo(id,**) toggle_todo(id) delete_todo(id) reorder_todo(id,±1)`
- Meals: `list_meals(...) create_meal(day,meal_type,name,calories?,time_min?,note?) update_meal delete_meal` (`meal_type in breakfast|lunch|dinner|snack`)
- Workouts: `list_workouts(...) create_workout(day,activity,duration_min?,intensity?,note?) update_workout delete_workout` (`intensity in low|med|high|None`)
- Metrics (per-day upsert): `get_metrics(day) list_metrics(start,end) set_metrics(day,**) add_water(day,±1)` object keys: `water_cups,sleep_hours,weight,mood(1..5)`
- Habits: `list_habits(include_inactive=False) create_habit(name,color?) update_habit delete_habit`
- Habit logs: `list_habit_logs(day|start,end) set_habit_log(habit_id,day,done) toggle_habit(habit_id,day) habit_streak(habit_id,day)->int`
- Journal: `get_journal(day) set_journal(day,content)`
- Overviews: `summary(start,end)->[perDay dict]` (keys: day, blocks, scheduled_min,
  todos_total, todos_done, meals, calories, workouts, workout_min, water_cups,
  sleep_hours, weight, mood, habits_total, habits_done, journal(bool)).
- Dashboard helpers: `current_and_next_block(day,now_min)->(cur,next)`,
  `upcoming(from_day,days=14)->[{kind:'block'|'todo',...}]`, `day_counts(day)->dict`.
- Constants: `repo.CATEGORIES` (`[{id,label}]`), `repo.CATEGORY_IDS`,
  `VALID_MEAL_TYPES`, `VALID_INTENSITIES`.

### `myday.palette` (colours; match Rich renders to the theme)
`ACCENT=#20fd14 ACCENT_DIM ACCENT_DEEP BG=#000000 PANEL=#0c0e10 PANEL_HI BORDER`
`TEXT=#eeeeee TEXT_SOFT TEXT_SUB MAROON MAROON_HI OK WARN ERROR INFO`
`CATEGORY_COLORS{} category_color(cat) HABIT_PALETTE habit_color(i)`
`MOOD_COLORS MOOD_GLYPHS MOOD_ASCII INTENSITY_COLORS GREEN_RAMP`.

### `myday.ui` (build with these; do not re-implement modals)
- `PlannerView(Vertical)` base for a top-level view. Set class attrs
  `VIEW_ID, VIEW_LABEL, VIEW_ORDER, NAV_STEP('day'|'week'|'month'|'year')`;
  implement `render_day(day)` (or override `refresh_view()`); optional
  `range_label(day)->str`. Access the date via `self.day`.
- `DayPanel(Vertical)` base for a Today/Day sub-panel. Set `PANEL_ID, PANEL_TITLE,
  PANEL_ORDER`; implement `render_panel(day)`.
- `Section(title, *children)` -> a `.panel` box with a `.panel-title` bar.
- `Field(name,label,type,required,options,placeholder,min,max,step)` and
  `FormModal(title, [Field...], values={}, submit_label, on_submit, on_delete)`.
  `on_submit(values)` returns `None` to close, or a message / `{"error":..}` / raises
  `repo.ValidationError` to stay open. Types: text, textarea, number, time (HH:MM),
  date (YYYY-MM-DD), select (options `[(label,value)]` or `[str]`), color, checkbox.
- `ConfirmModal(message,yes_label,no_label,danger)` -> dismiss(bool).
- `category_options()`, `toast(app,msg,kind)`.

### `myday.registry` (self-register at import)
`@register_view` on your PlannerView subclass; `@register_day_panel` on your
DayPanel subclass. `get_views()/get_day_panels()` are sorted by order.

### `myday.app.MyDayApp` (the app; already handles chrome/clock/idle/night)
Your view/panel can call, via `self.app`:
`app.day` (reactive 'YYYY-MM-DD'), `app.settings`, `app.set_date(day)`,
`app.set_view(id)`, `app.shift(±1)`, `app.go_today()`, `app.refresh_active()`,
`app.set_status(text)`, `app.notify(msg, severity=...)`, `app.push_screen(...)`.
The app auto-imports `myday.screens.{today,day,week,month,year,plan}` and
`myday.panels.{food,fitness,habits,journal,metrics}` at boot (defensively).

### Shared widget `myday.widgets.todolist.TodoList` (DONE - reuse, don't rebuild)
`TodoList(day=None, show_add=True)`; call `.reload(day)` on date change; it posts
`TodoList.Changed` after edits. Used by Today and Day.

---

## Theme classes (in `myday/theme.tcss`, loaded globally)
Use: `.panel .panel-title .card .muted .subtle .accent .danger .warn .done`
`.now .selected .chip .pill .key`; ids `#topbar #clock #statusbar`. Put
widget-specific rules in your file's `DEFAULT_CSS`, reusing these colours:
green `#20fd14`, panel `#0c0e10`, panel-hi `#14181b`, border `#2a2f33`,
text `#eeeeee`, soft `#bebebe`, sub `#959595`, maroon `#69021b`.

## Conventions
- `day` = `'YYYY-MM-DD'`; `*_min` = minutes 0..1439 from local midnight.
- Week starts Monday. Times shown 12h unless `settings.clock_24h`.
- Catch `repo.ValidationError` and show it with `app.notify(msg, severity="error")`.
- Every view/panel must survive an empty day (no data) without error.
- Keep it keyboard-first but mouse/touch-friendly (Textual clicks == touch taps).

## How to self-test (do this before you finish)
Mount the app headless and drive it. Example:
```python
import asyncio; from myday import repo, dates; from myday.app import MyDayApp
async def t():
    app=MyDayApp()
    async with app.run_test(size=(120,44)) as p:
        await p.pause(); app.set_view("YOUR_VIEW_ID"); await p.pause()
        # assert your widgets exist / drive keys with await p.press(...)
asyncio.run(t())
```
Run: `MYDAY_DB=/tmp/myday_x.db /tmp/mydayvenv/bin/python yourtest.py`
