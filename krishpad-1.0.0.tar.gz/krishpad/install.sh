#!/usr/bin/env bash
#
# krishpad / MyDay installer
# --------------------------
# One-command install of the MyDay terminal planner (Textual TUI) plus optional
# Omarchy theming, autostart, waybar, screen-off and Surface-touch extras.
#
# Safe to re-run: every step is idempotent and backs up anything it replaces.
# On this build VM you can preview the full flow with:  ./install.sh --dry-run --force
#
set -euo pipefail

# --------------------------------------------------------------------------
# Constants / paths
# --------------------------------------------------------------------------
BUNDLE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_HOME="${HOME}/.local/share/myday"
APP_DIR="${APP_HOME}/app"          # copy of the myday/ package lives here
VENV_DIR="${APP_HOME}/venv"
DB_PATH="${APP_HOME}/planner.db"   # user data - never touched by install
BIN_DIR="${HOME}/.local/bin"
LAUNCHER="${BIN_DIR}/myday"
TEXTUAL_SPEC="textual>=8,<9"
MIN_PY_MAJOR=3
MIN_PY_MINOR=11
TS="$(date +%Y%m%d-%H%M%S)"

# --------------------------------------------------------------------------
# Flags
# --------------------------------------------------------------------------
DRY_RUN=0
FORCE=0
DO_THEME=0
DO_AUTOSTART=0
DO_WAYBAR=0
DO_SCREEN_OFF=0
DO_TOUCH=0
DO_UNINSTALL=0

# --------------------------------------------------------------------------
# Output helpers
# --------------------------------------------------------------------------
if [[ -t 1 ]]; then
  C_G=$'\033[38;2;32;253;20m'; C_Y=$'\033[33m'; C_R=$'\033[31m'
  C_B=$'\033[1m'; C_D=$'\033[2m'; C_0=$'\033[0m'
else
  C_G=""; C_Y=""; C_R=""; C_B=""; C_D=""; C_0=""
fi
say()  { printf '%s\n' "$*"; }
info() { printf '%s==>%s %s\n' "$C_G" "$C_0" "$*"; }
step() { printf '  %s-%s %s\n' "$C_D" "$C_0" "$*"; }
warn() { printf '%swarning:%s %s\n' "$C_Y" "$C_0" "$*" >&2; }
err()  { printf '%serror:%s %s\n' "$C_R" "$C_0" "$*" >&2; }
die()  { err "$*"; exit 1; }

# run CMD... , honouring --dry-run
run() {
  if [[ "$DRY_RUN" -eq 1 ]]; then
    printf '  %s[dry-run]%s %s\n' "$C_D" "$C_0" "$*"
    return 0
  fi
  "$@"
}

usage() {
  cat <<EOF
${C_B}krishpad / MyDay installer${C_0}

Installs the MyDay terminal daily planner into an isolated virtualenv and drops
a ${C_B}myday${C_0} launcher on your PATH. Optional flags apply the Omarchy extras.

${C_B}USAGE${C_0}
  ./install.sh [options]

${C_B}CORE (always runs unless --uninstall)${C_0}
  Creates ${VENV_DIR}
  Installs ${TEXTUAL_SPEC} + the myday package
  Writes launcher ${LAUNCHER}

${C_B}OPTIONS${C_0}
  --theme            Apply the krishadmin Omarchy theme (omarchy/apply-theme.sh)
  --autostart        Autostart dashboard + widget on login (scripts/myday-autostart.sh)
  --waybar           Install the waybar config/module (omarchy/waybar)
  --screen-off-never Disable display power-off / DPMS (scripts/screen-off-never.sh --never)
  --touch            Set up Surface touchscreen (scripts/surface-touch-setup.sh).
                     Touches kernel modules; requires an explicit extra confirm.
  --all              Shorthand for: --theme --autostart --waybar
                     (does NOT include --touch or --screen-off-never)

  --force            Continue even if this is not detected as Arch/Omarchy
  --dry-run          Print every action without changing anything
  --uninstall        Run uninstall.sh (removes app/venv/launcher; keeps your DB)
  -h, --help         Show this help and exit

${C_B}AFTER INSTALL${C_0}
  myday              launch the planner        myday widget   compact widget
  myday status       one-line status           myday screensaver  pixel saver

Your data lives in ${DB_PATH} and is never modified by install or uninstall
(uninstall --purge is the only thing that removes it).
EOF
}

# --------------------------------------------------------------------------
# Parse args
# --------------------------------------------------------------------------
while [[ $# -gt 0 ]]; do
  case "$1" in
    --theme)            DO_THEME=1 ;;
    --autostart)        DO_AUTOSTART=1 ;;
    --waybar)           DO_WAYBAR=1 ;;
    --screen-off-never) DO_SCREEN_OFF=1 ;;
    --touch)            DO_TOUCH=1 ;;
    --all)              DO_THEME=1; DO_AUTOSTART=1; DO_WAYBAR=1 ;;
    --force)            FORCE=1 ;;
    --dry-run)          DRY_RUN=1 ;;
    --uninstall)        DO_UNINSTALL=1 ;;
    -h|--help)          usage; exit 0 ;;
    *) err "unknown option: $1"; say ""; usage; exit 2 ;;
  esac
  shift
done

# --------------------------------------------------------------------------
# Uninstall shortcut
# --------------------------------------------------------------------------
if [[ "$DO_UNINSTALL" -eq 1 ]]; then
  if [[ -x "${BUNDLE_DIR}/uninstall.sh" ]]; then
    exec "${BUNDLE_DIR}/uninstall.sh"
  else
    die "uninstall.sh not found next to install.sh (${BUNDLE_DIR})"
  fi
fi

# --------------------------------------------------------------------------
# Environment detection
# --------------------------------------------------------------------------
detect_os() {
  local pretty="unknown"
  if [[ -r /etc/os-release ]]; then
    # shellcheck disable=SC1091
    pretty="$(. /etc/os-release 2>/dev/null; printf '%s' "${PRETTY_NAME:-${NAME:-unknown}}")"
  fi
  printf '%s' "$pretty"
}

is_arch() {
  [[ -f /etc/arch-release ]] && return 0
  if [[ -r /etc/os-release ]]; then
    grep -qiE '^(ID|ID_LIKE)=.*arch' /etc/os-release && return 0
  fi
  return 1
}

is_omarchy() {
  [[ -d "${HOME}/.local/share/omarchy" || -d /etc/omarchy || -n "${OMARCHY_VERSION:-}" ]]
}

# --------------------------------------------------------------------------
# Locate a suitable python3 (>=3.11)
# --------------------------------------------------------------------------
find_python() {
  local cand
  for cand in python3.14 python3.13 python3.12 python3.11 python3 python; do
    command -v "$cand" >/dev/null 2>&1 || continue
    if "$cand" - <<PYEOF >/dev/null 2>&1
import sys
raise SystemExit(0 if sys.version_info[:2] >= (${MIN_PY_MAJOR}, ${MIN_PY_MINOR}) else 1)
PYEOF
    then
      printf '%s' "$cand"
      return 0
    fi
  done
  return 1
}

# --------------------------------------------------------------------------
# Preflight
# --------------------------------------------------------------------------
info "krishpad / MyDay installer  (bundle: ${BUNDLE_DIR})"
[[ "$DRY_RUN" -eq 1 ]] && warn "dry-run: no changes will be made"

OS_NAME="$(detect_os)"
step "detected OS: ${OS_NAME}"

if is_arch || is_omarchy; then
  step "Arch/Omarchy environment: yes"
else
  if [[ "$FORCE" -eq 1 ]]; then
    warn "this does not look like Arch/Omarchy - continuing because --force"
  else
    err "this does not look like an Arch/Omarchy system."
    say "  The planner itself runs anywhere, but the Omarchy extras are tuned"
    say "  for Arch/Hyprland. Re-run with --force to install here anyway."
    exit 1
  fi
fi

PY="$(find_python || true)"
if [[ -z "${PY}" ]]; then
  die "no python3 >= ${MIN_PY_MAJOR}.${MIN_PY_MINOR} found. Install python (e.g. 'sudo pacman -S python') and retry."
fi
PY_VER="$("$PY" -c 'import sys;print("%d.%d.%d"%sys.version_info[:3])' 2>/dev/null || echo '?')"
step "using python: ${PY} (${PY_VER})"

# The myday package must be present in the bundle
[[ -f "${BUNDLE_DIR}/myday/__main__.py" ]] || die "myday package not found in bundle (${BUNDLE_DIR}/myday)"

# --------------------------------------------------------------------------
# 1. Create app home + venv
# --------------------------------------------------------------------------
info "Installing MyDay core"
run mkdir -p "$APP_HOME" "$BIN_DIR"

if [[ -d "$VENV_DIR" && -x "${VENV_DIR}/bin/python" ]]; then
  step "reusing existing venv at ${VENV_DIR}"
else
  step "creating venv at ${VENV_DIR}"
  if ! run "$PY" -m venv "$VENV_DIR"; then
    die "failed to create venv. On Arch ensure 'python' is installed; on Debian 'python3-venv'."
  fi
fi
VENV_PY="${VENV_DIR}/bin/python"

# --------------------------------------------------------------------------
# 2. Install textual (offline-aware)
# --------------------------------------------------------------------------
have_textual() {
  [[ -x "$VENV_PY" ]] || return 1
  "$VENV_PY" - <<'PYEOF' >/dev/null 2>&1
import importlib.metadata as m
from packaging.version import Version  # noqa
v = Version(m.version("textual"))
raise SystemExit(0 if (Version("8") <= v < Version("9")) else 1)
PYEOF
}

if [[ "$DRY_RUN" -eq 1 ]]; then
  step "[dry-run] would ensure ${TEXTUAL_SPEC} in venv"
elif have_textual; then
  step "textual already present in venv (satisfies ${TEXTUAL_SPEC})"
else
  step "installing ${TEXTUAL_SPEC} into venv"
  run "$VENV_PY" -m pip install --quiet --upgrade pip >/dev/null 2>&1 || \
    warn "could not upgrade pip (continuing)"
  if ! "$VENV_PY" -m pip install --quiet "$TEXTUAL_SPEC"; then
    err "pip could not install textual."
    if ! "$VENV_PY" -m pip install --quiet --dry-run "$TEXTUAL_SPEC" >/dev/null 2>&1; then
      say ""
      say "  This looks like an OFFLINE / no-index situation. Options:"
      say "    1. Connect to a network, then re-run: ./install.sh"
      say "    2. Copy a wheel onto the laptop and install it manually:"
      say "         ${VENV_PY} -m pip install /path/to/textual-8.*.whl"
      say "    3. Point pip at an internal index:"
      say "         ${VENV_PY} -m pip install --index-url <URL> '${TEXTUAL_SPEC}'"
    fi
    die "textual install failed"
  fi
fi

# --------------------------------------------------------------------------
# 3. Copy the myday package into the app dir (run from a stable location)
# --------------------------------------------------------------------------
step "syncing myday package -> ${APP_DIR}"
run mkdir -p "$APP_DIR"
if [[ "$DRY_RUN" -eq 1 ]]; then
  step "[dry-run] would copy ${BUNDLE_DIR}/myday -> ${APP_DIR}/myday"
else
  # Back up any previous copy, then refresh.
  if [[ -d "${APP_DIR}/myday" ]]; then
    run mv "${APP_DIR}/myday" "${APP_DIR}/myday.bak-${TS}"
  fi
  if command -v rsync >/dev/null 2>&1; then
    run rsync -a --delete --exclude='__pycache__' --exclude='*.pyc' \
      "${BUNDLE_DIR}/myday/" "${APP_DIR}/myday/"
  else
    run cp -a "${BUNDLE_DIR}/myday" "${APP_DIR}/myday"
    run find "${APP_DIR}/myday" -name '__pycache__' -type d -prune -exec rm -rf {} + 2>/dev/null || true
  fi
  # Prune old backups, keep the two most recent. Guard the glob so an empty
  # match (no backups yet) does not trip 'set -o pipefail' and abort install.
  shopt -s nullglob
  _baks=( "${APP_DIR}"/myday.bak-* )
  shopt -u nullglob
  if [[ "${#_baks[@]}" -gt 2 ]]; then
    # Sort newest-first by mtime, drop the two newest, remove the rest.
    # shellcheck disable=SC2012
    ls -1dt "${_baks[@]}" | tail -n +3 | while read -r old; do
      [[ -n "$old" ]] && rm -rf "$old"
    done
  fi
fi

# --------------------------------------------------------------------------
# 4. Launcher on PATH
# --------------------------------------------------------------------------
step "writing launcher ${LAUNCHER}"
if [[ "$DRY_RUN" -eq 1 ]]; then
  step "[dry-run] would write ${LAUNCHER} (execs venv python -m myday)"
else
  if [[ -e "$LAUNCHER" ]]; then
    run cp -p "$LAUNCHER" "${LAUNCHER}.bak-${TS}" 2>/dev/null || true
  fi
  cat > "$LAUNCHER" <<EOF
#!/usr/bin/env bash
# MyDay launcher (generated by krishpad install.sh on ${TS})
# Runs the isolated venv interpreter against the installed package copy.
set -euo pipefail
APP_DIR="${APP_DIR}"
VENV_PY="${VENV_PY}"
if [[ ! -x "\$VENV_PY" ]]; then
  echo "myday: venv python missing at \$VENV_PY - re-run install.sh" >&2
  exit 1
fi
export PYTHONPATH="\${APP_DIR}\${PYTHONPATH:+:\$PYTHONPATH}"
exec "\$VENV_PY" -m myday "\$@"
EOF
  chmod +x "$LAUNCHER"
fi

# --------------------------------------------------------------------------
# 5. PATH check
# --------------------------------------------------------------------------
PATH_OK=1
case ":${PATH}:" in
  *":${BIN_DIR}:"*) : ;;
  *) PATH_OK=0 ;;
esac
if [[ "$PATH_OK" -eq 0 ]]; then
  warn "${BIN_DIR} is not on your PATH."
  rc=""
  case "${SHELL:-}" in
    *zsh)  rc="${HOME}/.zshrc" ;;
    *bash) rc="${HOME}/.bashrc" ;;
    *)     rc="${HOME}/.profile" ;;
  esac
  say "  Add it with:"
  say "      echo 'export PATH=\"\$HOME/.local/bin:\$PATH\"' >> ${rc}"
  say "      source ${rc}"
  say "  (or just run the planner directly: ${LAUNCHER})"
fi

# --------------------------------------------------------------------------
# Optional extras (each defensively checks its script exists)
# --------------------------------------------------------------------------
run_extra() {
  # run_extra "label" "script-path" arg...
  local label="$1"; shift
  local script="$1"; shift
  if [[ ! -f "$script" ]]; then
    warn "${label}: script not found (${script}) - skipping"
    return 0
  fi
  info "Extra: ${label}"
  if [[ ! -x "$script" ]]; then
    run chmod +x "$script" 2>/dev/null || true
  fi
  if [[ "$DRY_RUN" -eq 1 ]]; then
    step "[dry-run] would run: ${script} $*"
    return 0
  fi
  if bash "$script" "$@"; then
    step "${label}: done"
  else
    warn "${label}: script exited non-zero (continuing)"
  fi
}

if [[ "$DO_THEME" -eq 1 ]]; then
  run_extra "Omarchy theme" "${BUNDLE_DIR}/omarchy/apply-theme.sh"
fi

if [[ "$DO_WAYBAR" -eq 1 ]]; then
  # Prefer a dedicated waybar installer if present; else fall back to apply-theme --waybar.
  if [[ -f "${BUNDLE_DIR}/omarchy/waybar/install.sh" ]]; then
    run_extra "waybar" "${BUNDLE_DIR}/omarchy/waybar/install.sh"
  elif [[ -f "${BUNDLE_DIR}/scripts/myday-autostart.sh" && -d "${BUNDLE_DIR}/omarchy/waybar" ]]; then
    run_extra "waybar (via apply-theme)" "${BUNDLE_DIR}/omarchy/apply-theme.sh" --waybar
  else
    warn "waybar: no installer found under omarchy/waybar - skipping"
  fi
fi

if [[ "$DO_AUTOSTART" -eq 1 ]]; then
  run_extra "autostart" "${BUNDLE_DIR}/scripts/myday-autostart.sh" --dashboard --widget
fi

if [[ "$DO_SCREEN_OFF" -eq 1 ]]; then
  run_extra "screen-off-never" "${BUNDLE_DIR}/scripts/screen-off-never.sh" --never
fi

if [[ "$DO_TOUCH" -eq 1 ]]; then
  info "Extra: Surface touchscreen setup"
  warn "This step configures kernel modules / udev for the Surface touchscreen."
  if [[ "$DRY_RUN" -eq 1 ]]; then
    step "[dry-run] would run: ${BUNDLE_DIR}/scripts/surface-touch-setup.sh (after confirm)"
  else
    printf '  Proceed with Surface touch setup? [y/N] '
    read -r _ans || _ans=""
    case "$_ans" in
      y|Y|yes|YES) run_extra "surface-touch" "${BUNDLE_DIR}/scripts/surface-touch-setup.sh" ;;
      *) step "surface-touch: skipped by user" ;;
    esac
  fi
fi

# --------------------------------------------------------------------------
# Next steps summary
# --------------------------------------------------------------------------
say ""
info "MyDay is installed."
say ""
say "${C_B}Launch it${C_0}"
if [[ "$PATH_OK" -eq 1 ]]; then
  say "    myday                 the full planner (Today view)"
  say "    myday week|month|year|plan   start on a specific view"
  say "    myday widget          compact always-on widget"
  say "    myday status          one-line status (waybar/tmux/scripts)"
  say "    myday screensaver     the pixel screensaver"
else
  say "    ${LAUNCHER}"
  say "    (add ~/.local/bin to PATH - see the note above - to just type 'myday')"
fi
say ""
say "${C_B}Extras${C_0} (re-run install.sh with any of these)"
say "    --theme --autostart --waybar --screen-off-never --touch --all"
say ""
say "${C_B}Docs${C_0}"
say "    ${BUNDLE_DIR}/README.md            overview + quickstart"
say "    ${BUNDLE_DIR}/docs/INSTALL.md      detailed install + troubleshooting"
[[ -f "${BUNDLE_DIR}/scripts/doctor.sh" ]] && \
  say "    ${BUNDLE_DIR}/scripts/doctor.sh    environment health check"
say ""
say "${C_D}Data: ${DB_PATH} (kept across reinstalls). Uninstall: ./uninstall.sh${C_0}"
[[ "$DRY_RUN" -eq 1 ]] && warn "dry-run complete - nothing was changed"

exit 0
