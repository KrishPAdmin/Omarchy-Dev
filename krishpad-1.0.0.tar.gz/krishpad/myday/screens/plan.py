"""plan.py - the Plan view: a forward-looking agenda + quick planner.

This is the view built around the user's core goal: "easily plan out my future
tasks and timings." It shows an UPCOMING feed (merged, date-sorted future
schedule blocks + open todos) grouped by day, starting at the active date, and
gives a fast way to plan something new.

Keys (this view):
    N          Plan something (choose Timed block or To-do)
    e          Edit the focused item (block -> full form; todo -> text)
    x / space  Complete the focused to-do  /  delete the focused block
    enter      Jump to that item's day (opens the Day view on that date)
    + / -      Widen / narrow the look-ahead window (7 / 14 / 30 / 90 days)
    up / down  Move the selection

The quick-plan modal uses a single form with a TYPE select (Timed block /
To-do). Fields that don't apply to the chosen type are ignored on submit:
a To-do only needs a date + title; a Timed block also needs start/end times.
"""
from __future__ import annotations

from textual.app import ComposeResult
from textual.widgets import ListItem, ListView, Static

from .. import dates, palette, repo
from ..registry import register_view
from ..ui import ConfirmModal, Field, FormModal, PlannerView, category_options

# Look-ahead windows the +/- keys cycle through.
_HORIZONS = (7, 14, 30, 90)


# --------------------------------------------------------------------------- #
# feed rows
# --------------------------------------------------------------------------- #
class PlanHeader(ListItem):
    """A non-selectable day header inside the feed (disabled -> nav skips it)."""

    def __init__(self, label: str):
        super().__init__(disabled=True)
        self._label = label

    def compose(self) -> ComposeResult:
        yield Static(self._label, classes="plan-dayhdr", markup=True)


class PlanRow(ListItem):
    """A selectable feed row wrapping one upcoming item (block or todo)."""

    def __init__(self, item: dict, clock_24h: bool = False):
        super().__init__()
        self.item = item
        self._clock_24h = clock_24h

    def compose(self) -> ComposeResult:
        it = self.item
        if it["kind"] == "block":
            color = it.get("color") or palette.category_color(it.get("category"))
            rng = (f"{dates.pretty_min(it['start_min'], self._clock_24h)} - "
                   f"{dates.pretty_min(it['end_min'], self._clock_24h)}")
            title = it.get("title") or "(untitled)"
            yield Static(f"[{color}]●[/] [#959595]{rng}[/]  {title}",
                         classes="plan-row-block", markup=True)
        else:
            yield Static(f"☐ {it.get('text') or ''}",
                         classes="plan-row-todo", markup=True)


class PlanEmpty(ListItem):
    """The friendly empty-state row (disabled)."""

    def __init__(self, msg: str):
        super().__init__(disabled=True)
        self._msg = msg

    def compose(self) -> ComposeResult:
        yield Static(self._msg, classes="plan-empty")


# --------------------------------------------------------------------------- #
# view
# --------------------------------------------------------------------------- #
@register_view
class PlanView(PlannerView):
    VIEW_ID = "plan"
    VIEW_LABEL = "Plan"
    VIEW_ORDER = 50
    NAV_STEP = "week"

    DEFAULT_CSS = """
    PlanView { height: 1fr; padding: 0 1; }
    PlanView #plan-head {
        height: auto; padding: 1 1 0 1; color: #20fd14; text-style: bold;
    }
    PlanView #plan-sub { height: auto; padding: 0 1 1 1; color: #959595; }
    PlanView #plan-feed { height: 1fr; background: #0c0e10; border: round #2a2f33; }
    PlanView #plan-feed:focus { border: round #20fd14; }
    PlanView .plan-dayhdr {
        color: #20fd14; text-style: bold; background: #14181b; padding: 0 1; width: 100%;
    }
    PlanView .plan-row-block { padding: 0 1; }
    PlanView .plan-row-todo  { padding: 0 1; color: #eeeeee; }
    PlanView .plan-empty { color: #959595; padding: 2 2; }
    PlanView #plan-hint { height: auto; padding: 0 1; color: #959595; }
    """

    BINDINGS = [
        ("n,N", "plan", "Plan"),
        ("e", "edit", "Edit"),
        ("x,space", "complete", "Done/Del"),
        ("plus,equals_sign", "horizon(1)", "Wider"),
        ("minus,underscore", "horizon(-1)", "Narrower"),
    ]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._horizon_i = _HORIZONS.index(30)  # default 30-day look-ahead

    @property
    def _horizon(self) -> int:
        return _HORIZONS[self._horizon_i]

    # --- layout ----------------------------------------------------------- #
    def compose(self) -> ComposeResult:
        yield Static("Plan ahead", id="plan-head")
        yield Static("", id="plan-sub")
        yield ListView(id="plan-feed")
        yield Static(
            "[#20fd14]N[/] plan  [#20fd14]e[/] edit  "
            "[#20fd14]x[/] done/del  [#20fd14]↵[/] open day  "
            "[#20fd14]+/-[/] horizon",
            id="plan-hint", markup=True)

    def on_mount(self) -> None:
        self.refresh_view()
        self._focus_feed()

    def range_label(self, day: str) -> str:
        return f"Next {self._horizon} days from {dates.pretty(day, 'md')}"

    # --- rendering -------------------------------------------------------- #
    def refresh_view(self) -> None:
        try:
            lv = self.query_one("#plan-feed", ListView)
        except Exception:
            return  # not mounted yet
        clock_24h = bool(getattr(self.app.settings, "clock_24h", False))
        try:
            items = repo.upcoming(self.day, days=self._horizon)
        except Exception:
            items = []

        prev_idx = lv.index
        lv.clear()

        first_row = None
        cur_day = None
        for it in items:
            d = it["day"]
            if d != cur_day:
                cur_day = d
                lv.append(PlanHeader(self._day_header(d)))
            row = PlanRow(it, clock_24h=clock_24h)
            lv.append(row)
            if first_row is None:
                first_row = len(lv.children) - 1

        if first_row is None:
            lv.append(PlanEmpty(
                "nothing scheduled ahead - press N to plan something."))

        # restore / land the highlight on a real (enabled) row
        if first_row is not None:
            n = len(lv.children)
            if prev_idx is not None and 0 <= prev_idx < n and not lv.children[prev_idx].disabled:
                lv.index = prev_idx
            else:
                lv.index = first_row

        self._update_header(len(items))
        # keep the topbar period label in sync with the horizon
        try:
            self.app._update_rangelabel()
        except Exception:
            pass

    def _update_header(self, n_items: int) -> None:
        try:
            self.query_one("#plan-head", Static).update(
                f"Plan ahead · {self.range_label(self.day)}")
            sub = (f"{n_items} item{'s' if n_items != 1 else ''} coming up"
                   if n_items else "your agenda is clear")
            self.query_one("#plan-sub", Static).update(sub)
        except Exception:
            pass

    def _day_header(self, d: str) -> str:
        today = dates.today()
        if d == today:
            tag = "Today"
        elif d == dates.add(today, 1):
            tag = "Tomorrow"
        else:
            tag = dates.pretty(d, "dow_full")
        return f"{tag}  ·  {dates.pretty(d, 'full')}"

    # --- helpers ---------------------------------------------------------- #
    def _current(self) -> dict | None:
        try:
            lv = self.query_one("#plan-feed", ListView)
        except Exception:
            return None
        child = lv.highlighted_child
        return getattr(child, "item", None) if child else None

    def _focus_feed(self) -> None:
        try:
            if self.app.screen is self.screen:
                self.query_one("#plan-feed", ListView).focus()
        except Exception:
            pass

    def _err(self, e) -> None:
        try:
            self.app.notify(str(e) or e.__class__.__name__, severity="error")
        except Exception:
            pass

    # --- horizon ---------------------------------------------------------- #
    def action_horizon(self, delta: int) -> None:
        self._horizon_i = (self._horizon_i + delta) % len(_HORIZONS)
        self.refresh_view()
        self.app.set_status(f"Look-ahead: next {self._horizon} days")

    # --- quick plan ------------------------------------------------------- #
    def action_plan(self) -> None:
        fields = [
            Field("type", "Type", "select", required=True,
                  options=[("Timed block", "block"), ("To-do", "todo")]),
            Field("date", "Date", "date", required=True),
            Field("title", "Title / task", "text", required=True),
            Field("category", "Category (block)", "select", options=category_options()),
            Field("start", "Start time (block)", "time"),
            Field("end", "End time (block)", "time"),
            Field("note", "Note (block)", "textarea"),
        ]
        values = {"type": "block", "date": self.day, "category": "other"}

        def _submit(v):
            return self._create_from_form(v)

        self.app.push_screen(FormModal(
            "Plan something", fields, values=values,
            submit_label="Add", on_submit=_submit))
        self.app.set_status(
            "Plan something: pick Timed block (needs start/end) or To-do (date + title).")

    def _create_from_form(self, v: dict):
        typ = v.get("type") or "block"
        day = (v.get("date") or "").strip()
        title = (v.get("title") or "").strip()
        if not dates.is_valid(day):
            return "enter a valid YYYY-MM-DD date"
        if not title:
            return "title is required"
        if typ == "todo":
            repo.create_todo(day, title)          # raises ValidationError -> shown
            kind = "task"
        else:
            start = (v.get("start") or "").strip()
            end = (v.get("end") or "").strip()
            if not start or not end:
                return "a timed block needs both a start and an end time"
            try:
                smin, emin = dates.to_min(start), dates.to_min(end)
            except Exception:
                return "times must be HH:MM"
            repo.create_schedule(day, smin, emin, title,
                                 category=v.get("category") or "other",
                                 note=v.get("note") or "")
            kind = "block"
        self.refresh_view()
        self.app.set_status(f"Planned {kind} '{title}' for {dates.pretty(day, 'md')}")
        return None

    # --- edit ------------------------------------------------------------- #
    def action_edit(self) -> None:
        it = self._current()
        if not it:
            return
        if it["kind"] == "block":
            self._edit_block(it)
        else:
            self._edit_todo(it)

    def _edit_block(self, b: dict) -> None:
        fields = [
            Field("date", "Date", "date", required=True),
            Field("title", "Title", "text", required=True),
            Field("category", "Category", "select", options=category_options()),
            Field("start", "Start time", "time", required=True),
            Field("end", "End time", "time", required=True),
            Field("note", "Note", "textarea"),
        ]
        values = {
            "date": b["day"], "title": b.get("title", ""),
            "category": b.get("category", "other"),
            "start": dates.to_hhmm(b["start_min"]),
            "end": dates.to_hhmm(b["end_min"]),
            "note": b.get("note", "") or "",
        }

        def _submit(v):
            day = (v.get("date") or "").strip()
            if not dates.is_valid(day):
                return "enter a valid YYYY-MM-DD date"
            try:
                smin, emin = dates.to_min(v.get("start", "")), dates.to_min(v.get("end", ""))
            except Exception:
                return "times must be HH:MM"
            repo.update_schedule(b["id"], day=day, start_min=smin, end_min=emin,
                                 title=(v.get("title") or "").strip(),
                                 category=v.get("category") or "other",
                                 note=v.get("note") or "")
            self.refresh_view()
            self.app.set_status("Block updated")
            return None

        def _delete():
            repo.delete_schedule(b["id"])
            self.refresh_view()
            self.app.set_status("Block deleted")

        self.app.push_screen(FormModal(
            "Edit block", fields, values=values,
            on_submit=_submit, on_delete=_delete))

    def _edit_todo(self, t: dict) -> None:
        fields = [
            Field("date", "Date", "date", required=True),
            Field("text", "Task", "text", required=True),
        ]
        values = {"date": t["day"], "text": t.get("text", "")}

        def _submit(v):
            day = (v.get("date") or "").strip()
            txt = (v.get("text") or "").strip()
            if not dates.is_valid(day):
                return "enter a valid YYYY-MM-DD date"
            if not txt:
                return "task text is required"
            repo.update_todo(t["id"], text=txt, day=day)
            self.refresh_view()
            self.app.set_status("Task updated")
            return None

        def _delete():
            repo.delete_todo(t["id"])
            self.refresh_view()
            self.app.set_status("Task deleted")

        self.app.push_screen(FormModal(
            "Edit task", fields, values=values,
            on_submit=_submit, on_delete=_delete))

    # --- complete (x / space): finish a todo, or delete a block ----------- #
    def action_complete(self) -> None:
        it = self._current()
        if not it:
            return
        if it["kind"] == "todo":
            try:
                repo.toggle_todo(it["id"])
            except (repo.ValidationError, repo.NotFound) as e:
                self._err(e); return
            self.refresh_view()
            self.app.set_status("Task done ✓")
        else:
            title = it.get("title") or "block"

            def _confirm(ok):
                if not ok:
                    return
                try:
                    repo.delete_schedule(it["id"])
                except (repo.ValidationError, repo.NotFound) as e:
                    self._err(e); return
                self.refresh_view()
                self.app.set_status("Block deleted")

            self.app.push_screen(
                ConfirmModal(f"Delete block '{title}'?", yes_label="Delete"),
                _confirm)

    # --- enter: jump to the item's day ------------------------------------ #
    def on_list_view_selected(self, event: ListView.Selected) -> None:
        it = getattr(event.item, "item", None)
        if not it:
            return
        day = it["day"]
        self.app.set_date(day)
        self.app.set_view("day")
        self.app.set_status(f"Jumped to {dates.pretty(day, 'full')}")
