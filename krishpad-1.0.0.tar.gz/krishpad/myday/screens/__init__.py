"""MyDay top-level views (self-register via myday.registry.register_view)."""
