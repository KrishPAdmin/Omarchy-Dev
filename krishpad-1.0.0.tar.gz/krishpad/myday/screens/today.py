"""today.py - TodayView: the flagship MyDay dashboard (default view).

Left column  : a big block-digit clock (BigClock) over a live timeline of the
               day's schedule blocks (TimedAgenda).
Right column : a "Tasks" section reusing the shared TodoList widget, plus a
               compact "day at a glance" rollup driven by repo.day_counts.

VIEW_ORDER=5 makes this the first (default) view. NAV_STEP='day' so ◀/▶ step
one day at a time. Everything survives an empty day.
"""
from __future__ import annotations

from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical
from textual.widgets import Static

from .. import dates, palette, repo
from ..registry import register_view
from ..ui import PlannerView, Section
from ..widgets.agenda import TimedAgenda
from ..widgets.clock import BigClock
from ..widgets.todolist import TodoList


def _esc(text) -> str:
    return str(text).replace("[", r"\[")


@register_view
class TodayView(PlannerView):
    VIEW_ID = "today"
    VIEW_LABEL = "Today"
    VIEW_ORDER = 5
    NAV_STEP = "day"

    DEFAULT_CSS = """
    TodayView #today-cols { height: 1fr; }
    TodayView #today-left { width: 2fr; height: 1fr; }
    TodayView #today-right { width: 1fr; height: 1fr; min-width: 32; }
    TodayView #today-agenda-sec { height: 1fr; }
    TodayView #today-tasks-sec { height: 2fr; }
    TodayView #today-roll-sec { height: auto; }
    TodayView #today-rollup { padding: 0 1; color: #eeeeee; }
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._clock: BigClock | None = None
        self._agenda: TimedAgenda | None = None
        self._todos: TodoList | None = None

    def compose(self) -> ComposeResult:
        self._clock = BigClock(id="today-clock")
        self._agenda = TimedAgenda(id="today-agenda")
        self._todos = TodoList(id="today-todos")
        with Horizontal(id="today-cols"):
            with Vertical(id="today-left"):
                yield self._clock
                yield Section("Timeline", self._agenda, id="today-agenda-sec")
            with Vertical(id="today-right"):
                yield Section("Tasks", self._todos, id="today-tasks-sec")
                yield Section("Day at a glance",
                              Static("", id="today-rollup", markup=True),
                              id="today-roll-sec")

    def on_mount(self) -> None:
        self.refresh_view()

    def range_label(self, day: str) -> str:
        return dates.pretty(day, "full")

    # --- refresh ---------------------------------------------------------- #
    def refresh_view(self) -> None:
        day = self.day
        if self._clock is not None:
            try:
                self._clock.set_day(day)
            except Exception:
                pass
        if self._agenda is not None:
            try:
                self._agenda.reload(day)
            except Exception:
                pass
        if self._todos is not None:
            try:
                self._todos.reload(day)
            except Exception:
                pass
        self._render_rollup(day)
        try:
            self.app.set_status(
                "Today  ·  n new block  ·  e edit block  ·  a add task  ·  "
                "◀/▶ change day  ·  t jump to today")
        except Exception:
            pass

    def _render_rollup(self, day: str) -> None:
        try:
            widget = self.query_one("#today-rollup", Static)
        except Exception:
            return
        try:
            c = repo.day_counts(day)
        except Exception:
            widget.update("[#959595]nothing to summarise[/]")
            return
        open_ = c.get("todos_open", 0)
        total = c.get("todos_total", 0)
        done = c.get("todos_done", 0)
        blocks = c.get("blocks", 0)
        h_done = c.get("habits_done", 0)
        h_total = c.get("habits_total", 0)

        def plural(n, word):
            return f"{word}" if n == 1 else f"{word}s"

        lines = [
            f"[b {palette.ACCENT}]{open_}[/] open {plural(open_, 'todo')}"
            f"   [{palette.TEXT_SUB}]({done}/{total} done)[/]",
            f"[b {palette.ACCENT}]{blocks}[/] schedule {plural(blocks, 'block')}",
            f"[b {palette.ACCENT}]{h_done}/{h_total}[/] "
            f"{plural(h_total, 'habit')} done",
        ]
        widget.update("\n".join(lines))

    # --- react to child changes ------------------------------------------ #
    def on_todo_list_changed(self, event: TodoList.Changed) -> None:
        event.stop()
        self._render_rollup(self.day)

    def on_timed_agenda_changed(self, event: TimedAgenda.Changed) -> None:
        event.stop()
        self._render_rollup(self.day)


__all__ = ["TodayView"]
