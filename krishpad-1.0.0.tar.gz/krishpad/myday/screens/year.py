"""year.py - the Year view (whole-year mood / activity HEATMAP).

One row per month, 31 day-cells across. Each day cell is a block glyph coloured
by that day's mood (`palette.mood_color`); when there is no mood it falls back
to a green intensity ramp (`palette.GREEN_RAMP`) scaled by that day's activity
(schedule blocks + todos + workouts). Days that don't exist in a month are
blank. A small legend explains the colours.

All data comes from a single `repo.summary(Jan 1, Dec 31)` call. Clicking a day
cell (or Enter on the focused cell) opens that day in the Day view.
"""
from __future__ import annotations

from datetime import date

from rich.text import Text

from textual.app import ComposeResult
from textual.widgets import DataTable

from .. import dates, palette, repo
from ..registry import register_view
from ..ui import PlannerView

_MON = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
        "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]


def _activity(r: dict) -> int:
    return (r.get("blocks", 0) or 0) + (r.get("todos_total", 0) or 0) + (r.get("workouts", 0) or 0)


@register_view
class YearView(PlannerView):
    VIEW_ID = "year"
    VIEW_LABEL = "Year"
    VIEW_ORDER = 40
    NAV_STEP = "year"

    DEFAULT_CSS = """
    YearView { height: 1fr; padding: 1 1; }
    YearView #year-table { height: 1fr; }
    YearView #year-legend { color: #bebebe; height: auto; padding: 1 1 0 1; }
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._year: int = dates.parse(dates.today()).year

    def compose(self) -> ComposeResult:
        table = DataTable(id="year-table", zebra_stripes=False)
        table.cursor_type = "cell"
        yield table
        from textual.widgets import Static
        yield Static("", id="year-legend")

    def on_mount(self) -> None:
        self.refresh_view()

    def range_label(self, day: str) -> str:
        return dates.pretty(day, "year")

    # --- render ------------------------------------------------------------- #
    def refresh_view(self) -> None:
        try:
            table = self.query_one("#year-table", DataTable)
        except Exception:
            return
        self._year = dates.parse(self.day).year
        start = f"{self._year:04d}-01-01"
        end = f"{self._year:04d}-12-31"
        by_day = {r["day"]: r for r in repo.summary(start, end)}

        table.clear(columns=True)
        table.add_column(Text("Mo", style=f"bold {palette.ACCENT}"), key="mon", width=4)
        for dnum in range(1, 32):
            table.add_column(Text(f"{dnum:>2}", style=palette.TEXT_SUB), width=2)

        for mi in range(12):
            month = mi + 1
            ndays = self._days_in_month(self._year, month)
            cells = [Text(_MON[mi], style=f"bold {palette.ACCENT}")]
            for dnum in range(1, 32):
                if dnum > ndays:
                    cells.append(Text("  ", style=palette.TEXT_SUB))
                    continue
                d = f"{self._year:04d}-{month:02d}-{dnum:02d}"
                cells.append(self._daycell(d, by_day.get(d)))
            table.add_row(*cells)

        self._render_legend()

    def _daycell(self, d: str, r: dict | None) -> Text:
        today = dates.is_today(d)
        glyph = "◈" if today else "█"
        if r is None:
            color = palette.GREEN_RAMP[0]
            return Text(glyph, style=(f"bold {palette.ACCENT}" if today else palette.TEXT_SUB))
        mood = r.get("mood")
        if mood:
            color = palette.mood_color(mood)
        else:
            act = _activity(r)
            if act <= 0:
                color = palette.GREEN_RAMP[0]
            else:
                idx = min(len(palette.GREEN_RAMP) - 1, act)
                color = palette.GREEN_RAMP[idx]
        style = f"bold {color}" if today else color
        return Text(glyph, style=style)

    def _render_legend(self) -> None:
        try:
            from textual.widgets import Static
            legend = self.query_one("#year-legend", Static)
        except Exception:
            return
        t = Text()
        t.append("Mood ", style=palette.TEXT_SOFT)
        for m in range(1, 6):
            t.append("█", style=palette.mood_color(m))
        t.append("  low→high", style=palette.TEXT_SUB)
        t.append("     Activity ", style=palette.TEXT_SOFT)
        for c in palette.GREEN_RAMP:
            t.append("█", style=c)
        t.append("  none→busy   ", style=palette.TEXT_SUB)
        t.append("◈", style=f"bold {palette.ACCENT}")
        t.append(" today", style=palette.TEXT_SUB)
        legend.update(t)

    @staticmethod
    def _days_in_month(year: int, month: int) -> int:
        if month == 12:
            nxt = date(year + 1, 1, 1)
        else:
            nxt = date(year, month + 1, 1)
        return (nxt - date(year, month, 1)).days

    # --- interaction -------------------------------------------------------- #
    def on_data_table_cell_selected(self, event: DataTable.CellSelected) -> None:
        rr, cc = event.coordinate.row, event.coordinate.column
        if cc <= 0 or rr < 0 or rr > 11:
            return
        month = rr + 1
        dnum = cc  # column 1 == day 1
        if dnum > self._days_in_month(self._year, month):
            return
        self._open(f"{self._year:04d}-{month:02d}-{dnum:02d}")

    def _open(self, day: str) -> None:
        try:
            self.app.set_view("day")
            self.app.set_date(day)
        except Exception:
            pass
