"""day.py - the Day view: an hour-grid schedule + the day's to-dos + panels.

The detailed single-day planner. Left: an hour-by-hour schedule grid where each
`repo.list_schedule` block is drawn (coloured by category) in every hour it
spans, overlaps sitting side-by-side so nothing is hidden. Right: the shared
`TodoList`. Below: every registered day-panel (Food/Fitness/Habits/...).

Interaction
    click an empty hour (or press `n`)  -> add a block prefilled to that hour
    click a block      (or press `e`)   -> edit / delete that block
    the current hour is marked `.now` when the day is today

Keyboard-first but every click is a touch tap too. Survives an empty day.
"""
from __future__ import annotations

from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.widgets import Static

from .. import dates, palette, repo
from ..registry import register_day_panel, register_view, get_day_panels
from ..ui import Field, FormModal, PlannerView, Section, category_options
from ..widgets.todolist import TodoList

# default visible window; the grid auto-expands to cover any out-of-range block
HOUR_START = 6
HOUR_END = 23


# --------------------------------------------------------------------------- #
# grid pieces
# --------------------------------------------------------------------------- #
class BlockChip(Static):
    """One schedule block as it appears inside a single hour row.

    Clicking a chip asks the owning DayView to edit that block.
    """

    def __init__(self, block: dict, *, is_start: bool, clock_24h: bool):
        self.block = block
        color = block.get("color") or palette.category_color(block.get("category"))
        title = str(block.get("title") or "(untitled)")
        if is_start:
            rng = (f"{dates.pretty_min(block['start_min'], clock_24h)}"
                   f"-{dates.pretty_min(block['end_min'], clock_24h)}")
            label = f"[{color}]● {title}[/]  [#959595]{rng}[/]"
        else:
            label = f"[{color}]↳ {title}[/]"
        super().__init__(label, markup=True, classes="sched-chip")

    def on_click(self, event) -> None:
        event.stop()
        owner = _owner(self)
        if owner is not None:
            owner.open_block_modal(self.block)


class HourRow(Horizontal):
    """A single hour lane: time label on the left, block chips on the right.

    Clicking empty space (or focusing + Enter) adds a new block starting at
    this hour.
    """

    can_focus = True

    def __init__(self, hour: int, blocks: list[dict], *, is_now: bool,
                 clock_24h: bool):
        super().__init__(classes="hour-row")
        self._hour = hour
        self._blocks = blocks
        self._is_now = is_now
        self._clock_24h = clock_24h

    @property
    def hour(self) -> int:
        return self._hour

    def compose(self) -> ComposeResult:
        lbl = dates.pretty_min(self._hour * 60, self._clock_24h)
        cls = "hour-label now" if self._is_now else "hour-label"
        yield Static(lbl, classes=cls)
        lane = Horizontal(classes="hour-lane")
        yield lane
        if self._blocks:
            for b in self._blocks:
                lane_child = BlockChip(
                    b, is_start=(b["start_min"] // 60 == self._hour),
                    clock_24h=self._clock_24h)
                self._pending = getattr(self, "_pending", [])
                self._pending.append(lane_child)

    def on_mount(self) -> None:
        for child in getattr(self, "_pending", []):
            try:
                self.query_one(".hour-lane", Horizontal).mount(child)
            except Exception:
                pass
        self._pending = []

    def on_click(self, event) -> None:
        # empty-hour click (chips stop their own clicks)
        owner = _owner(self)
        if owner is not None:
            owner.open_add_modal(self._hour)

    def on_focus(self) -> None:
        owner = _owner(self)
        if owner is not None:
            owner._focused_hour = self._hour


def _owner(node) -> "DayView | None":
    n = node
    while n is not None:
        if isinstance(n, DayView):
            return n
        n = n.parent
    return None


# --------------------------------------------------------------------------- #
# the view
# --------------------------------------------------------------------------- #
@register_view
class DayView(PlannerView):
    VIEW_ID = "day"
    VIEW_LABEL = "Day"
    VIEW_ORDER = 10
    NAV_STEP = "day"

    DEFAULT_CSS = """
    DayView { height: 1fr; }

    DayView #day-main { height: 1fr; }
    DayView #day-schedule { width: 2fr; height: 1fr; }
    DayView #day-tasks { width: 1fr; height: 1fr; }

    DayView #grid { height: 1fr; background: #0c0e10; }

    DayView .hour-row { height: auto; min-height: 1; }
    DayView .hour-row:focus { background: #14181b; }
    DayView .hour-label {
        width: 10; color: #959595; padding: 0 1 0 0; text-align: right;
    }
    DayView .hour-label.now { color: #000000; background: #20fd14; text-style: bold; }
    DayView .hour-lane { width: 1fr; height: auto; }
    DayView .sched-chip {
        height: 1; width: auto; margin: 0 1 0 0; padding: 0 1; background: #14181b;
    }
    DayView .grid-empty { color: #959595; padding: 1 2; }

    DayView #day-panels { height: auto; max-height: 40%; }
    DayView .day-panel-fail { color: #a4102f; padding: 1 2; }
    """

    BINDINGS = [
        ("n", "add", "New block"),
        ("e", "edit", "Edit block"),
    ]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._focused_hour: int | None = None
        self._panels: list = []

    # --- layout ----------------------------------------------------------- #
    def compose(self) -> ComposeResult:
        grid = VerticalScroll(id="grid")
        todos = TodoList(day=None, show_add=True)
        with Horizontal(id="day-main"):
            yield Section("Schedule", grid, id="day-schedule")
            yield Section("Tasks", todos, id="day-tasks")

        panels_box = Vertical(id="day-panels")
        yield panels_box
        # instantiate every registered day-panel; a broken one can't kill us
        for cls in get_day_panels():
            try:
                inst = cls()
                self._panels.append(inst)
            except Exception as e:  # pragma: no cover - defensive
                self._panels.append(Static(
                    f"[{getattr(cls, 'PANEL_ID', '?')}] failed: {e}",
                    classes="day-panel-fail"))

    def on_mount(self) -> None:
        box = self.query_one("#day-panels", Vertical)
        for p in self._panels:
            try:
                box.mount(p)
            except Exception:
                pass
        self.refresh_view()

    # --- header label ----------------------------------------------------- #
    def range_label(self, day: str) -> str:
        return dates.pretty(day, "full")

    # --- refresh ---------------------------------------------------------- #
    def refresh_view(self) -> None:
        try:
            self._rebuild_grid(self.day)
        except Exception as e:
            self.app.notify(f"schedule error: {e}", severity="error")
        # todo list
        try:
            self.query_one(TodoList).reload(self.day)
        except Exception:
            pass
        self._refresh_panels()

    def _refresh_panels(self) -> None:
        for p in self._panels:
            fn = getattr(p, "refresh_panel", None)
            if callable(fn):
                try:
                    fn()
                except Exception:
                    pass  # a broken panel must not break the view

    def _clock_24h(self) -> bool:
        try:
            return bool(self.app.settings.clock_24h)
        except Exception:
            return False

    def _visible_range(self, blocks: list[dict]) -> tuple[int, int]:
        start, end = HOUR_START, HOUR_END
        for b in blocks:
            start = min(start, b["start_min"] // 60)
            last = max(0, (b["end_min"] - 1)) // 60
            end = max(end, last)
        return max(0, start), min(23, end)

    def _rebuild_grid(self, day: str) -> None:
        try:
            blocks = repo.list_schedule(day=day)
        except Exception:
            blocks = []
        grid = self.query_one("#grid", VerticalScroll)
        grid.remove_children()

        if not blocks:
            grid.mount(Static(
                "no blocks yet - click an hour or press [b]n[/] to add one",
                markup=True, classes="grid-empty"))
            # still render the hour lanes so empty hours are clickable
        clk = self._clock_24h()
        now_hour = dates.now_min() // 60 if dates.is_today(day) else -1
        lo, hi = self._visible_range(blocks)
        rows = []
        for h in range(lo, hi + 1):
            here = [b for b in blocks
                    if b["start_min"] < (h + 1) * 60 and b["end_min"] > h * 60]
            rows.append(HourRow(h, here, is_now=(h == now_hour), clock_24h=clk))
        if rows:
            grid.mount(*rows)

    # --- add / edit modals ------------------------------------------------ #
    def _cat_field(self) -> Field:
        return Field("category", "Category", "select",
                     options=category_options())

    def open_add_modal(self, hour: int) -> None:
        day = self.day
        start = max(0, min(1439, hour * 60))
        end = min(1439, start + 60)
        fields = [
            Field("title", "Title", "text", required=True),
            self._cat_field(),
            Field("start", "Start", "time", required=True),
            Field("end", "End", "time", required=True),
            Field("note", "Note", "textarea"),
        ]
        values = {
            "category": "other",
            "start": dates.to_hhmm(start),
            "end": dates.to_hhmm(end),
        }

        def _submit(v):
            repo.create_schedule(
                day,
                dates.to_min(v["start"]) if v.get("start") else None,
                dates.to_min(v["end"]) if v.get("end") else None,
                v.get("title", ""),
                category=v.get("category") or "other",
                note=v.get("note", ""))
            self.refresh_view()
            return None

        self.app.push_screen(FormModal(
            "New block", fields, values=values, submit_label="Add",
            on_submit=_submit))

    def open_block_modal(self, block: dict) -> None:
        day = self.day
        bid = block["id"]
        fields = [
            Field("title", "Title", "text", required=True),
            self._cat_field(),
            Field("start", "Start", "time", required=True),
            Field("end", "End", "time", required=True),
            Field("note", "Note", "textarea"),
        ]
        values = {
            "title": block.get("title", ""),
            "category": block.get("category", "other"),
            "start": dates.to_hhmm(block["start_min"]),
            "end": dates.to_hhmm(block["end_min"]),
            "note": block.get("note", ""),
        }

        def _submit(v):
            repo.update_schedule(
                bid,
                title=v.get("title", ""),
                category=v.get("category") or "other",
                start_min=dates.to_min(v["start"]) if v.get("start") else None,
                end_min=dates.to_min(v["end"]) if v.get("end") else None,
                note=v.get("note", ""))
            self.refresh_view()
            return None

        def _delete():
            repo.delete_schedule(bid)
            self.refresh_view()

        self.app.push_screen(FormModal(
            "Edit block", fields, values=values, submit_label="Save",
            on_submit=_submit, on_delete=_delete))

    # --- key actions ------------------------------------------------------ #
    def _default_hour(self) -> int:
        if self._focused_hour is not None:
            return self._focused_hour
        if dates.is_today(self.day):
            return dates.now_min() // 60
        return HOUR_START

    def action_add(self) -> None:
        self.open_add_modal(self._default_hour())

    def action_edit(self) -> None:
        block = None
        # prefer a block in the focused hour, else the current/first block
        try:
            blocks = repo.list_schedule(day=self.day)
        except Exception:
            blocks = []
        if not blocks:
            self.app.notify("no blocks to edit - press n to add one",
                            severity="warning")
            return
        h = self._focused_hour
        if h is not None:
            for b in blocks:
                if b["start_min"] < (h + 1) * 60 and b["end_min"] > h * 60:
                    block = b
                    break
        if block is None and dates.is_today(self.day):
            cur, _nxt = repo.current_and_next_block(self.day, dates.now_min())
            block = cur
        if block is None:
            block = blocks[0]
        self.open_block_modal(block)

    # --- react to shared widget ------------------------------------------- #
    def on_todo_list_changed(self, _event: TodoList.Changed) -> None:
        # todo edits can change day-panel rollups (counts, etc.)
        self._refresh_panels()


__all__ = ["DayView"]
