"""month.py - the Month view (6x7 calendar grid with tiny per-day indicators).

A DataTable with 7 day-of-week columns (Mon..Sun) and 6 rows, populated from
`dates.month_matrix(day)` (Mon-start, includes spill-over days). Each cell is a
compact multi-line summary of that day: the day number (dimmed if it belongs to
an adjacent month, highlighted if today), a green schedule bar scaled by
scheduled minutes, a "done/total" todo tag (✓ when all done), a workout ▲, a
mood-coloured dot, and a journal ●.

All numbers come from a single `repo.summary(start, end)` over the grid range.
Clicking a cell (or Enter on the focused cell) opens that day in the Day view.
"""
from __future__ import annotations

from rich.text import Text

from textual.app import ComposeResult
from textual.widgets import DataTable

from .. import dates, palette, repo
from ..registry import register_view
from ..ui import PlannerView

_DOW = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
_CELL_H = 4


def _bar(scheduled_min: int) -> int:
    """0..6 green bars scaled by scheduled minutes (~2h per bar)."""
    if not scheduled_min:
        return 0
    return max(1, min(6, round(scheduled_min / 120)))


@register_view
class MonthView(PlannerView):
    VIEW_ID = "month"
    VIEW_LABEL = "Month"
    VIEW_ORDER = 30
    NAV_STEP = "month"

    DEFAULT_CSS = """
    MonthView { height: 1fr; padding: 1 1; }
    MonthView #month-table { height: 1fr; }
    MonthView #month-hint { color: #959595; height: 1; padding: 0 1; }
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._matrix: list[list[str]] = []

    def compose(self) -> ComposeResult:
        table = DataTable(id="month-table")
        table.cursor_type = "cell"
        yield table
        from textual.widgets import Static
        yield Static("Enter / click a day to open it", id="month-hint")

    def on_mount(self) -> None:
        self.refresh_view()

    def range_label(self, day: str) -> str:
        return dates.pretty(day, "month")

    # --- render ------------------------------------------------------------- #
    def refresh_view(self) -> None:
        try:
            table = self.query_one("#month-table", DataTable)
        except Exception:
            return
        day = self.day
        self._matrix = dates.month_matrix(day)
        flat = [d for row in self._matrix for d in row]
        by_day = {r["day"]: r for r in repo.summary(flat[0], flat[-1])}

        table.clear(columns=True)
        for name in _DOW:
            table.add_column(Text(name, style=f"bold {palette.ACCENT}"), width=12)

        for row in self._matrix:
            cells = [self._cell(d, by_day.get(d), day) for d in row]
            table.add_row(*cells, height=_CELL_H)

    def _cell(self, d: str, r: dict | None, ref: str) -> Text:
        in_mo = dates.in_month(d, ref)
        today = dates.is_today(d)
        num = dates.pretty(d, "day")
        t = Text()
        # line 1: day number
        if today:
            t.append(f" {num} ", style=f"bold {palette.BG} on {palette.ACCENT}")
        elif in_mo:
            t.append(num, style=palette.TEXT)
        else:
            t.append(num, style=palette.TEXT_SUB)
        t.append("\n")

        if r is None:
            # empty day: keep the cell height stable
            t.append("", style=palette.TEXT_SUB)
            t.append("\n\n")
            return t

        # line 2: schedule bar
        bars = _bar(r["scheduled_min"])
        if bars:
            t.append("❚" * bars, style=palette.ACCENT)
        else:
            t.append("·", style=palette.TEXT_SUB)
        t.append("\n")

        # line 3: todos + workout
        total, done = r["todos_total"], r["todos_done"]
        if total:
            if done >= total:
                t.append(f"{done}/{total}✓", style=palette.ACCENT)
            else:
                t.append(f"{done}/{total}", style=palette.TEXT_SOFT)
        else:
            t.append("·", style=palette.TEXT_SUB)
        if r["workouts"]:
            t.append(" ▲", style=palette.INTENSITY_COLORS["med"])
        t.append("\n")

        # line 4: mood dot + journal
        mood = r.get("mood")
        if mood:
            t.append("●", style=palette.mood_color(mood))
        else:
            t.append(" ", style=palette.TEXT_SUB)
        if r["journal"]:
            t.append(" ●", style=palette.ACCENT_DIM)
        return t

    # --- interaction -------------------------------------------------------- #
    def on_data_table_cell_selected(self, event: DataTable.CellSelected) -> None:
        rr, cc = event.coordinate.row, event.coordinate.column
        if 0 <= rr < len(self._matrix) and 0 <= cc < len(self._matrix[rr]):
            self._open(self._matrix[rr][cc])

    def _open(self, day: str) -> None:
        try:
            self.app.set_view("day")
            self.app.set_date(day)
        except Exception:
            pass
