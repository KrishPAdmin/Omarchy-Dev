"""week.py - the Week view (7 columns Mon..Sun, per-day rollup chips).

A single DataTable: column 0 is the metric label, columns 1..7 are the seven
days of the Mon-start week. Each day column shows a small stack of rollup
values (blocks/hours, todos, workout, mood, water, journal) built entirely
from one `repo.summary(start, end)` call over the visible week.

Clicking any day cell (or Enter on a focused day cell) jumps to the Day view
for that date. Arrow keys move the cell cursor; the DataTable is themed
globally in theme.tcss.
"""
from __future__ import annotations

from rich.text import Text

from textual.app import ComposeResult
from textual.widgets import DataTable

from .. import dates, palette, repo
from ..registry import register_view
from ..ui import PlannerView


def _blank_row() -> dict:
    return {
        "blocks": 0, "scheduled_min": 0, "todos_total": 0, "todos_done": 0,
        "workouts": 0, "workout_min": 0, "water_cups": 0, "mood": None,
        "journal": False,
    }


def _hours(minutes: int) -> str:
    h = (minutes or 0) / 60.0
    if h == 0:
        return "0h"
    if h == int(h):
        return f"{int(h)}h"
    return f"{h:.1f}h"


@register_view
class WeekView(PlannerView):
    VIEW_ID = "week"
    VIEW_LABEL = "Week"
    VIEW_ORDER = 20
    NAV_STEP = "week"

    DEFAULT_CSS = """
    WeekView { height: 1fr; padding: 1 1; }
    WeekView #week-table { height: 1fr; }
    WeekView #week-hint { color: #959595; height: 1; padding: 0 1; }
    """

    # metric label, key builder
    _METRICS = ("Schedule", "Todos", "Workout", "Mood", "Water", "Journal")

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._days: list[str] = []

    def compose(self) -> ComposeResult:
        table = DataTable(id="week-table", zebra_stripes=True)
        table.cursor_type = "cell"
        yield table
        from textual.widgets import Static
        yield Static("Enter / click a day to open it", id="week-hint")

    def on_mount(self) -> None:
        self.refresh_view()

    # --- header period label ------------------------------------------------ #
    def range_label(self, day: str) -> str:
        days = dates.week_days(day)
        first, last = days[0], days[-1]
        year = dates.parse(last).year
        return f"{dates.pretty(first, 'md')} - {dates.pretty(last, 'md')}, {year}"

    # --- render ------------------------------------------------------------- #
    def refresh_view(self) -> None:
        try:
            table = self.query_one("#week-table", DataTable)
        except Exception:
            return
        day = self.day
        self._days = dates.week_days(day)
        by_day = {r["day"]: r for r in repo.summary(self._days[0], self._days[-1])}

        table.clear(columns=True)
        table.add_column("", key="metric", width=10)
        for d in self._days:
            head = f"{dates.pretty(d, 'dow')} {dates.parse(d).day}"
            if dates.is_today(d):
                label = Text(head, style=f"bold {palette.BG} on {palette.ACCENT}")
            else:
                label = Text(head, style=f"bold {palette.ACCENT}")
            table.add_column(label, key=d, width=11)

        rows = {name: [] for name in self._METRICS}
        for d in self._days:
            r = by_day.get(d) or _blank_row()
            rows["Schedule"].append(self._cell_schedule(r))
            rows["Todos"].append(self._cell_todos(r))
            rows["Workout"].append(self._cell_workout(r))
            rows["Mood"].append(self._cell_mood(r))
            rows["Water"].append(self._cell_water(r))
            rows["Journal"].append(self._cell_journal(r))

        for name in self._METRICS:
            metric = Text(name, style=palette.TEXT_SUB)
            table.add_row(metric, *rows[name], key=name)

    # --- cell builders ------------------------------------------------------ #
    def _cell_schedule(self, r: dict) -> Text:
        n = r["blocks"]
        if not n:
            return Text("-", style=palette.TEXT_SUB)
        return Text(f"{n}b {_hours(r['scheduled_min'])}", style=palette.ACCENT)

    def _cell_todos(self, r: dict) -> Text:
        total, done = r["todos_total"], r["todos_done"]
        if not total:
            return Text("-", style=palette.TEXT_SUB)
        txt = Text(f"{done}/{total}")
        if done >= total:
            txt.append(" ✓", style=palette.ACCENT)
            txt.stylize(palette.ACCENT)
        else:
            txt.stylize(palette.TEXT_SOFT)
        return txt

    def _cell_workout(self, r: dict) -> Text:
        wm, w = r["workout_min"], r["workouts"]
        if not w:
            return Text("-", style=palette.TEXT_SUB)
        return Text(f"▲ {wm}m", style=palette.INTENSITY_COLORS["med"])

    def _cell_mood(self, r: dict) -> Text:
        mood = r.get("mood")
        if not mood:
            return Text("-", style=palette.TEXT_SUB)
        glyph = palette.MOOD_GLYPHS.get(mood, str(mood))
        return Text(glyph, style=palette.mood_color(mood))

    def _cell_water(self, r: dict) -> Text:
        c = r["water_cups"]
        if not c:
            return Text("-", style=palette.TEXT_SUB)
        return Text(f"{c}c", style=palette.INFO)

    def _cell_journal(self, r: dict) -> Text:
        if r["journal"]:
            return Text("●", style=palette.ACCENT)
        return Text("", style=palette.TEXT_SUB)

    # --- interaction -------------------------------------------------------- #
    def on_data_table_cell_selected(self, event: DataTable.CellSelected) -> None:
        col = event.coordinate.column
        if col <= 0:
            return
        idx = col - 1
        if 0 <= idx < len(self._days):
            self._open(self._days[idx])

    def _open(self, day: str) -> None:
        try:
            self.app.set_view("day")
            self.app.set_date(day)
        except Exception:
            pass
