"""db.py - MyDay database layer (stdlib sqlite3 only).

Ported from the web app's backend/db.py, retargeted at a local per-user
SQLite file (see config.db_path()). Same robust transaction pattern:
WAL journal, busy_timeout, autocommit connection with explicit
BEGIN IMMEDIATE around every write.
"""
from __future__ import annotations

import sqlite3
from contextlib import contextmanager

from . import config


def get_conn() -> sqlite3.Connection:
    path = config.db_path()
    conn = sqlite3.connect(path, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.isolation_level = None          # autocommit; we manage txns ourselves
    conn.execute("PRAGMA busy_timeout=5000")
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


@contextmanager
def immediate_txn(conn: sqlite3.Connection):
    """BEGIN IMMEDIATE / COMMIT, ROLLBACK on error."""
    conn.execute("BEGIN IMMEDIATE")
    try:
        yield conn
        conn.execute("COMMIT")
    except Exception:
        try:
            conn.execute("ROLLBACK")
        except Exception:
            pass
        raise


_DDL = """
CREATE TABLE IF NOT EXISTS schedule_blocks (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    day         TEXT NOT NULL,
    start_min   INTEGER NOT NULL,
    end_min     INTEGER NOT NULL,
    title       TEXT NOT NULL,
    category    TEXT NOT NULL DEFAULT 'other',
    note        TEXT NOT NULL DEFAULT '',
    color       TEXT NOT NULL DEFAULT '',
    created_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS todos (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    day         TEXT NOT NULL,
    text        TEXT NOT NULL,
    done        INTEGER NOT NULL DEFAULT 0,
    sort_order  INTEGER NOT NULL DEFAULT 0,
    created_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS meals (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    day         TEXT NOT NULL,
    meal_type   TEXT NOT NULL,
    name        TEXT NOT NULL,
    calories    INTEGER,
    time_min    INTEGER,
    note        TEXT NOT NULL DEFAULT '',
    created_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS workouts (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    day         TEXT NOT NULL,
    activity    TEXT NOT NULL,
    duration_min INTEGER,
    intensity   TEXT,
    note        TEXT NOT NULL DEFAULT '',
    created_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS day_metrics (
    day         TEXT PRIMARY KEY,
    water_cups  INTEGER NOT NULL DEFAULT 0,
    sleep_hours REAL,
    weight      REAL,
    mood        INTEGER,
    updated_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS habits (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL,
    color       TEXT NOT NULL DEFAULT '',
    active      INTEGER NOT NULL DEFAULT 1,
    sort_order  INTEGER NOT NULL DEFAULT 0,
    created_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS habit_logs (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    habit_id    INTEGER NOT NULL,
    day         TEXT NOT NULL,
    done        INTEGER NOT NULL DEFAULT 1,
    UNIQUE(habit_id, day)
);

CREATE TABLE IF NOT EXISTS journal (
    day         TEXT PRIMARY KEY,
    content     TEXT NOT NULL DEFAULT '',
    updated_at  TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_sched_day  ON schedule_blocks(day);
CREATE INDEX IF NOT EXISTS idx_todos_day  ON todos(day);
CREATE INDEX IF NOT EXISTS idx_meals_day  ON meals(day);
CREATE INDEX IF NOT EXISTS idx_wk_day     ON workouts(day);
CREATE INDEX IF NOT EXISTS idx_hlog_day   ON habit_logs(day);
"""


def init_db() -> None:
    conn = get_conn()
    try:
        conn.executescript(_DDL)   # implicit COMMIT; run outside immediate_txn
    finally:
        conn.close()


__all__ = ["get_conn", "immediate_txn", "init_db"]
