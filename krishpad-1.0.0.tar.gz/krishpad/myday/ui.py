"""ui.py - shared Textual building blocks for MyDay screens & panels.

Everything reusable lives here so the build agents write less and stay
consistent. Import from here; do NOT re-implement modals or section chrome.

Provided:
    PlannerView   - base class for a top-level view (Day/Week/Month/Year/Plan)
    DayPanel      - base class for a Today/Day sub-panel (Food/Fitness/...)
    Section       - a titled .panel container (title bar + body)
    FormModal     - generic form dialog (mirrors the web app's App.modal)
    ConfirmModal  - yes/no dialog
    Field         - dataclass describing one FormModal field
    ask() / confirm() / toast() helpers

FormModal field types: text, textarea, number, time (HH:MM), date
(YYYY-MM-DD), select, color, checkbox.  on_submit(values: dict) may raise
repo.ValidationError or return a truthy string / {"error": msg} to keep the
dialog open and show the message; returning None/falsey closes it.
"""
from __future__ import annotations

from dataclasses import dataclass, field as dc_field
from typing import Any, Callable, Iterable, Optional

from textual.app import ComposeResult
from textual.containers import Vertical, Horizontal, VerticalScroll
from textual.screen import ModalScreen
from textual.widgets import (
    Button, Checkbox, Input, Label, Select, Static, TextArea,
)

from . import repo


# --------------------------------------------------------------------------- #
# base view / panel
# --------------------------------------------------------------------------- #
class PlannerView(Vertical):
    """Base for a top-level view.

    Subclasses set the class attributes and implement `render_day(day)` (or
    override `refresh_view`). The app mounts exactly one view at a time into
    the #view-root and calls `refresh_view()` on show and whenever the active
    date changes.

        VIEW_ID     : str   unique id ('day', 'week', ...)
        VIEW_LABEL  : str   tab label
        VIEW_ORDER  : int   sort order in the view switcher
        NAV_STEP    : str   'day'|'week'|'month'|'year' - how <-/-> steps
    """
    VIEW_ID: str = "view"
    VIEW_LABEL: str = "View"
    VIEW_ORDER: int = 100
    NAV_STEP: str = "day"

    @property
    def day(self) -> str:
        return self.app.day  # type: ignore[attr-defined]

    def range_label(self, day: str) -> str:
        """Header period label for `day` (override per view)."""
        from . import dates
        return dates.pretty(day, "full")

    def refresh_view(self) -> None:
        """Re-render for the current day. Default calls render_day()."""
        try:
            self.render_day(self.day)
        except NotImplementedError:
            pass

    def render_day(self, day: str) -> None:  # pragma: no cover - overridden
        raise NotImplementedError


class DayPanel(Vertical):
    """Base for a Today/Day sub-panel (Food, Fitness, Habits, Journal, ...).

    Subclasses set PANEL_* and implement `render_panel(day)`. The Today/Day
    view mounts every registered panel in order and calls `refresh_panel()`.
    """
    PANEL_ID: str = "panel"
    PANEL_TITLE: str = "Panel"
    PANEL_ORDER: int = 100

    @property
    def day(self) -> str:
        return self.app.day  # type: ignore[attr-defined]

    def refresh_panel(self) -> None:
        try:
            self.render_panel(self.day)
        except NotImplementedError:
            pass

    def render_panel(self, day: str) -> None:  # pragma: no cover - overridden
        raise NotImplementedError


# --------------------------------------------------------------------------- #
# Section - titled panel container
# --------------------------------------------------------------------------- #
class Section(Vertical):
    """A titled .panel box. Use as a context in compose or pass a body.

        yield Section("Todos", body_widgets...)
    or subclass / mount children after construction.
    """
    DEFAULT_CLASSES = "panel"

    def __init__(self, title: str, *children, **kwargs):
        super().__init__(**kwargs)
        self._title = title
        self._initial = children

    def compose(self) -> ComposeResult:
        yield Static(self._title, classes="panel-title")
        for c in self._initial:
            yield c


# --------------------------------------------------------------------------- #
# form field spec
# --------------------------------------------------------------------------- #
@dataclass
class Field:
    name: str
    label: str
    type: str = "text"           # text|textarea|number|time|date|select|color|checkbox
    required: bool = False
    options: Iterable = dc_field(default_factory=list)  # for select: [(label,value)] or [str]
    placeholder: str = ""
    min: Optional[float] = None
    max: Optional[float] = None
    step: Optional[float] = None


class FormModal(ModalScreen):
    """Generic form dialog. Result is delivered via `on_submit`, not dismiss.

    on_submit(values) -> None | str | {"error": str}
        return None            -> valid, dialog closes
        return "msg"/{"error"} -> stays open, shows msg
        raise ValidationError  -> stays open, shows the exception message
    on_delete() (optional)     -> adds a Delete button; called then closes.
    """

    DEFAULT_CSS = """
    FormModal { align: center middle; background: black 55%; }
    FormModal > #form-card {
        background: #0c0e10; border: thick #20fd14; padding: 1 2;
        width: 64; max-width: 90%; height: auto; max-height: 90%;
    }
    FormModal .dialog-title { color: #20fd14; text-style: bold; padding: 0 0 1 0; }
    FormModal .field-label { color: #bebebe; padding: 1 0 0 0; }
    FormModal .form-error { color: #a4102f; text-style: bold; padding: 1 0 0 0; }
    FormModal #form-buttons { padding: 1 0 0 0; height: auto; align-horizontal: right; }
    FormModal #form-buttons Button { margin: 0 0 0 2; min-width: 10; }
    FormModal Input, FormModal Select, FormModal TextArea { width: 100%; }
    FormModal TextArea { height: 6; }
    """

    BINDINGS = [("escape", "cancel", "Cancel")]

    def __init__(self, title: str, fields: list[Field],
                 values: Optional[dict] = None,
                 submit_label: str = "Save",
                 on_submit: Optional[Callable[[dict], Any]] = None,
                 on_delete: Optional[Callable[[], Any]] = None):
        super().__init__()
        self._title = title
        self._fields = fields
        self._values = values or {}
        self._submit_label = submit_label
        self._on_submit = on_submit
        self._on_delete = on_delete
        self._inputs: dict[str, Any] = {}

    def compose(self) -> ComposeResult:
        with VerticalScroll(id="form-card"):
            yield Static(self._title, classes="dialog-title")
            for f in self._fields:
                yield Label(f.label + (" *" if f.required else ""), classes="field-label")
                yield self._build_widget(f)
            yield Static("", id="form-err", classes="form-error")
            with Horizontal(id="form-buttons"):
                if self._on_delete is not None:
                    yield Button("Delete", id="btn-delete", classes="-danger")
                yield Button("Cancel", id="btn-cancel")
                yield Button(self._submit_label, id="btn-submit", classes="-primary")

    def _build_widget(self, f: Field):
        cur = self._values.get(f.name)
        if f.type == "textarea":
            w = TextArea(str(cur) if cur is not None else "", id=f"fld-{f.name}")
        elif f.type == "checkbox":
            w = Checkbox(f.placeholder or "", value=bool(cur), id=f"fld-{f.name}")
        elif f.type == "select":
            opts = _norm_options(f.options)
            # Always allow_blank at the widget level (we enforce `required`
            # ourselves on submit). Passing Select.BLANK as an explicit value
            # while allow_blank=False is rejected by Textual 8.2's validator,
            # so only set `value` when we actually have one.
            kwargs = {"allow_blank": True, "id": f"fld-{f.name}"}
            if cur is not None and cur != "":
                kwargs["value"] = cur
            w = Select(opts, **kwargs)
        else:
            itype = "number" if f.type == "number" else "text"
            ph = f.placeholder or _default_ph(f.type)
            val = "" if cur is None else str(cur)
            w = Input(value=val, placeholder=ph, type=itype, id=f"fld-{f.name}")
        self._inputs[f.name] = w
        return w

    # --- actions ---------------------------------------------------------- #
    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "btn-cancel":
            self.action_cancel()
        elif event.button.id == "btn-delete":
            if self._on_delete is not None:
                try:
                    self._on_delete()
                except repo.ValidationError as e:
                    self._show_err(str(e)); return
            self.dismiss(None)
        elif event.button.id == "btn-submit":
            self._submit()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        self._submit()

    def action_cancel(self) -> None:
        self.dismiss(None)

    def _collect(self) -> dict:
        out: dict[str, Any] = {}
        for f in self._fields:
            w = self._inputs[f.name]
            if f.type == "checkbox":
                out[f.name] = bool(w.value)
            elif f.type == "select":
                # Select's blank sentinel is not identity-comparable to the
                # widget's own blank value; use is_blank() (Textual 8.2).
                try:
                    blank = w.is_blank()
                except Exception:
                    blank = w.value is Select.BLANK
                out[f.name] = None if blank else w.value
            elif f.type == "textarea":
                out[f.name] = w.text
            else:
                out[f.name] = w.value.strip()
        return out

    def _submit(self) -> None:
        values = self._collect()
        # required-field check
        for f in self._fields:
            if f.required:
                v = values.get(f.name)
                if v is None or (isinstance(v, str) and not v.strip()):
                    self._show_err(f"{f.label} is required")
                    self._focus(f.name)
                    return
        if self._on_submit is None:
            self.dismiss(values); return
        try:
            res = self._on_submit(values)
        except repo.ValidationError as e:
            self._show_err(str(e)); return
        except Exception as e:  # surface unexpected errors instead of crashing
            self._show_err(str(e) or e.__class__.__name__); return
        if res:
            msg = res.get("error") if isinstance(res, dict) else str(res)
            self._show_err(msg or "Please check the form"); return
        self.dismiss(values)

    def _show_err(self, msg: str) -> None:
        try:
            self.query_one("#form-err", Static).update(msg)
        except Exception:
            pass

    def _focus(self, name: str) -> None:
        try:
            self._inputs[name].focus()
        except Exception:
            pass


class ConfirmModal(ModalScreen[bool]):
    """A yes/no dialog. Result delivered via dismiss(bool)."""
    DEFAULT_CSS = """
    ConfirmModal { align: center middle; background: black 55%; }
    ConfirmModal > #confirm-card {
        background: #0c0e10; border: thick #20fd14; padding: 1 2; width: 52; height: auto;
    }
    ConfirmModal .dialog-title { color: #eeeeee; padding: 0 0 1 0; }
    ConfirmModal #confirm-buttons { padding: 1 0 0 0; height: auto; align-horizontal: right; }
    ConfirmModal #confirm-buttons Button { margin: 0 0 0 2; min-width: 10; }
    """
    BINDINGS = [("escape", "no", "No"), ("y", "yes", "Yes"), ("n", "no", "No")]

    def __init__(self, message: str, yes_label: str = "Yes", no_label: str = "Cancel",
                 danger: bool = True):
        super().__init__()
        self._message = message
        self._yes = yes_label
        self._no = no_label
        self._danger = danger

    def compose(self) -> ComposeResult:
        with Vertical(id="confirm-card"):
            yield Static(self._message, classes="dialog-title")
            with Horizontal(id="confirm-buttons"):
                yield Button(self._no, id="btn-no")
                yield Button(self._yes, id="btn-yes",
                             classes="-danger" if self._danger else "-primary")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        self.dismiss(event.button.id == "btn-yes")

    def action_yes(self) -> None:
        self.dismiss(True)

    def action_no(self) -> None:
        self.dismiss(False)


# --------------------------------------------------------------------------- #
# helpers
# --------------------------------------------------------------------------- #
def _norm_options(options: Iterable):
    out = []
    for o in options:
        if isinstance(o, (tuple, list)) and len(o) == 2:
            out.append((str(o[0]), o[1]))
        else:
            out.append((str(o), o))
    return out


def _default_ph(ftype: str) -> str:
    return {"time": "HH:MM", "date": "YYYY-MM-DD", "color": "#20fd14"}.get(ftype, "")


def category_options() -> list[tuple[str, str]]:
    return [(c["label"], c["id"]) for c in repo.CATEGORIES]


def toast(app, message: str, kind: str = "information") -> None:
    """kind: information|warning|error. Thin wrapper over App.notify."""
    sev = {"information": "information", "info": "information",
           "warning": "warning", "warn": "warning",
           "error": "error", "ok": "information"}.get(kind, "information")
    try:
        app.notify(message, severity=sev)
    except Exception:
        pass


__all__ = [
    "PlannerView", "DayPanel", "Section", "Field", "FormModal", "ConfirmModal",
    "category_options", "toast",
]
