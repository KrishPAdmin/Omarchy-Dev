"""app.py - MyDayApp: the Textual application (chrome, routing, clock, idle).

Owns the shared chrome (#topbar with live clock, #view-root, #statusbar,
Footer), the active-date/active-view state, global key bindings, and the
idle -> screensaver + nightly-dark trigger. Views and day-panels are supplied
by build agents and discovered through myday.registry.

Public app surface used by views/panels/widgets:
    app.day                      -> 'YYYY-MM-DD' active date (reactive)
    app.settings                 -> myday.config.Settings
    app.set_date(day)            -> change active date (refreshes view)
    app.set_view(view_id)        -> switch top-level view
    app.shift(+1|-1)             -> step date by the active view's NAV_STEP
    app.go_today()               -> jump to today
    app.refresh_active()         -> re-render the current view
    app.set_status(text)         -> write the bottom status bar
    app.open_form(modal)/confirm(msg) helpers live in myday.ui
"""
from __future__ import annotations

import os
from time import monotonic

from textual import events
from textual.app import App, ComposeResult
from textual.containers import Horizontal
from textual.reactive import reactive
from textual.widgets import ContentSwitcher, Footer, Static

from . import config, dates, repo
from . import registry

_HERE = os.path.dirname(__file__)


# --------------------------------------------------------------------------- #
# chrome widgets
# --------------------------------------------------------------------------- #
class TopBar(Horizontal):
    def compose(self) -> ComposeResult:
        yield Static("◈ MyDay", classes="brand", id="brand")
        yield Static("", classes="rangelabel", id="rangelabel")
        yield Static("", id="clock")


class StatusBar(Static):
    pass


# --------------------------------------------------------------------------- #
# app
# --------------------------------------------------------------------------- #
class MyDayApp(App):
    CSS_PATH = os.path.join(_HERE, "theme.tcss")
    TITLE = "MyDay"

    BINDINGS = [
        ("q", "quit", "Quit"),
        ("left,h", "prev", "◀ Prev"),
        ("right,l", "next", "Next ▶"),
        ("t", "today", "Today"),
        ("g", "goto", "Go to date"),
        ("d", "view('day')", "Day"),
        ("w", "view('week')", "Week"),
        ("m", "view('month')", "Month"),
        ("y", "view('year')", "Year"),
        ("p", "view('plan')", "Plan"),
        ("tab", "cycle(1)", "Next view"),
        ("shift+tab", "cycle(-1)", "Prev view"),
        ("s", "screensaver", "Screensaver"),
        ("r", "refresh", "Refresh"),
        ("question_mark", "help", "Help"),
    ]

    day: reactive[str] = reactive(dates.today, always_update=True)
    view_id: reactive[str] = reactive("")

    def __init__(self, start_view: str | None = None, **kwargs):
        super().__init__(**kwargs)
        self.settings = config.load_settings()
        self._start_view = start_view
        self._last_input = monotonic()
        self._saver_active = False
        self._view_instances: dict[str, object] = {}

    # --- lifecycle -------------------------------------------------------- #
    def on_mount(self) -> None:
        repo.init()
        # ensure the app's view/panel modules are imported & self-registered
        _load_modules()
        self._build_views()
        views = registry.get_views()
        first = self._start_view if (self._start_view and registry.get_view(self._start_view)) else None
        if not first:
            first = views[0].VIEW_ID if views else ""
        self.day = dates.today()
        self.set_view(first)
        self.set_interval(1.0, self._tick)          # clock + idle + night
        self._update_clock()

    def compose(self) -> ComposeResult:
        yield TopBar(id="topbar")
        yield ContentSwitcher(id="view-root")
        yield StatusBar("", id="statusbar")
        yield Footer()

    def _build_views(self) -> None:
        switcher = self.query_one("#view-root", ContentSwitcher)
        views = registry.get_views()
        if not views:
            switcher.mount(Static(
                "No views registered.\nBuild agents populate myday/screens/*.",
                id="view-empty"))
            return
        for cls in views:
            try:
                inst = cls()
                inst.id = f"view-{cls.VIEW_ID}"
                self._view_instances[cls.VIEW_ID] = inst
                switcher.mount(inst)
            except Exception as e:  # never let one bad view kill the app
                ph = Static(f"[{cls.VIEW_ID}] failed to build:\n{e}", id=f"view-{cls.VIEW_ID}")
                switcher.mount(ph)

    # --- state ------------------------------------------------------------ #
    def set_date(self, day: str) -> None:
        if dates.is_valid(day):
            self.day = day

    def set_view(self, view_id: str) -> None:
        if not registry.get_view(view_id) and view_id not in self._view_instances:
            return
        self.view_id = view_id

    def go_today(self) -> None:
        self.set_date(dates.today())

    def shift(self, delta: int) -> None:
        cls = registry.get_view(self.view_id)
        step = getattr(cls, "NAV_STEP", "day") if cls else "day"
        if step == "day":
            self.set_date(dates.add(self.day, delta))
        elif step == "week":
            self.set_date(dates.add(self.day, 7 * delta))
        elif step == "month":
            self.set_date(dates.add_months(self.day, delta))
        elif step == "year":
            self.set_date(dates.add_years(self.day, delta))
        else:
            self.set_date(dates.add(self.day, delta))

    def refresh_active(self) -> None:
        inst = self._view_instances.get(self.view_id)
        if inst is not None and hasattr(inst, "refresh_view"):
            try:
                inst.refresh_view()
            except Exception as e:
                self.notify(f"view error: {e}", severity="error")
        self._update_rangelabel()

    def set_status(self, text: str) -> None:
        try:
            self.query_one("#statusbar", StatusBar).update(text)
        except Exception:
            pass

    # --- reactive watchers ------------------------------------------------ #
    def watch_day(self, _old: str, _new: str) -> None:
        if self.is_running:
            self.refresh_active()

    def watch_view_id(self, _old: str, new: str) -> None:
        if not self.is_running or not new:
            return
        try:
            self.query_one("#view-root", ContentSwitcher).current = f"view-{new}"
        except Exception:
            return
        self.refresh_active()

    # --- clock / idle / night -------------------------------------------- #
    def _tick(self) -> None:
        self._update_clock()
        idle = monotonic() - self._last_input
        if (not self._saver_active
                and self.settings.idle_seconds > 0
                and idle >= self.settings.idle_seconds
                and len(self.screen_stack) == 1):
            self._enter_screensaver()

    def _update_clock(self) -> None:
        try:
            self.query_one("#clock", Static).update(
                dates.clock_str(clock_24h=self.settings.clock_24h, seconds=True))
        except Exception:
            pass

    def _update_rangelabel(self) -> None:
        inst = self._view_instances.get(self.view_id)
        label = self.day
        if inst is not None and hasattr(inst, "range_label"):
            try:
                label = inst.range_label(self.day)
            except Exception:
                pass
        try:
            self.query_one("#rangelabel", Static).update(label)
        except Exception:
            pass

    # --- screensaver ------------------------------------------------------ #
    def _enter_screensaver(self) -> None:
        if self._saver_active:
            return
        try:
            from .screensaver.engine import ScreensaverScreen
        except Exception:
            return  # engine not present yet (dev) - just skip
        self._saver_active = True

        def _closed(_result=None) -> None:
            self._saver_active = False
            self._last_input = monotonic()

        try:
            self.push_screen(ScreensaverScreen(), _closed)
        except Exception:
            self._saver_active = False

    # --- global input activity tracking ---------------------------------- #
    async def on_event(self, event: events.Event) -> None:
        if isinstance(event, (events.Key, events.MouseDown, events.MouseMove,
                              events.MouseScrollDown, events.MouseScrollUp,
                              events.Paste, events.Click)):
            self._last_input = monotonic()
        await super().on_event(event)

    # --- actions ---------------------------------------------------------- #
    def action_prev(self) -> None:
        self.shift(-1)

    def action_next(self) -> None:
        self.shift(1)

    def action_today(self) -> None:
        self.go_today()

    def action_view(self, view_id: str) -> None:
        self.set_view(view_id)

    def action_cycle(self, delta: int) -> None:
        views = [c.VIEW_ID for c in registry.get_views()]
        if not views:
            return
        try:
            i = views.index(self.view_id)
        except ValueError:
            i = 0
        self.set_view(views[(i + delta) % len(views)])

    def action_refresh(self) -> None:
        self.refresh_active()

    def action_screensaver(self) -> None:
        self._enter_screensaver()

    def action_goto(self) -> None:
        from .ui import FormModal, Field

        def _submit(values):
            d = values.get("day", "").strip()
            if not dates.is_valid(d):
                return "enter a valid YYYY-MM-DD date"
            self.set_date(d)
            return None

        self.push_screen(FormModal(
            "Go to date",
            [Field("day", "Date (YYYY-MM-DD)", "date", required=True)],
            values={"day": self.day}, submit_label="Go", on_submit=_submit))

    def action_help(self) -> None:
        from .ui import ConfirmModal
        text = (
            "MyDay - keys\n\n"
            "  ◀ / ▶   h l   step date/period\n"
            "  d w m y p     Day Week Month Year Plan\n"
            "  tab           cycle views\n"
            "  t             jump to today\n"
            "  g             go to a date\n"
            "  s             screensaver now\n"
            "  r             refresh\n"
            "  q             quit\n\n"
            "Idle 5 min -> pixel screensaver. 10pm-6am -> dark."
        )
        self.push_screen(ConfirmModal(text, yes_label="OK", no_label="Close", danger=False))


# --------------------------------------------------------------------------- #
# module loading - import view/panel modules so they self-register
# --------------------------------------------------------------------------- #
def _load_modules() -> None:
    """Import every screen/widget module that self-registers a view or panel.

    Best-effort: a missing or broken module is skipped (with a note) so the app
    still runs. Build agents just drop their file in and add it here is NOT
    required - we import the packages' known module names defensively.
    """
    import importlib
    modules = [
        # top-level views
        "myday.screens.today", "myday.screens.day", "myday.screens.week",
        "myday.screens.month", "myday.screens.year", "myday.screens.plan",
        # day panels
        "myday.panels.food", "myday.panels.fitness",
        "myday.panels.habits", "myday.panels.journal", "myday.panels.metrics",
    ]
    for m in modules:
        try:
            importlib.import_module(m)
        except Exception:
            pass


def run(start_view: str | None = None) -> None:
    MyDayApp(start_view=start_view).run()


__all__ = ["MyDayApp", "run"]
