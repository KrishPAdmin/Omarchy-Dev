"""MyDay screensaver: idle detection host + pixel effects + nightly dark."""
