"""engine.py - the screensaver host.

:class:`ScreensaverScreen` is a full-screen ``ModalScreen`` the app pushes after
5 minutes idle. It:

* picks a random pixel effect and animates a ``Static`` at ~13 fps;
* rotates to a *different* random effect every ``settings.rotate_seconds``;
* shows a faint clock at the bottom;
* dismisses on ANY key / mouse click / (real) mouse move, returning to the app;
* honours the nightly dark window: while ``config.in_night_window()`` is true and
  ``settings.night_dark``, the animation stops and the screen goes almost black
  (a barely-visible dim clock only) with the ``night`` CSS class applied.

The render loop body is wrapped so a buggy effect can never crash the app - it
degrades to a solid dark field.

``run_standalone()`` shows the screensaver immediately in a tiny throwaway app
for ``myday screensaver`` (preview / test).
"""
from __future__ import annotations

from time import monotonic

from textual import events
from textual.app import App, ComposeResult
from textual.screen import ModalScreen
from textual.widgets import Static
from rich.text import Text

from .. import config, dates, palette
from .effects import get_effects

FPS = 13
_INTERVAL = 1.0 / FPS
NIGHT_CLOCK_COLOR = "#071006"   # barely visible dim clock during blackout


class ScreensaverScreen(ModalScreen):
    """Full-screen pixel screensaver overlay."""

    DEFAULT_CSS = """
    ScreensaverScreen {
        layers: field clock;
        background: #000000;
    }
    ScreensaverScreen > #screensaver {
        layer: field;
        width: 100%;
        height: 100%;
        background: #000000;
        color: #20fd14;
    }
    ScreensaverScreen > #screensaver.night {
        color: #071006;
        background: #000000;
    }
    ScreensaverScreen > #saver-clock {
        layer: clock;
        dock: bottom;
        width: 100%;
        height: 1;
        content-align: center middle;
        color: #0e7a08;
        background: transparent;
    }
    ScreensaverScreen > #saver-clock.night {
        color: #071006;
    }
    """

    def __init__(self) -> None:
        super().__init__()
        self._settings = None
        self._factories = []
        self._effect = None
        self._effect_name = ""
        self._frame = 0
        self._rot_start = 0
        self._mounted_at = 0.0
        self._dismissed = False
        self._rng = None
        self._night = False

    # --- settings / eligible effects ------------------------------------- #
    def _load_settings(self):
        s = getattr(self.app, "settings", None)
        if s is None:
            s = config.load_settings()
        return s

    def _pick_effect(self, avoid: str | None = None):
        import random
        rng = self._rng
        names = [f.name for f in self._factories]
        pool = self._factories
        if avoid and len(pool) > 1:
            pool = [f for f in self._factories if f.name != avoid] or self._factories
        factory = rng.choice(pool)
        # vary the per-effect seed run-to-run so it isn't identical each rotate
        self._effect = factory(rng.randint(0, 1_000_000))
        self._effect_name = factory.name
        self._frame = 0
        self._rot_start = monotonic()

    # --- lifecycle -------------------------------------------------------- #
    def compose(self) -> ComposeResult:
        yield Static("", id="screensaver")
        yield Static("", id="saver-clock")

    def on_mount(self) -> None:
        import random
        self._settings = self._load_settings()
        self._rng = random.Random()
        self._factories = get_effects(tuple(getattr(self._settings, "effects", ()) or ()))
        self._pick_effect()
        self._mounted_at = monotonic()
        self.set_interval(_INTERVAL, self._tick)
        # paint one frame immediately so we never flash empty
        self._tick()

    # --- the render loop -------------------------------------------------- #
    def _rotate_seconds(self) -> int:
        try:
            return max(5, int(getattr(self._settings, "rotate_seconds", 60)))
        except Exception:
            return 60

    def _tick(self) -> None:
        try:
            self._render_frame()
        except Exception:
            # never crash the app - degrade to a solid dark field
            try:
                w = max(1, self.size.width)
                h = max(1, self.size.height)
                blank = Text("\n".join(" " * w for _ in range(h)),
                             no_wrap=True, end="")
                self.query_one("#screensaver", Static).update(blank)
            except Exception:
                pass

    def _render_frame(self) -> None:
        w = max(1, self.size.width)
        h = max(1, self.size.height)
        field = self.query_one("#screensaver", Static)
        clock_w = self.query_one("#saver-clock", Static)

        # nightly blackout takes over
        night = False
        try:
            night = bool(config.in_night_window(settings=self._settings))
        except Exception:
            night = False

        clock = dates.clock_str(
            clock_24h=getattr(self._settings, "clock_24h", False), seconds=False)

        if night:
            if not self._night:
                field.add_class("night")
                clock_w.add_class("night")
                self._night = True
            # near-black field with a centred, barely-visible dim clock
            field.update(self._dark_field(w, h, clock))
            clock_w.update("")
            return

        if self._night:
            field.remove_class("night")
            clock_w.remove_class("night")
            self._night = False

        # rotate to a different effect after rotate_seconds
        if monotonic() - self._rot_start >= self._rotate_seconds():
            self._pick_effect(avoid=self._effect_name)

        payload = self._effect.render(w, h, self._frame)
        field.update(payload)
        clock_w.update(Text(f" {clock} ", style=palette.ACCENT_DEEP))
        self._frame += 1

    def _dark_field(self, w: int, h: int, clock: str) -> Text:
        """Almost-black screen with one dim clock line near the middle."""
        lines = []
        mid = h // 2
        for y in range(h):
            if y == mid and w >= len(clock):
                pad = (w - len(clock)) // 2
                lines.append(" " * pad + clock + " " * (w - pad - len(clock)))
            else:
                lines.append(" " * w)
        t = Text("\n".join(lines), no_wrap=True, end="")
        t.stylize(NIGHT_CLOCK_COLOR)
        return t

    # --- dismissal (any input returns to the app) ------------------------- #
    def _leave(self) -> None:
        if self._dismissed:
            return
        self._dismissed = True
        try:
            self.dismiss(None)
        except Exception:
            pass

    def on_key(self, event: events.Key) -> None:
        event.stop()
        self._leave()

    def on_mouse_down(self, event: events.MouseDown) -> None:
        event.stop()
        self._leave()

    def on_click(self, event: events.Click) -> None:
        event.stop()
        self._leave()

    def on_mouse_move(self, event: events.MouseMove) -> None:
        # ignore synthetic / settling moves in the first moment after mount so a
        # resting cursor doesn't instantly dismiss the saver
        if monotonic() - self._mounted_at < 0.4:
            return
        self._leave()


# --------------------------------------------------------------------------- #
# standalone preview app (`myday screensaver`)
# --------------------------------------------------------------------------- #
class _SaverApp(App):
    import os as _os
    CSS_PATH = _os.path.join(_os.path.dirname(_os.path.dirname(__file__)), "theme.tcss")

    def on_mount(self) -> None:
        self.settings = config.load_settings()

        def _closed(_result=None) -> None:
            self.exit()

        self.push_screen(ScreensaverScreen(), _closed)


def run_standalone() -> None:
    """Run the screensaver by itself (for previewing / testing)."""
    _SaverApp().run()


__all__ = ["ScreensaverScreen", "run_standalone"]
