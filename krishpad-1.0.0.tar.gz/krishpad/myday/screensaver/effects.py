"""effects.py - a library of neon-green pixel screensaver effects.

Every effect is pure-Python (stdlib + rich, which ships with Textual). No extra
deps. Each effect renders a full-screen grid of coloured "pixels" (block and
shading glyphs) using the brand green ramp from :mod:`myday.palette`, on pure
black.

Design
------
* :class:`Effect` is the base. ``render(width, height, frame) -> rich.Text``
  returns a Textual ``Static`` update payload sized exactly ``width`` x
  ``height`` (rows joined with ``\\n``). It must never raise and must survive
  tiny terminals (e.g. 20x6) - callers additionally wrap it, but we degrade
  gracefully on our own.
* Randomness goes through ``self.rng`` (a seedable ``random.Random``) and frame
  numbers - never real wall-clock time - so effects are deterministic for a
  given seed + frame and are unit-testable.
* Stateful effects (rain, pipes, life, ...) lazily (re)seed their state when the
  surface size changes via :meth:`Effect._ensure`.

Registry
--------
``ALL_EFFECTS`` maps ``name -> factory`` where a factory is ``factory(seed=0)``
returning an :class:`Effect`. ``get_effects(names=())`` returns the list of
factories (empty ``names`` => all).
"""
from __future__ import annotations

import math
import random
from typing import Callable

from rich.text import Text

from .. import palette

# --------------------------------------------------------------------------- #
# palette helpers
# --------------------------------------------------------------------------- #
RAMP = list(palette.GREEN_RAMP)          # dark -> bright, 7 stops
NR = len(RAMP)
ACCENT = palette.ACCENT                   # "#20fd14"
BRIGHT = RAMP[-1]                          # "#9dffa0"
BG = palette.BG                            # "#000000"

# shading glyphs, dark -> solid ("pixel" texture)
SHADE = [" ", "░", "▒", "▓", "█"]  # ' ░▒▓█'
# half / full blocks used to read as pixels
BLOCK = "█"     # █
UPPER = "▀"     # ▀
LOWER = "▄"     # ▄

# matrix-rain glyph soup (katakana-ish + latin + digits) for the falling look
GLYPHS = (
    "ｱｲｳｴｵｶｷｸｹｺｻｼ"
    "ｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈ"
    "0123456789ABCDEFGHKLMNXYZ+*<>=/\\|"
)


def ramp_color(b: float) -> str:
    """Map brightness ``b`` in [0, 1] to a green-ramp hex colour."""
    if b <= 0:
        return RAMP[0]
    if b >= 1:
        return RAMP[NR - 1]
    return RAMP[min(NR - 1, int(b * NR))]


def shade_char(b: float) -> str:
    """Map brightness ``b`` in [0, 1] to a shading glyph."""
    if b <= 0:
        return " "
    return SHADE[min(len(SHADE) - 1, int(b * len(SHADE)))]


# --------------------------------------------------------------------------- #
# pixel buffer -> rich.Text (run-length coalesced for speed)
# --------------------------------------------------------------------------- #
class Buf:
    """A width x height grid of (char, colour) that renders to a rich ``Text``."""

    __slots__ = ("w", "h", "ch", "fg")

    def __init__(self, w: int, h: int):
        self.w = w
        self.h = h
        self.ch = [[" "] * w for _ in range(h)]
        self.fg: list[list[str | None]] = [[None] * w for _ in range(h)]

    def set(self, x: int, y: int, ch: str, color: str | None) -> None:
        if 0 <= x < self.w and 0 <= y < self.h:
            self.ch[y][x] = ch
            self.fg[y][x] = color

    def text(self, x: int, y: int, s: str, color: str | None) -> None:
        for i, c in enumerate(s):
            self.set(x + i, y, c, color)

    def to_text(self) -> Text:
        out = Text(no_wrap=True, end="")
        append = out.append
        for y in range(self.h):
            if y:
                append("\n")
            row_ch = self.ch[y]
            row_fg = self.fg[y]
            w = self.w
            x = 0
            while x < w:
                color = row_fg[x]
                x2 = x + 1
                while x2 < w and row_fg[x2] == color:
                    x2 += 1
                seg = "".join(row_ch[x:x2])
                if color:
                    append(seg, style=color)
                else:
                    append(seg)
                x = x2
        return out


# --------------------------------------------------------------------------- #
# base effect
# --------------------------------------------------------------------------- #
class Effect:
    name = "base"

    def __init__(self, seed: int = 0):
        self.seed = seed
        self.rng = random.Random(seed)
        self._w = 0
        self._h = 0

    # subclasses override to (re)build size-dependent state
    def _init(self, w: int, h: int) -> None:  # pragma: no cover - trivial
        pass

    def _ensure(self, w: int, h: int) -> None:
        if w != self._w or h != self._h:
            self._w, self._h = w, h
            self.rng = random.Random(self.seed)
            self._init(w, h)

    def render(self, width: int, height: int, frame: int) -> Text:
        w = max(1, int(width))
        h = max(1, int(height))
        self._ensure(w, h)
        buf = Buf(w, h)
        self.draw(buf, frame)
        return buf.to_text()

    # subclasses implement
    def draw(self, buf: Buf, frame: int) -> None:  # pragma: no cover - abstract
        raise NotImplementedError


# --------------------------------------------------------------------------- #
# 1. Matrix rain
# --------------------------------------------------------------------------- #
class MatrixRain(Effect):
    name = "matrix"

    def _init(self, w: int, h: int) -> None:
        self.speed = [self.rng.uniform(0.25, 0.9) for _ in range(w)]
        self.length = [self.rng.randint(4, max(5, h)) for _ in range(w)]
        self.offset = [self.rng.uniform(0, h + 8) for _ in range(w)]
        self.on = [self.rng.random() > 0.18 for _ in range(w)]  # some cols idle

    def draw(self, buf: Buf, frame: int) -> None:
        h = buf.h
        for x in range(buf.w):
            if not self.on[x]:
                continue
            L = self.length[x]
            cycle = h + L
            pos = (self.offset[x] + frame * self.speed[x]) % cycle
            head = pos
            for k in range(L):
                yy = int(head) - k
                if 0 <= yy < h:
                    g = GLYPHS[(x * 31 + yy * 7 + (frame // 2) * 13 + self.seed)
                               % len(GLYPHS)]
                    if k == 0:
                        buf.set(x, yy, g, BRIGHT)
                    elif k == 1:
                        buf.set(x, yy, g, ACCENT)
                    else:
                        b = 1.0 - k / L
                        buf.set(x, yy, g, ramp_color(b * 0.7))


# --------------------------------------------------------------------------- #
# 2. Pixel pipes / maze (Omarchy-style growing pipes)
# --------------------------------------------------------------------------- #
_H, _V = "─", "│"           # ─ │
_TL, _TR = "┌", "┐"          # ┌ ┐
_BL, _BR = "└", "┘"          # └ ┘
_DIRS = [(1, 0), (-1, 0), (0, 1), (0, -1)]


def _corner(old: tuple[int, int], new: tuple[int, int]) -> str:
    # glyph joining an incoming direction `old` to outgoing `new`
    m = {
        ((1, 0), (0, 1)): _TR, ((0, -1), (-1, 0)): _TR,
        ((1, 0), (0, -1)): _BR, ((0, 1), (-1, 0)): _BR,
        ((-1, 0), (0, 1)): _TL, ((0, -1), (1, 0)): _TL,
        ((-1, 0), (0, -1)): _BL, ((0, 1), (1, 0)): _BL,
    }
    return m.get((old, new), _H if new[0] else _V)


class Pipes(Effect):
    name = "pipes"

    def _init(self, w: int, h: int) -> None:
        self.cells_ch = [[" "] * w for _ in range(h)]
        self.cells_fg: list[list[str | None]] = [[None] * w for _ in range(h)]
        self.filled = 0
        self.pipes: list[dict] = []
        n = max(2, min(5, w // 20 + 2))
        for _ in range(n):
            self._spawn()

    def _spawn(self) -> None:
        w, h = self._w, self._h
        self.pipes.append({
            "x": self.rng.randint(0, max(0, w - 1)),
            "y": self.rng.randint(0, max(0, h - 1)),
            "d": self.rng.choice(_DIRS),
            "c": RAMP[self.rng.randint(2, NR - 1)],
        })

    def _clear(self) -> None:
        for row in self.cells_ch:
            for i in range(len(row)):
                row[i] = " "
        for row in self.cells_fg:
            for i in range(len(row)):
                row[i] = None
        self.filled = 0

    def _step_pipe(self, p: dict) -> None:
        w, h = self._w, self._h
        old = p["d"]
        if self.rng.random() < 0.18:
            if old[0] != 0:
                p["d"] = (0, self.rng.choice((1, -1)))
            else:
                p["d"] = (self.rng.choice((1, -1)), 0)
        x, y = p["x"], p["y"]
        if self.cells_ch[y][x] == " ":
            glyph = _corner(old, p["d"]) if old != p["d"] else (
                _H if p["d"][0] else _V)
            self.cells_ch[y][x] = glyph
            self.cells_fg[y][x] = p["c"]
            self.filled += 1
        nx, ny = x + p["d"][0], y + p["d"][1]
        if not (0 <= nx < w and 0 <= ny < h):
            # respawn this pipe at a fresh spot / colour
            p["x"] = self.rng.randint(0, w - 1)
            p["y"] = self.rng.randint(0, h - 1)
            p["d"] = self.rng.choice(_DIRS)
            p["c"] = RAMP[self.rng.randint(2, NR - 1)]
        else:
            p["x"], p["y"] = nx, ny

    def draw(self, buf: Buf, frame: int) -> None:
        w, h = buf.w, buf.h
        if self.filled > w * h * 0.6:
            self._clear()
        for p in self.pipes:
            self._step_pipe(p)
            self._step_pipe(p)  # two cells / frame -> livelier growth
        for y in range(h):
            src_ch = self.cells_ch[y]
            src_fg = self.cells_fg[y]
            for x in range(w):
                if src_ch[x] != " ":
                    buf.set(x, y, src_ch[x], src_fg[x])
        # bright heads
        for p in self.pipes:
            buf.set(p["x"], p["y"], BLOCK, BRIGHT)


# --------------------------------------------------------------------------- #
# 3. Conway's Game of Life
# --------------------------------------------------------------------------- #
class Life(Effect):
    name = "life"

    def _init(self, w: int, h: int) -> None:
        self.grid = [[1 if self.rng.random() < 0.28 else 0
                      for _ in range(w)] for _ in range(h)]
        self.last_change = 0

    def _seed(self) -> None:
        w, h = self._w, self._h
        self.grid = [[1 if self.rng.random() < 0.28 else 0
                      for _ in range(w)] for _ in range(h)]

    def draw(self, buf: Buf, frame: int) -> None:
        w, h = buf.w, buf.h
        g = self.grid
        pop = 0
        counts = [[0] * w for _ in range(h)]
        for y in range(h):
            gy = g[y]
            up = g[(y - 1) % h]
            dn = g[(y + 1) % h]
            for x in range(w):
                xl = (x - 1) % w
                xr = (x + 1) % w
                n = (up[xl] + up[x] + up[xr] + gy[xl] + gy[xr]
                     + dn[xl] + dn[x] + dn[xr])
                counts[y][x] = n
        ng = self.grid
        new = [[0] * w for _ in range(h)]
        for y in range(h):
            for x in range(w):
                n = counts[y][x]
                alive = ng[y][x]
                nv = 1 if (alive and (n == 2 or n == 3)) or (not alive and n == 3) else 0
                new[y][x] = nv
                if nv:
                    pop += 1
                    buf.set(x, y, BLOCK, ramp_color(0.35 + 0.16 * n))
        self.grid = new
        # reseed a stagnant / dead board
        if pop < max(3, int(w * h * 0.02)) or (frame % 600 == 0 and frame):
            self._seed()


# --------------------------------------------------------------------------- #
# 4. Starfield / warp
# --------------------------------------------------------------------------- #
class Starfield(Effect):
    name = "starfield"

    def _init(self, w: int, h: int) -> None:
        n = max(24, (w * h) // 20)
        self.stars = [self._new_star() for _ in range(n)]

    def _new_star(self) -> dict:
        return {
            "a": self.rng.uniform(0, math.tau),
            "r": self.rng.uniform(0.2, 3.0),
            "s": self.rng.uniform(0.05, 0.25),
        }

    def draw(self, buf: Buf, frame: int) -> None:
        w, h = buf.w, buf.h
        cx, cy = w / 2.0, h / 2.0
        maxr = math.hypot(cx, cy) + 1
        glyphs = [".", "·", "░", "▒", "▓", "█"]
        for st in self.stars:
            st["r"] *= (1.0 + st["s"])
            r = st["r"]
            x = int(cx + math.cos(st["a"]) * r)
            y = int(cy + math.sin(st["a"]) * r * 0.55)
            if not (0 <= x < w and 0 <= y < h) or r > maxr:
                st.update(self._new_star())
                st["r"] = self.rng.uniform(0.2, 1.0)
                continue
            b = min(1.0, r / maxr)
            buf.set(x, y, glyphs[min(len(glyphs) - 1, int(b * len(glyphs)))],
                    ramp_color(0.2 + 0.8 * b))


# --------------------------------------------------------------------------- #
# 5. Bouncing "K" box (DVD-logo style, hue drifts within the green ramp)
# --------------------------------------------------------------------------- #
class BounceK(Effect):
    name = "dvd"

    def _init(self, w: int, h: int) -> None:
        self.bw = max(3, min(11, w // 6))
        self.bh = max(2, min(5, h // 5))
        self.x = float(self.rng.randint(0, max(0, w - self.bw)))
        self.y = float(self.rng.randint(0, max(0, h - self.bh)))
        self.vx = self.rng.choice((-0.9, 0.9))
        self.vy = self.rng.choice((-0.5, 0.5))
        self.hue = self.rng.randint(2, NR - 1)

    def draw(self, buf: Buf, frame: int) -> None:
        w, h = buf.w, buf.h
        bw = min(self.bw, w)
        bh = min(self.bh, h)
        self.x += self.vx
        self.y += self.vy
        bounced = False
        if self.x <= 0:
            self.x = 0
            self.vx = abs(self.vx)
            bounced = True
        elif self.x + bw >= w:
            self.x = w - bw
            self.vx = -abs(self.vx)
            bounced = True
        if self.y <= 0:
            self.y = 0
            self.vy = abs(self.vy)
            bounced = True
        elif self.y + bh >= h:
            self.y = h - bh
            self.vy = -abs(self.vy)
            bounced = True
        if bounced:
            self.hue = (self.hue + 1 - 2) % (NR - 2) + 2  # cycle 2..NR-1
        color = RAMP[self.hue]
        ox, oy = int(self.x), int(self.y)
        for j in range(bh):
            for i in range(bw):
                edge = i == 0 or j == 0 or i == bw - 1 or j == bh - 1
                buf.set(ox + i, oy + j, BLOCK if edge else " ",
                        color if edge else None)
        # letter K in the middle (bright)
        buf.set(ox + bw // 2, oy + bh // 2, "K", BRIGHT)


# --------------------------------------------------------------------------- #
# 6. Plasma / sine field (the "pixelated movement" look)
# --------------------------------------------------------------------------- #
class Plasma(Effect):
    name = "plasma"

    def draw(self, buf: Buf, frame: int) -> None:
        w, h = buf.w, buf.h
        f = frame * 0.12
        cx, cy = w / 2.0, h / 2.0
        for y in range(h):
            sy = math.sin(y / 6.0 - f * 1.3)
            for x in range(w):
                v = (math.sin(x / 8.0 + f)
                     + sy
                     + math.sin((x + y) / 10.0 + f * 0.7)
                     + math.sin(math.hypot(x - cx, (y - cy) * 1.8) / 6.0 - f))
                b = (v + 4.0) / 8.0  # -> 0..1
                buf.set(x, y, shade_char(b), ramp_color(b))


# --------------------------------------------------------------------------- #
# 7. Bouncing balls / pixel field (decaying trails => pixel-rain look)
# --------------------------------------------------------------------------- #
class Balls(Effect):
    name = "balls"

    def _init(self, w: int, h: int) -> None:
        n = max(3, min(9, (w * h) // 300 + 3))
        self.field = [[0.0] * w for _ in range(h)]
        self.balls = []
        for _ in range(n):
            self.balls.append({
                "x": self.rng.uniform(1, max(1, w - 2)),
                "y": self.rng.uniform(1, max(1, h - 2)),
                "vx": self.rng.uniform(-1.1, 1.1) or 0.6,
                "vy": self.rng.uniform(-0.7, 0.7) or 0.4,
            })

    def draw(self, buf: Buf, frame: int) -> None:
        w, h = buf.w, buf.h
        fld = self.field
        # decay trails
        for y in range(h):
            row = fld[y]
            for x in range(w):
                if row[x] > 0.02:
                    row[x] *= 0.82
                else:
                    row[x] = 0.0
        for b in self.balls:
            b["x"] += b["vx"]
            b["y"] += b["vy"]
            if b["x"] <= 0 or b["x"] >= w - 1:
                b["vx"] = -b["vx"]
                b["x"] = min(max(b["x"], 0), w - 1)
            if b["y"] <= 0 or b["y"] >= h - 1:
                b["vy"] = -b["vy"]
                b["y"] = min(max(b["y"], 0), h - 1)
            ix, iy = int(b["x"]), int(b["y"])
            if 0 <= iy < h and 0 <= ix < w:
                fld[iy][ix] = 1.0
        for y in range(h):
            row = fld[y]
            for x in range(w):
                v = row[x]
                if v > 0.02:
                    buf.set(x, y, shade_char(v), ramp_color(v))


# --------------------------------------------------------------------------- #
# 8. Pixel rain (solid falling blocks - distinct from glyph matrix)
# --------------------------------------------------------------------------- #
class PixelRain(Effect):
    name = "rain"

    def _init(self, w: int, h: int) -> None:
        self.speed = [self.rng.uniform(0.3, 1.0) for _ in range(w)]
        self.length = [self.rng.randint(2, max(3, h // 2)) for _ in range(w)]
        self.offset = [self.rng.uniform(0, h + 6) for _ in range(w)]
        self.on = [self.rng.random() > 0.25 for _ in range(w)]

    def draw(self, buf: Buf, frame: int) -> None:
        h = buf.h
        for x in range(buf.w):
            if not self.on[x]:
                continue
            L = self.length[x]
            cycle = h + L
            head = (self.offset[x] + frame * self.speed[x]) % cycle
            for k in range(L):
                yy = int(head) - k
                if 0 <= yy < h:
                    b = 1.0 - k / (L + 1)
                    ch = BLOCK if k == 0 else (UPPER if k == 1 else shade_char(b))
                    buf.set(x, yy, ch, BRIGHT if k == 0 else ramp_color(b))


# --------------------------------------------------------------------------- #
# registry
# --------------------------------------------------------------------------- #
_EFFECT_CLASSES = [
    MatrixRain, Pipes, Life, Starfield, BounceK, Plasma, Balls, PixelRain,
]

ALL_EFFECTS: dict[str, Callable[..., Effect]] = {
    cls.name: cls for cls in _EFFECT_CLASSES
}


def get_effects(names: tuple[str, ...] = ()) -> list[Callable[..., Effect]]:
    """Return effect factories. Empty ``names`` => all effects.

    Unknown names are ignored; if nothing matches, falls back to all so the
    screensaver always has something to show.
    """
    if not names:
        return list(ALL_EFFECTS.values())
    chosen = [ALL_EFFECTS[n] for n in names if n in ALL_EFFECTS]
    return chosen or list(ALL_EFFECTS.values())


__all__ = [
    "Effect", "Buf", "ALL_EFFECTS", "get_effects",
    "ramp_color", "shade_char", "RAMP", "ACCENT",
    "MatrixRain", "Pipes", "Life", "Starfield", "BounceK", "Plasma",
    "Balls", "PixelRain",
]
