"""config.py - paths and user settings for MyDay (the terminal planner).

Single source of truth for where data lives and for tunable behaviour
(idle timeout, screensaver rotation, the nightly dark window, week start).

Settings load order (later wins):
    1. built-in defaults (below)
    2. ~/.config/myday/config.toml   (or $XDG_CONFIG_HOME/myday/config.toml)
    3. environment overrides (MYDAY_* - handy for tests / one-off launches)

Everything here is pure/stdlib so every other module can import it freely.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, asdict, replace
from datetime import datetime

try:  # py3.11+ ships tomllib; we never hard-fail if the file is absent
    import tomllib  # type: ignore
except ModuleNotFoundError:  # pragma: no cover - very old python
    tomllib = None  # type: ignore

APP_NAME = "myday"


# --------------------------------------------------------------------------- #
# paths (XDG-aware, with sane ~/.local fallbacks)
# --------------------------------------------------------------------------- #
def _xdg(env: str, default_rel: str) -> str:
    base = os.environ.get(env)
    if base and os.path.isabs(base):
        return os.path.join(base, APP_NAME)
    return os.path.join(os.path.expanduser("~"), default_rel, APP_NAME)


def data_dir() -> str:
    """Where the SQLite DB and runtime state live (persists)."""
    d = _xdg("XDG_DATA_HOME", ".local/share")
    os.makedirs(d, exist_ok=True)
    return d


def config_dir() -> str:
    d = _xdg("XDG_CONFIG_HOME", ".config")
    os.makedirs(d, exist_ok=True)
    return d


def state_dir() -> str:
    d = _xdg("XDG_STATE_HOME", ".local/state")
    os.makedirs(d, exist_ok=True)
    return d


def db_path() -> str:
    """Absolute path to the planner DB. MYDAY_DB overrides (tests use this)."""
    env = os.environ.get("MYDAY_DB")
    if env:
        parent = os.path.dirname(env)
        if parent:
            os.makedirs(parent, exist_ok=True)
        return env
    return os.path.join(data_dir(), "planner.db")


def config_path() -> str:
    return os.path.join(config_dir(), "config.toml")


# --------------------------------------------------------------------------- #
# settings
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class Settings:
    # WEEK_START: 0=Sunday, 1=Monday. UI convention across the app is Monday.
    week_start: int = 1
    # Idle screensaver: after this many seconds of no input, the app morphs
    # into the pixel screensaver.
    idle_seconds: int = 300           # 5 minutes
    # While the screensaver is up, switch to a different effect every N seconds.
    rotate_seconds: int = 60          # 1 minute
    # Nightly dark window: the screen goes fully dark (a faint dim clock only)
    # between night_start and night_end, wrapping past midnight. Minutes from
    # local midnight: 1320 = 22:00, 360 = 06:00.
    night_start_min: int = 22 * 60
    night_end_min: int = 6 * 60
    # Honour the nightly dark window at all (set false to disable the blackout).
    night_dark: bool = True
    # Which screensaver effects are eligible (empty = all registered effects).
    effects: tuple[str, ...] = ()
    # Textual theme name (only "krishadmin" ships today; kept for future light).
    theme: str = "krishadmin"
    # 12h vs 24h clock display.
    clock_24h: bool = False

    def as_dict(self) -> dict:
        return asdict(self)


_TRUE = {"1", "true", "yes", "on"}
_FALSE = {"0", "false", "no", "off"}


def _coerce(default, raw):
    """Coerce a loaded value to the type of the dataclass default."""
    if isinstance(default, bool):
        if isinstance(raw, bool):
            return raw
        return str(raw).strip().lower() in _TRUE
    if isinstance(default, int):
        return int(raw)
    if isinstance(default, tuple):
        if isinstance(raw, (list, tuple)):
            return tuple(str(x) for x in raw)
        return tuple(s.strip() for s in str(raw).split(",") if s.strip())
    return str(raw)


def _hhmm_to_min(raw) -> int:
    """Accept '22:00' or an int number-of-minutes for the night window."""
    s = str(raw).strip()
    if ":" in s:
        h, m = s.split(":", 1)
        return (int(h) % 24) * 60 + (int(m) % 60)
    return int(s)


def load_settings() -> Settings:
    """Build Settings from defaults + config.toml + MYDAY_* env overrides."""
    values = Settings().as_dict()

    # 1) config.toml
    path = config_path()
    if tomllib is not None and os.path.isfile(path):
        try:
            with open(path, "rb") as fh:
                data = tomllib.load(fh)
        except Exception:
            data = {}
        section = data.get("myday", data)  # allow [myday] table or flat keys
        for key, default in Settings().as_dict().items():
            if key in section:
                if key in ("night_start_min", "night_end_min") and ":" in str(section[key]):
                    values[key] = _hhmm_to_min(section[key])
                else:
                    values[key] = _coerce(default, section[key])
        # friendly aliases in the toml
        if "night_start" in section:
            values["night_start_min"] = _hhmm_to_min(section["night_start"])
        if "night_end" in section:
            values["night_end_min"] = _hhmm_to_min(section["night_end"])

    # 2) env overrides
    env_map = {
        "MYDAY_IDLE_SECONDS": ("idle_seconds", int),
        "MYDAY_ROTATE_SECONDS": ("rotate_seconds", int),
        "MYDAY_NIGHT_START": ("night_start_min", _hhmm_to_min),
        "MYDAY_NIGHT_END": ("night_end_min", _hhmm_to_min),
        "MYDAY_NIGHT_DARK": ("night_dark", lambda v: str(v).lower() in _TRUE),
        "MYDAY_WEEK_START": ("week_start", int),
        "MYDAY_CLOCK_24H": ("clock_24h", lambda v: str(v).lower() in _TRUE),
        "MYDAY_THEME": ("theme", str),
        "MYDAY_EFFECTS": ("effects", lambda v: tuple(s.strip() for s in v.split(",") if s.strip())),
    }
    for env, (key, conv) in env_map.items():
        if env in os.environ and os.environ[env] != "":
            try:
                values[key] = conv(os.environ[env])
            except Exception:
                pass

    values["effects"] = tuple(values.get("effects") or ())
    return Settings(**values)


def in_night_window(now: datetime | None = None, settings: Settings | None = None) -> bool:
    """True if `now` (local) falls in the nightly dark window.

    Handles the normal wrap where start (22:00) is later than end (06:00),
    and the degenerate equal case (start == end -> never)."""
    s = settings or load_settings()
    if not s.night_dark:
        return False
    now = now or datetime.now()
    cur = now.hour * 60 + now.minute
    start, end = s.night_start_min, s.night_end_min
    if start == end:
        return False
    if start < end:                      # same-day window, e.g. 01:00..05:00
        return start <= cur < end
    return cur >= start or cur < end      # wraps midnight, e.g. 22:00..06:00


# A tiny convenience for modules that just want "the current settings once".
def default_settings() -> Settings:
    return load_settings()


__all__ = [
    "APP_NAME", "Settings", "data_dir", "config_dir", "state_dir",
    "db_path", "config_path", "load_settings", "default_settings",
    "in_night_window", "replace",
]
