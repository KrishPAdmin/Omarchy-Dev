"""dates.py - local wall-clock date & time helpers.

Ported from the web app's core.js `App.date` / `App.time`. Everything works
on the app's two primitive types:

    day     : 'YYYY-MM-DD' string (a local calendar date; the DB primary key)
    minutes : int 0..1439, minutes from local midnight (09:00 -> 540)

WEEK STARTS MONDAY (week_start=1) by app convention; helpers take an optional
week_start so a future Sunday-start setting Just Works.
"""
from __future__ import annotations

from datetime import date, datetime, timedelta

_MONTHS = ["January", "February", "March", "April", "May", "June", "July",
           "August", "September", "October", "November", "December"]
_MON_ABBR = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep",
             "Oct", "Nov", "Dec"]
_DOW_ABBR = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]  # Python Mon=0


# --------------------------------------------------------------------------- #
# parse / format
# --------------------------------------------------------------------------- #
def today() -> str:
    return date.today().isoformat()


def parse(day: str) -> date:
    return date.fromisoformat(day)


def to_str(d: date) -> str:
    return d.isoformat()


def is_valid(day: str) -> bool:
    try:
        date.fromisoformat(day)
        return True
    except (TypeError, ValueError):
        return False


# --------------------------------------------------------------------------- #
# arithmetic
# --------------------------------------------------------------------------- #
def add(day: str, n: int) -> str:
    return (parse(day) + timedelta(days=n)).isoformat()


def add_months(day: str, n: int) -> str:
    d = parse(day)
    total = (d.year * 12 + (d.month - 1)) + n
    y, m = divmod(total, 12)
    m += 1
    # clamp day-of-month (e.g. Jan 31 + 1 month -> Feb 28/29)
    dom = min(d.day, _days_in_month(y, m))
    return date(y, m, dom).isoformat()


def add_years(day: str, n: int) -> str:
    d = parse(day)
    y = d.year + n
    dom = min(d.day, _days_in_month(y, d.month))
    return date(y, d.month, dom).isoformat()


def _days_in_month(year: int, month: int) -> int:
    if month == 12:
        nxt = date(year + 1, 1, 1)
    else:
        nxt = date(year, month + 1, 1)
    return (nxt - date(year, month, 1)).days


# --------------------------------------------------------------------------- #
# weeks / months
# --------------------------------------------------------------------------- #
def _dow_index(d: date, week_start: int) -> int:
    """0-based index of `d` within a week that begins on `week_start`
    (0=Sun, 1=Mon)."""
    # Python: Monday=0..Sunday=6. Convert to 0=Sun..6=Sat first.
    sun0 = (d.weekday() + 1) % 7
    return (sun0 - week_start) % 7


def start_of_week(day: str, week_start: int = 1) -> str:
    d = parse(day)
    return (d - timedelta(days=_dow_index(d, week_start))).isoformat()


def week_days(day: str, week_start: int = 1) -> list[str]:
    s = parse(start_of_week(day, week_start))
    return [(s + timedelta(days=i)).isoformat() for i in range(7)]


def month_matrix(day: str, week_start: int = 1) -> list[list[str]]:
    """6x7 grid of day strings covering the month of `day`, including the
    spill-over days from adjacent months (same as core.js monthMatrix)."""
    d = parse(day)
    first = date(d.year, d.month, 1)
    grid_start = first - timedelta(days=_dow_index(first, week_start))
    weeks: list[list[str]] = []
    cur = grid_start
    for _ in range(6):
        row = [(cur + timedelta(days=i)).isoformat() for i in range(7)]
        weeks.append(row)
        cur += timedelta(days=7)
    return weeks


def month_days(day: str) -> list[str]:
    """Just the real days of `day`'s month (no spill)."""
    d = parse(day)
    n = _days_in_month(d.year, d.month)
    return [date(d.year, d.month, i).isoformat() for i in range(1, n + 1)]


def year_days(day: str) -> list[str]:
    d = parse(day)
    out: list[str] = []
    cur = date(d.year, 1, 1)
    end = date(d.year, 12, 31)
    while cur <= end:
        out.append(cur.isoformat())
        cur += timedelta(days=1)
    return out


def in_month(day: str, ref: str) -> bool:
    a, b = parse(day), parse(ref)
    return a.year == b.year and a.month == b.month


def is_today(day: str) -> bool:
    return day == today()


def weekday_abbr(day: str) -> str:
    return _DOW_ABBR[parse(day).weekday()]


# --------------------------------------------------------------------------- #
# pretty printing (mirrors core.js App.date.pretty styles)
# --------------------------------------------------------------------------- #
def pretty(day: str, style: str = "full") -> str:
    d = parse(day)
    if style == "full":                       # "Mon, Aug 24, 2026"
        return f"{_DOW_ABBR[d.weekday()]}, {_MON_ABBR[d.month - 1]} {d.day}, {d.year}"
    if style == "md":                         # "Aug 24"
        return f"{_MON_ABBR[d.month - 1]} {d.day}"
    if style == "mdy":                        # "Aug 24, 2026"
        return f"{_MON_ABBR[d.month - 1]} {d.day}, {d.year}"
    if style == "dow":                        # "Mon"
        return _DOW_ABBR[d.weekday()]
    if style == "dow_full":                   # "Monday"
        return ["Monday", "Tuesday", "Wednesday", "Thursday",
                "Friday", "Saturday", "Sunday"][d.weekday()]
    if style == "month":                      # "August 2026"
        return f"{_MONTHS[d.month - 1]} {d.year}"
    if style == "month_short":                # "Aug 2026"
        return f"{_MON_ABBR[d.month - 1]} {d.year}"
    if style == "year":                       # "2026"
        return str(d.year)
    if style == "day":                        # "24"
        return str(d.day)
    return day


# --------------------------------------------------------------------------- #
# minutes-of-day <-> strings
# --------------------------------------------------------------------------- #
def to_min(hhmm: str) -> int:
    h, m = hhmm.split(":", 1)
    return int(h) * 60 + int(m)


def to_hhmm(minutes: int) -> str:
    minutes = max(0, min(1439, int(minutes)))
    return f"{minutes // 60:02d}:{minutes % 60:02d}"


def pretty_min(minutes: int, clock_24h: bool = False) -> str:
    """540 -> '9:00 AM' (or '09:00' when clock_24h)."""
    minutes = max(0, min(1439, int(minutes)))
    h, m = divmod(minutes, 60)
    if clock_24h:
        return f"{h:02d}:{m:02d}"
    ampm = "AM" if h < 12 else "PM"
    h12 = h % 12 or 12
    return f"{h12}:{m:02d} {ampm}"


def now_min(now: datetime | None = None) -> int:
    now = now or datetime.now()
    return now.hour * 60 + now.minute


def clock_str(now: datetime | None = None, clock_24h: bool = False,
              seconds: bool = True) -> str:
    now = now or datetime.now()
    if clock_24h:
        fmt = "%H:%M:%S" if seconds else "%H:%M"
        return now.strftime(fmt)
    fmt = "%-I:%M:%S %p" if seconds else "%-I:%M %p"
    try:
        return now.strftime(fmt)
    except ValueError:  # platforms without %-I
        h12 = now.hour % 12 or 12
        base = f"{h12}:{now.minute:02d}"
        if seconds:
            base += f":{now.second:02d}"
        return f"{base} {'AM' if now.hour < 12 else 'PM'}"


__all__ = [
    "today", "parse", "to_str", "is_valid", "add", "add_months", "add_years",
    "start_of_week", "week_days", "month_matrix", "month_days", "year_days",
    "in_month", "is_today", "weekday_abbr", "pretty",
    "to_min", "to_hhmm", "pretty_min", "now_min", "clock_str",
]
