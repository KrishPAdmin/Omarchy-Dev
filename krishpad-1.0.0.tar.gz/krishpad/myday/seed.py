"""seed.py - idempotent starter data for MyDay (ported)."""
from __future__ import annotations

from datetime import datetime, timezone

from . import db as _db

_STARTER_HABITS = [
    {"name": "Water",     "color": "#3aa0c9", "sort_order": 1},
    {"name": "Exercise",  "color": "#2f9e6b", "sort_order": 2},
    {"name": "Read",      "color": "#e08a2f", "sort_order": 3},
    {"name": "Sleep 8h",  "color": "#6d5efc", "sort_order": 4},
]


def _utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def seed() -> None:
    conn = _db.get_conn()
    try:
        if conn.execute("SELECT COUNT(*) AS n FROM habits").fetchone()["n"] > 0:
            return  # already seeded
        ts = _utc_now()
        with _db.immediate_txn(conn):
            for h in _STARTER_HABITS:
                conn.execute(
                    "INSERT INTO habits (name,color,active,sort_order,created_at) VALUES (?,?,1,?,?)",
                    (h["name"], h["color"], h["sort_order"], ts))
    finally:
        conn.close()


__all__ = ["seed"]
