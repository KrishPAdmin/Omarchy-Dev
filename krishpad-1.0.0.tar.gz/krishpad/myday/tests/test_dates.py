"""Tests for myday.dates - pure local wall-clock date/time helpers."""
from __future__ import annotations

from datetime import date, datetime

import pytest

from myday import dates


# --------------------------------------------------------------------------- #
# parse / format / validity
# --------------------------------------------------------------------------- #
def test_today_is_iso_and_valid():
    t = dates.today()
    assert t == date.today().isoformat()
    assert dates.is_valid(t)


def test_parse_and_to_str_roundtrip():
    d = dates.parse("2026-08-24")
    assert d == date(2026, 8, 24)
    assert dates.to_str(d) == "2026-08-24"


@pytest.mark.parametrize("good", ["2026-01-01", "2024-02-29", "2000-12-31"])
def test_is_valid_true(good):
    assert dates.is_valid(good)


@pytest.mark.parametrize("bad", ["2026-13-01", "2026-02-30", "not-a-date",
                                 "", "2023-02-29", None, "2026/08/24"])
def test_is_valid_false(bad):
    assert not dates.is_valid(bad)


# --------------------------------------------------------------------------- #
# arithmetic: add / add_months / add_years
# --------------------------------------------------------------------------- #
def test_add_days_forward_and_back():
    assert dates.add("2026-08-24", 1) == "2026-08-25"
    assert dates.add("2026-08-24", -1) == "2026-08-23"
    assert dates.add("2026-08-24", 0) == "2026-08-24"


def test_add_days_crosses_month_and_year():
    assert dates.add("2026-08-31", 1) == "2026-09-01"
    assert dates.add("2026-12-31", 1) == "2027-01-01"
    assert dates.add("2027-01-01", -1) == "2026-12-31"


def test_add_months_simple():
    assert dates.add_months("2026-01-15", 1) == "2026-02-15"
    assert dates.add_months("2026-01-15", 12) == "2027-01-15"
    assert dates.add_months("2026-03-15", -1) == "2026-02-15"


def test_add_months_month_end_clamp():
    # Jan 31 + 1 month -> Feb 28 in a common year
    assert dates.add_months("2026-01-31", 1) == "2026-02-28"
    # Jan 31 + 1 month -> Feb 29 in a leap year
    assert dates.add_months("2024-01-31", 1) == "2024-02-29"
    # May 31 + 1 -> June 30 (30-day month)
    assert dates.add_months("2026-05-31", 1) == "2026-06-30"


def test_add_months_wraps_year_backwards():
    assert dates.add_months("2026-01-15", -1) == "2025-12-15"
    assert dates.add_months("2026-02-15", -3) == "2025-11-15"


def test_add_years_and_leap_clamp():
    assert dates.add_years("2026-08-24", 1) == "2027-08-24"
    assert dates.add_years("2026-08-24", -2) == "2024-08-24"
    # Feb 29 (leap) + 1 year -> Feb 28 (non-leap) clamp
    assert dates.add_years("2024-02-29", 1) == "2025-02-28"
    # Feb 29 + 4 years -> stays Feb 29 (next leap year)
    assert dates.add_years("2024-02-29", 4) == "2028-02-29"


# --------------------------------------------------------------------------- #
# weeks (MONDAY start)
# --------------------------------------------------------------------------- #
def test_start_of_week_monday():
    # 2026-08-24 is a Monday -> start is itself
    assert dates.parse("2026-08-24").weekday() == 0
    assert dates.start_of_week("2026-08-24") == "2026-08-24"
    # Sunday 2026-08-23 belongs to the week that starts Mon 2026-08-17
    assert dates.parse("2026-08-23").weekday() == 6
    assert dates.start_of_week("2026-08-23") == "2026-08-17"
    # A Wednesday
    assert dates.start_of_week("2026-08-26") == "2026-08-24"


def test_week_days_seven_consecutive_from_monday():
    days = dates.week_days("2026-08-26")
    assert len(days) == 7
    assert days[0] == "2026-08-24"           # Monday
    assert days[-1] == "2026-08-30"          # Sunday
    # strictly consecutive
    for a, b in zip(days, days[1:]):
        assert dates.add(a, 1) == b
    # first day is a Monday, last a Sunday
    assert dates.parse(days[0]).weekday() == 0
    assert dates.parse(days[-1]).weekday() == 6


def test_start_of_week_sunday_start_option():
    # week_start=0 -> Sunday-start still works
    assert dates.start_of_week("2026-08-26", week_start=0) == "2026-08-23"


# --------------------------------------------------------------------------- #
# month grids
# --------------------------------------------------------------------------- #
def test_month_matrix_shape_and_first_cell():
    m = dates.month_matrix("2026-08-15")
    assert len(m) == 6
    assert all(len(row) == 7 for row in m)
    # August 2026: the 1st is a Saturday; Monday-start grid begins Mon Jul 27
    first = dates.parse("2026-08-01")
    assert first.weekday() == 5  # Saturday
    assert m[0][0] == "2026-07-27"
    assert dates.parse(m[0][0]).weekday() == 0  # a Monday
    # flat grid is 42 strictly consecutive days
    flat = [d for row in m for d in row]
    assert len(flat) == 42
    for a, b in zip(flat, flat[1:]):
        assert dates.add(a, 1) == b


def test_month_matrix_includes_spill_days():
    m = dates.month_matrix("2026-08-15")
    flat = [d for row in m for d in row]
    # spill from previous month (late July) and next month present
    assert "2026-07-31" in flat
    assert any(d.startswith("2026-09") for d in flat)
    # every real day of August is covered
    for day in dates.month_days("2026-08-15"):
        assert day in flat


def test_month_matrix_first_when_month_starts_monday():
    # February 2027 starts on a Monday -> first cell is Feb 1 exactly
    assert dates.parse("2027-02-01").weekday() == 0
    m = dates.month_matrix("2027-02-10")
    assert m[0][0] == "2027-02-01"


def test_month_days_and_year_days():
    md = dates.month_days("2026-02-15")
    assert md[0] == "2026-02-01"
    assert md[-1] == "2026-02-28"
    assert len(md) == 28
    # leap February
    assert len(dates.month_days("2024-02-15")) == 29
    yd = dates.year_days("2026-06-01")
    assert len(yd) == 365
    assert yd[0] == "2026-01-01"
    assert yd[-1] == "2026-12-31"
    assert len(dates.year_days("2024-01-01")) == 366


# --------------------------------------------------------------------------- #
# in_month / is_today / weekday_abbr
# --------------------------------------------------------------------------- #
def test_in_month():
    assert dates.in_month("2026-08-01", "2026-08-31")
    assert not dates.in_month("2026-07-31", "2026-08-01")
    assert not dates.in_month("2025-08-15", "2026-08-15")  # same month diff year


def test_is_today():
    assert dates.is_today(dates.today())
    assert not dates.is_today(dates.add(dates.today(), 1))


def test_weekday_abbr():
    assert dates.weekday_abbr("2026-08-24") == "Mon"
    assert dates.weekday_abbr("2026-08-23") == "Sun"
    assert dates.weekday_abbr("2026-08-28") == "Fri"


# --------------------------------------------------------------------------- #
# pretty(day, style)
# --------------------------------------------------------------------------- #
def test_pretty_all_styles():
    d = "2026-08-24"  # Monday
    assert dates.pretty(d, "full") == "Mon, Aug 24, 2026"
    assert dates.pretty(d, "md") == "Aug 24"
    assert dates.pretty(d, "mdy") == "Aug 24, 2026"
    assert dates.pretty(d, "dow") == "Mon"
    assert dates.pretty(d, "dow_full") == "Monday"
    assert dates.pretty(d, "month") == "August 2026"
    assert dates.pretty(d, "month_short") == "Aug 2026"
    assert dates.pretty(d, "year") == "2026"
    assert dates.pretty(d, "day") == "24"
    # default style is "full"
    assert dates.pretty(d) == "Mon, Aug 24, 2026"
    # unknown style falls back to the raw day string
    assert dates.pretty(d, "nonsense") == d


def test_pretty_dow_full_for_each_weekday():
    # Mon..Sun of one week
    expected = ["Monday", "Tuesday", "Wednesday", "Thursday",
                "Friday", "Saturday", "Sunday"]
    for i, name in enumerate(expected):
        day = dates.add("2026-08-24", i)
        assert dates.pretty(day, "dow_full") == name


# --------------------------------------------------------------------------- #
# minutes <-> strings
# --------------------------------------------------------------------------- #
def test_to_min():
    assert dates.to_min("00:00") == 0
    assert dates.to_min("09:00") == 540
    assert dates.to_min("23:59") == 1439
    assert dates.to_min("6:30") == 390


def test_to_hhmm_and_clamp():
    assert dates.to_hhmm(0) == "00:00"
    assert dates.to_hhmm(540) == "09:00"
    assert dates.to_hhmm(1439) == "23:59"
    # clamps out-of-range
    assert dates.to_hhmm(-5) == "00:00"
    assert dates.to_hhmm(5000) == "23:59"


def test_to_min_to_hhmm_roundtrip():
    for hhmm in ("00:00", "07:05", "12:00", "13:45", "23:59"):
        assert dates.to_hhmm(dates.to_min(hhmm)) == hhmm


def test_pretty_min_12h():
    assert dates.pretty_min(0) == "12:00 AM"
    assert dates.pretty_min(540) == "9:00 AM"
    assert dates.pretty_min(720) == "12:00 PM"
    assert dates.pretty_min(780) == "1:00 PM"
    assert dates.pretty_min(1439) == "11:59 PM"


def test_pretty_min_24h():
    assert dates.pretty_min(0, clock_24h=True) == "00:00"
    assert dates.pretty_min(540, clock_24h=True) == "09:00"
    assert dates.pretty_min(720, clock_24h=True) == "12:00"
    assert dates.pretty_min(1439, clock_24h=True) == "23:59"


def test_pretty_min_clamps():
    assert dates.pretty_min(-10) == "12:00 AM"
    assert dates.pretty_min(99999, clock_24h=True) == "23:59"


# --------------------------------------------------------------------------- #
# now_min / clock_str (injectable now)
# --------------------------------------------------------------------------- #
def test_now_min_with_injected_now():
    assert dates.now_min(datetime(2026, 8, 24, 9, 0)) == 540
    assert dates.now_min(datetime(2026, 8, 24, 0, 0)) == 0
    assert dates.now_min(datetime(2026, 8, 24, 23, 59)) == 1439


def test_clock_str_24h():
    now = datetime(2026, 8, 24, 9, 5, 7)
    assert dates.clock_str(now, clock_24h=True, seconds=True) == "09:05:07"
    assert dates.clock_str(now, clock_24h=True, seconds=False) == "09:05"


def test_clock_str_12h():
    now = datetime(2026, 8, 24, 13, 5, 7)
    assert dates.clock_str(now, clock_24h=False, seconds=False) == "1:05 PM"
    assert dates.clock_str(now, clock_24h=False, seconds=True) == "1:05:07 PM"
    midnight = datetime(2026, 8, 24, 0, 0, 0)
    assert dates.clock_str(midnight, clock_24h=False, seconds=False) == "12:00 AM"
