"""Tests for myday.repo - the synchronous data API over SQLite.

Every test runs against a fresh, seeded DB (see conftest.fresh_db). The seed
inserts 4 active starter habits, so habits_total == 4 unless a test changes it.
"""
from __future__ import annotations

import pytest

from myday import repo, dates


DAY = "2026-08-24"      # a Monday
DAY2 = "2026-08-25"
DAY3 = "2026-08-26"


def _habit_ids():
    return [h["id"] for h in repo.list_habits()]


# --------------------------------------------------------------------------- #
# schedule CRUD + time validation
# --------------------------------------------------------------------------- #
def test_create_and_get_schedule():
    b = repo.create_schedule(DAY, 540, 600, "Standup", category="work", note="n")
    assert b["day"] == DAY and b["start_min"] == 540 and b["end_min"] == 600
    assert b["title"] == "Standup" and b["category"] == "work" and b["note"] == "n"
    got = repo.get_block(b["id"])
    assert got == b


def test_get_block_missing_returns_none():
    assert repo.get_block(999999) is None


def test_list_schedule_sorted_by_start():
    repo.create_schedule(DAY, 660, 720, "Later")
    repo.create_schedule(DAY, 540, 600, "Earlier")
    rows = repo.list_schedule(day=DAY)
    assert [r["start_min"] for r in rows] == [540, 660]


def test_list_schedule_range():
    repo.create_schedule(DAY, 540, 600, "A")
    repo.create_schedule(DAY3, 540, 600, "C")
    rows = repo.list_schedule(start=DAY, end=DAY2)
    assert [r["day"] for r in rows] == [DAY]        # DAY3 out of range


def test_schedule_end_before_or_equal_start_rejected():
    with pytest.raises(repo.ValidationError):
        repo.create_schedule(DAY, 600, 540, "backwards")
    with pytest.raises(repo.ValidationError):
        repo.create_schedule(DAY, 600, 600, "zero-length")


def test_schedule_out_of_range_rejected():
    with pytest.raises(repo.ValidationError):
        repo.create_schedule(DAY, -1, 600, "neg start")
    with pytest.raises(repo.ValidationError):
        repo.create_schedule(DAY, 540, 1440, "end too big")
    with pytest.raises(repo.ValidationError):
        repo.create_schedule(DAY, 1500, 1600, "start too big")


def test_schedule_bad_day_rejected():
    with pytest.raises(repo.ValidationError):
        repo.create_schedule("2026-02-30", 540, 600, "bad date")
    with pytest.raises(repo.ValidationError):
        repo.create_schedule("nope", 540, 600, "bad date")


def test_schedule_title_required():
    with pytest.raises(repo.ValidationError):
        repo.create_schedule(DAY, 540, 600, "   ")


def test_schedule_missing_times_rejected():
    with pytest.raises(repo.ValidationError):
        repo.create_schedule(DAY, None, 600, "no start")


def test_schedule_unknown_category_defaults_to_other():
    b = repo.create_schedule(DAY, 540, 600, "x", category="banana")
    assert b["category"] == "other"


def test_update_schedule():
    b = repo.create_schedule(DAY, 540, 600, "x")
    upd = repo.update_schedule(b["id"], title="y", end_min=630, category="focus")
    assert upd["title"] == "y" and upd["end_min"] == 630 and upd["category"] == "focus"
    # unspecified fields preserved
    assert upd["start_min"] == 540


def test_update_schedule_validates_times():
    b = repo.create_schedule(DAY, 540, 600, "x")
    with pytest.raises(repo.ValidationError):
        repo.update_schedule(b["id"], end_min=500)


def test_update_schedule_missing_raises_notfound():
    with pytest.raises(repo.NotFound):
        repo.update_schedule(424242, title="x")


def test_delete_schedule():
    b = repo.create_schedule(DAY, 540, 600, "x")
    repo.delete_schedule(b["id"])
    assert repo.get_block(b["id"]) is None
    with pytest.raises(repo.NotFound):
        repo.delete_schedule(b["id"])


# --------------------------------------------------------------------------- #
# todos CRUD + toggle + reorder
# --------------------------------------------------------------------------- #
def test_create_todo_appends_sort_order():
    a = repo.create_todo(DAY, "a")
    b = repo.create_todo(DAY, "b")
    c = repo.create_todo(DAY, "c")
    assert [a["sort_order"], b["sort_order"], c["sort_order"]] == [0, 1, 2]
    assert a["done"] == 0


def test_create_todo_text_required():
    with pytest.raises(repo.ValidationError):
        repo.create_todo(DAY, "  ")


def test_create_todo_bad_day():
    with pytest.raises(repo.ValidationError):
        repo.create_todo("2026-13-01", "x")


def test_toggle_todo():
    t = repo.create_todo(DAY, "a")
    assert t["done"] == 0
    t2 = repo.toggle_todo(t["id"])
    assert t2["done"] == 1
    t3 = repo.toggle_todo(t["id"])
    assert t3["done"] == 0


def test_toggle_todo_missing():
    with pytest.raises(repo.NotFound):
        repo.toggle_todo(999)


def test_update_todo_and_notfound():
    t = repo.create_todo(DAY, "a")
    upd = repo.update_todo(t["id"], text="b", done=1)
    assert upd["text"] == "b" and upd["done"] == 1
    with pytest.raises(repo.NotFound):
        repo.update_todo(999, text="x")


def test_delete_todo():
    t = repo.create_todo(DAY, "a")
    repo.delete_todo(t["id"])
    assert repo.list_todos(day=DAY) == []
    with pytest.raises(repo.NotFound):
        repo.delete_todo(t["id"])


def test_reorder_todo_swaps_with_neighbour():
    a = repo.create_todo(DAY, "a")
    b = repo.create_todo(DAY, "b")
    c = repo.create_todo(DAY, "c")
    # move b up (toward the front)
    repo.reorder_todo(b["id"], -1)
    order = [t["text"] for t in repo.list_todos(day=DAY)]
    assert order == ["b", "a", "c"]
    # move b (now first) up again -> no-op at the boundary
    repo.reorder_todo(b["id"], -1)
    assert [t["text"] for t in repo.list_todos(day=DAY)] == ["b", "a", "c"]
    # move a down
    repo.reorder_todo(a["id"], 1)
    assert [t["text"] for t in repo.list_todos(day=DAY)] == ["b", "c", "a"]


def test_reorder_todo_missing():
    with pytest.raises(repo.NotFound):
        repo.reorder_todo(999, 1)


def test_reorder_stays_within_day():
    a = repo.create_todo(DAY, "a")
    other = repo.create_todo(DAY2, "other")
    # moving `a` up has no neighbour in its own day -> no-op, other untouched
    repo.reorder_todo(a["id"], -1)
    assert repo.list_todos(day=DAY2)[0]["sort_order"] == other["sort_order"]


# --------------------------------------------------------------------------- #
# meals
# --------------------------------------------------------------------------- #
def test_create_meal_basic_and_coercion():
    m = repo.create_meal(DAY, "lunch", "Salad", calories="450", time_min="720")
    assert m["meal_type"] == "lunch" and m["name"] == "Salad"
    assert m["calories"] == 450 and m["time_min"] == 720   # coerced to int


def test_create_meal_empty_calories_and_time_become_none():
    m = repo.create_meal(DAY, "snack", "Nuts", calories="", time_min="")
    assert m["calories"] is None and m["time_min"] is None
    m2 = repo.create_meal(DAY, "snack", "Chips")
    assert m2["calories"] is None and m2["time_min"] is None


def test_create_meal_bad_type_rejected():
    with pytest.raises(repo.ValidationError):
        repo.create_meal(DAY, "brunch", "x")


def test_create_meal_name_required():
    with pytest.raises(repo.ValidationError):
        repo.create_meal(DAY, "lunch", "   ")


def test_create_meal_bad_calories_and_time():
    with pytest.raises(repo.ValidationError):
        repo.create_meal(DAY, "lunch", "x", calories="abc")
    with pytest.raises(repo.ValidationError):
        repo.create_meal(DAY, "lunch", "x", time_min=2000)   # out of day range


def test_update_and_delete_meal():
    m = repo.create_meal(DAY, "lunch", "Salad", calories=400)
    upd = repo.update_meal(m["id"], name="Big Salad", calories=500)
    assert upd["name"] == "Big Salad" and upd["calories"] == 500
    repo.delete_meal(m["id"])
    with pytest.raises(repo.NotFound):
        repo.delete_meal(m["id"])
    with pytest.raises(repo.NotFound):
        repo.update_meal(m["id"], name="x")


# --------------------------------------------------------------------------- #
# workouts
# --------------------------------------------------------------------------- #
def test_create_workout_basic():
    w = repo.create_workout(DAY, "Run", duration_min="30", intensity="high")
    assert w["activity"] == "Run" and w["duration_min"] == 30 and w["intensity"] == "high"


def test_workout_empty_intensity_becomes_none():
    w = repo.create_workout(DAY, "Walk", intensity="")
    assert w["intensity"] is None
    w2 = repo.create_workout(DAY, "Walk2")
    assert w2["intensity"] is None


def test_workout_bad_intensity_rejected():
    with pytest.raises(repo.ValidationError):
        repo.create_workout(DAY, "Run", intensity="extreme")


def test_workout_activity_required():
    with pytest.raises(repo.ValidationError):
        repo.create_workout(DAY, "   ")


def test_update_and_delete_workout():
    w = repo.create_workout(DAY, "Run", duration_min=30)
    upd = repo.update_workout(w["id"], duration_min=45, intensity="med")
    assert upd["duration_min"] == 45 and upd["intensity"] == "med"
    with pytest.raises(repo.ValidationError):
        repo.update_workout(w["id"], intensity="nope")
    repo.delete_workout(w["id"])
    with pytest.raises(repo.NotFound):
        repo.update_workout(w["id"], activity="x")


# --------------------------------------------------------------------------- #
# metrics - partial upsert
# --------------------------------------------------------------------------- #
def test_metrics_default_object():
    m = repo.get_metrics(DAY)
    assert m == {"day": DAY, "water_cups": 0, "sleep_hours": None,
                 "weight": None, "mood": None, "updated_at": None}


def test_metrics_partial_upsert_keeps_other_fields():
    repo.set_metrics(DAY, sleep_hours=7.5, mood=4)
    # writing only water must not wipe sleep or mood
    repo.set_metrics(DAY, water_cups=3)
    m = repo.get_metrics(DAY)
    assert m["water_cups"] == 3
    assert m["sleep_hours"] == 7.5
    assert m["mood"] == 4


def test_metrics_weight_and_coercion():
    repo.set_metrics(DAY, weight="180.5", mood="3", water_cups="2")
    m = repo.get_metrics(DAY)
    assert m["weight"] == 180.5 and m["mood"] == 3 and m["water_cups"] == 2


def test_metrics_mood_bounds():
    with pytest.raises(repo.ValidationError):
        repo.set_metrics(DAY, mood=6)
    with pytest.raises(repo.ValidationError):
        repo.set_metrics(DAY, mood=0)
    assert repo.set_metrics(DAY, mood=1)["mood"] == 1
    assert repo.set_metrics(DAY, mood=5)["mood"] == 5


def test_add_water_increments_and_floors_at_zero():
    assert repo.add_water(DAY, 1)["water_cups"] == 1
    assert repo.add_water(DAY, 1)["water_cups"] == 2
    assert repo.add_water(DAY, -1)["water_cups"] == 1
    assert repo.add_water(DAY, -5)["water_cups"] == 0   # never negative


def test_list_metrics_range():
    repo.set_metrics(DAY, water_cups=1)
    repo.set_metrics(DAY3, water_cups=2)
    rows = repo.list_metrics(DAY, DAY2)
    assert [r["day"] for r in rows] == [DAY]


# --------------------------------------------------------------------------- #
# habits + habit logs + streak
# --------------------------------------------------------------------------- #
def test_seed_creates_four_active_habits():
    habits = repo.list_habits()
    assert len(habits) == 4
    assert [h["name"] for h in habits] == ["Water", "Exercise", "Read", "Sleep 8h"]


def test_create_update_habit():
    h = repo.create_habit("Meditate", color="#abcdef")
    assert h["name"] == "Meditate" and h["active"] == 1
    upd = repo.update_habit(h["id"], name="Meditate 10m")
    assert upd["name"] == "Meditate 10m"


def test_create_habit_name_required():
    with pytest.raises(repo.ValidationError):
        repo.create_habit("  ")


def test_update_habit_missing():
    with pytest.raises(repo.NotFound):
        repo.update_habit(999, name="x")


def test_include_inactive_filter():
    h = repo.create_habit("Temp")
    repo.update_habit(h["id"], active=0)
    assert h["id"] not in _habit_ids()                       # hidden by default
    all_ids = [x["id"] for x in repo.list_habits(include_inactive=True)]
    assert h["id"] in all_ids


def test_delete_habit_cascades_logs():
    h = repo.create_habit("Temp")
    repo.set_habit_log(h["id"], DAY, 1)
    repo.set_habit_log(h["id"], DAY2, 1)
    assert len(repo.list_habit_logs(start=DAY, end=DAY3)) == 2
    repo.delete_habit(h["id"])
    # habit gone AND its logs cascaded away
    assert h["id"] not in [x["id"] for x in repo.list_habits(include_inactive=True)]
    assert repo.list_habit_logs(start=DAY, end=DAY3) == []
    with pytest.raises(repo.NotFound):
        repo.delete_habit(h["id"])


def test_set_habit_log_missing_habit():
    with pytest.raises(repo.NotFound):
        repo.set_habit_log(999, DAY, 1)


def test_set_habit_log_upsert():
    hid = _habit_ids()[0]
    repo.set_habit_log(hid, DAY, 1)
    repo.set_habit_log(hid, DAY, 0)                          # upsert same key
    logs = repo.list_habit_logs(day=DAY)
    mine = [l for l in logs if l["habit_id"] == hid]
    assert len(mine) == 1 and mine[0]["done"] == 0


def test_toggle_habit():
    hid = _habit_ids()[0]
    assert repo.toggle_habit(hid, DAY)["done"] == 1
    assert repo.toggle_habit(hid, DAY)["done"] == 0


def test_habit_streak_consecutive_and_gap():
    hid = _habit_ids()[0]
    end = "2026-08-20"
    # mark 4 consecutive done days ending at `end`
    for d in ("2026-08-17", "2026-08-18", "2026-08-19", "2026-08-20"):
        repo.set_habit_log(hid, d, 1)
    assert repo.habit_streak(hid, end) == 4
    # a not-done day breaks the count from that side
    assert repo.habit_streak(hid, "2026-08-19") == 3
    # streak asked on a day with no log -> 0
    assert repo.habit_streak(hid, "2026-08-21") == 0


def test_habit_streak_gap_breaks():
    hid = _habit_ids()[0]
    # done on 17,18, skip 19, done 20,21 -> streak ending 21 is only 2
    for d in ("2026-08-17", "2026-08-18", "2026-08-20", "2026-08-21"):
        repo.set_habit_log(hid, d, 1)
    assert repo.habit_streak(hid, "2026-08-21") == 2
    assert repo.habit_streak(hid, "2026-08-18") == 2


def test_habit_streak_ignores_not_done_rows():
    hid = _habit_ids()[0]
    repo.set_habit_log(hid, "2026-08-20", 1)
    repo.set_habit_log(hid, "2026-08-19", 0)      # explicitly not done
    repo.set_habit_log(hid, "2026-08-18", 1)
    assert repo.habit_streak(hid, "2026-08-20") == 1


# --------------------------------------------------------------------------- #
# journal
# --------------------------------------------------------------------------- #
def test_journal_default_and_upsert():
    assert repo.get_journal(DAY) == {"day": DAY, "content": "", "updated_at": None}
    repo.set_journal(DAY, "first")
    assert repo.get_journal(DAY)["content"] == "first"
    repo.set_journal(DAY, "second")               # upsert overwrites
    j = repo.get_journal(DAY)
    assert j["content"] == "second" and j["updated_at"] is not None


def test_journal_bad_day():
    with pytest.raises(repo.ValidationError):
        repo.get_journal("bad")


# --------------------------------------------------------------------------- #
# summary aggregation across several seeded days
# --------------------------------------------------------------------------- #
def test_summary_aggregation():
    hid = _habit_ids()[0]
    # ---- DAY: rich day ----
    repo.create_schedule(DAY, 540, 600, "A")        # 60 min
    repo.create_schedule(DAY, 660, 720, "B")        # 60 min -> 120 total, 2 blocks
    t1 = repo.create_todo(DAY, "t1")
    repo.create_todo(DAY, "t2")
    repo.toggle_todo(t1["id"])                       # 1 of 2 done
    repo.create_meal(DAY, "lunch", "Salad", calories=400)
    repo.create_meal(DAY, "snack", "Nuts", calories=100)   # 2 meals, 500 cal
    repo.create_workout(DAY, "Run", duration_min=30)
    repo.set_metrics(DAY, water_cups=3, sleep_hours=8.0, weight=180.0, mood=4)
    repo.set_habit_log(hid, DAY, 1)                  # habits_done = 1
    repo.set_journal(DAY, "dear diary")

    # ---- DAY2: a single open todo ----
    repo.create_todo(DAY2, "lonely")

    # ---- DAY3: empty journal should NOT count; add a meal so day appears ----
    repo.set_journal(DAY3, "")
    repo.create_meal(DAY3, "breakfast", "Eggs", calories=200)

    rows = repo.summary(DAY, DAY3)
    by_day = {r["day"]: r for r in rows}
    assert set(by_day) == {DAY, DAY2, DAY3}

    d1 = by_day[DAY]
    assert d1["blocks"] == 2 and d1["scheduled_min"] == 120
    assert d1["todos_total"] == 2 and d1["todos_done"] == 1
    assert d1["meals"] == 2 and d1["calories"] == 500
    assert d1["workouts"] == 1 and d1["workout_min"] == 30
    assert d1["water_cups"] == 3 and d1["sleep_hours"] == 8.0
    assert d1["weight"] == 180.0 and d1["mood"] == 4
    assert d1["habits_total"] == 4 and d1["habits_done"] == 1
    assert d1["journal"] is True

    d2 = by_day[DAY2]
    assert d2["todos_total"] == 1 and d2["todos_done"] == 0
    assert d2["blocks"] == 0 and d2["journal"] is False

    d3 = by_day[DAY3]
    assert d3["meals"] == 1 and d3["calories"] == 200
    assert d3["journal"] is False                    # empty content excluded
    assert d3["habits_total"] == 4 and d3["habits_done"] == 0


def test_summary_empty_range_is_empty():
    assert repo.summary(DAY, DAY3) == []


def test_summary_bad_dates():
    with pytest.raises(repo.ValidationError):
        repo.summary("bad", DAY)
    with pytest.raises(repo.ValidationError):
        repo.summary(DAY, "bad")


# --------------------------------------------------------------------------- #
# dashboard helpers
# --------------------------------------------------------------------------- #
def test_current_and_next_block():
    b1 = repo.create_schedule(DAY, 540, 600, "A")    # 09:00-10:00
    b2 = repo.create_schedule(DAY, 660, 720, "B")    # 11:00-12:00
    # inside b1
    cur, nxt = repo.current_and_next_block(DAY, 570)
    assert cur["id"] == b1["id"] and nxt["id"] == b2["id"]
    # in the gap between blocks
    cur, nxt = repo.current_and_next_block(DAY, 630)
    assert cur is None and nxt["id"] == b2["id"]
    # after everything
    cur, nxt = repo.current_and_next_block(DAY, 800)
    assert cur is None and nxt is None
    # before everything
    cur, nxt = repo.current_and_next_block(DAY, 0)
    assert cur is None and nxt["id"] == b1["id"]


def test_current_and_next_block_empty_day():
    assert repo.current_and_next_block(DAY, 600) == (None, None)


def test_upcoming_merges_blocks_and_open_todos_sorted():
    repo.create_schedule(DAY, 540, 600, "Block")
    open_t = repo.create_todo(DAY2, "open")
    done_t = repo.create_todo(DAY, "done")
    repo.toggle_todo(done_t["id"])                   # done -> excluded
    items = repo.upcoming(DAY, days=14)
    kinds = [(it["kind"], it["day"]) for it in items]
    # block on DAY sorts before the open todo on DAY2; done todo absent
    assert kinds == [("block", DAY), ("todo", DAY2)]
    assert all(not (it["kind"] == "todo" and it.get("done")) for it in items)


def test_upcoming_respects_window():
    # todo far in the future is outside a 2-day window
    repo.create_todo(dates.add(DAY, 30), "far")
    repo.create_todo(DAY, "near")
    items = repo.upcoming(DAY, days=2)
    assert [it["day"] for it in items] == [DAY]


def test_upcoming_bad_day():
    with pytest.raises(repo.ValidationError):
        repo.upcoming("bad")


def test_day_counts():
    t1 = repo.create_todo(DAY, "a")
    repo.create_todo(DAY, "b")
    repo.toggle_todo(t1["id"])
    repo.create_schedule(DAY, 540, 600, "A")
    hid = _habit_ids()[0]
    repo.set_habit_log(hid, DAY, 1)
    dc = repo.day_counts(DAY)
    assert dc["todos_total"] == 2
    assert dc["todos_done"] == 1
    assert dc["todos_open"] == 1
    assert dc["blocks"] == 1
    assert dc["habits_total"] == 4
    assert dc["habits_done"] == 1


def test_day_counts_empty_day():
    dc = repo.day_counts(DAY)
    assert dc["todos_total"] == 0 and dc["blocks"] == 0
    assert dc["habits_total"] == 4 and dc["habits_done"] == 0
