"""Tests for myday.config - Settings, night window, env overrides, hh:mm."""
from __future__ import annotations

from datetime import datetime

import pytest

from myday import config
from myday.config import Settings, in_night_window


_ENV_KEYS = [
    "MYDAY_IDLE_SECONDS", "MYDAY_ROTATE_SECONDS", "MYDAY_NIGHT_START",
    "MYDAY_NIGHT_END", "MYDAY_NIGHT_DARK", "MYDAY_WEEK_START",
    "MYDAY_CLOCK_24H", "MYDAY_THEME",
]


@pytest.fixture
def clean_env(tmp_path, monkeypatch):
    """Isolate settings loading: no host config.toml, no stray MYDAY_* vars."""
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / "cfg"))
    for k in _ENV_KEYS:
        monkeypatch.delenv(k, raising=False)
    return monkeypatch


# --------------------------------------------------------------------------- #
# defaults
# --------------------------------------------------------------------------- #
def test_default_settings_values():
    s = Settings()
    assert s.week_start == 1                 # Monday
    assert s.idle_seconds == 300
    assert s.rotate_seconds == 60
    assert s.night_start_min == 22 * 60      # 1320 == 22:00
    assert s.night_end_min == 6 * 60         # 360 == 06:00
    assert s.night_dark is True
    assert s.effects == ()
    assert s.theme == "krishadmin"
    assert s.clock_24h is False
    assert s.as_dict()["night_start_min"] == 1320


def test_load_settings_defaults_when_clean(clean_env):
    s = config.load_settings()
    assert s == Settings()
    assert s.effects == ()


# --------------------------------------------------------------------------- #
# in_night_window - the 22:00 -> 06:00 wrap
# --------------------------------------------------------------------------- #
def test_night_window_wrap_true_late_evening():
    s = Settings()  # 22:00..06:00
    assert in_night_window(datetime(2026, 8, 24, 23, 0), s) is True


def test_night_window_wrap_true_early_morning():
    s = Settings()
    assert in_night_window(datetime(2026, 8, 24, 2, 0), s) is True


def test_night_window_wrap_false_at_noon():
    s = Settings()
    assert in_night_window(datetime(2026, 8, 24, 12, 0), s) is False


def test_night_window_boundaries():
    s = Settings()  # start=1320 inclusive, end=360 exclusive
    assert in_night_window(datetime(2026, 8, 24, 22, 0), s) is True   # == start
    assert in_night_window(datetime(2026, 8, 24, 21, 59), s) is False
    assert in_night_window(datetime(2026, 8, 24, 5, 59), s) is True
    assert in_night_window(datetime(2026, 8, 24, 6, 0), s) is False   # == end excl.


def test_night_window_same_day_window():
    # start < end: a plain same-day window 01:00..05:00
    s = config.replace(Settings(), night_start_min=60, night_end_min=300)
    assert in_night_window(datetime(2026, 8, 24, 2, 0), s) is True
    assert in_night_window(datetime(2026, 8, 24, 1, 0), s) is True    # == start
    assert in_night_window(datetime(2026, 8, 24, 5, 0), s) is False   # == end excl.
    assert in_night_window(datetime(2026, 8, 24, 23, 0), s) is False


def test_night_window_disabled_when_night_dark_false():
    s = config.replace(Settings(), night_dark=False)
    # 23:00 would be in-window if enabled, but night_dark disables it
    assert in_night_window(datetime(2026, 8, 24, 23, 0), s) is False


def test_night_window_start_equals_end_never():
    s = config.replace(Settings(), night_start_min=360, night_end_min=360)
    assert in_night_window(datetime(2026, 8, 24, 6, 0), s) is False
    assert in_night_window(datetime(2026, 8, 24, 23, 0), s) is False


# --------------------------------------------------------------------------- #
# env overrides via monkeypatch
# --------------------------------------------------------------------------- #
def test_env_override_idle_and_rotate(clean_env):
    clean_env.setenv("MYDAY_IDLE_SECONDS", "42")
    clean_env.setenv("MYDAY_ROTATE_SECONDS", "7")
    s = config.load_settings()
    assert s.idle_seconds == 42
    assert s.rotate_seconds == 7


def test_env_override_night_window_hhmm(clean_env):
    clean_env.setenv("MYDAY_NIGHT_START", "23:30")
    clean_env.setenv("MYDAY_NIGHT_END", "05:15")
    s = config.load_settings()
    assert s.night_start_min == 23 * 60 + 30   # 1410
    assert s.night_end_min == 5 * 60 + 15      # 315


def test_env_override_night_start_as_int_minutes(clean_env):
    clean_env.setenv("MYDAY_NIGHT_START", "1200")
    s = config.load_settings()
    assert s.night_start_min == 1200


def test_env_override_booleans(clean_env):
    clean_env.setenv("MYDAY_NIGHT_DARK", "off")
    clean_env.setenv("MYDAY_CLOCK_24H", "yes")
    s = config.load_settings()
    assert s.night_dark is False
    assert s.clock_24h is True


def test_env_override_week_start_and_theme(clean_env):
    clean_env.setenv("MYDAY_WEEK_START", "0")
    clean_env.setenv("MYDAY_THEME", "midnight")
    s = config.load_settings()
    assert s.week_start == 0
    assert s.theme == "midnight"


def test_empty_env_value_is_ignored(clean_env):
    clean_env.setenv("MYDAY_IDLE_SECONDS", "")   # blank -> keep default
    s = config.load_settings()
    assert s.idle_seconds == 300


def test_bad_env_value_is_ignored(clean_env):
    clean_env.setenv("MYDAY_IDLE_SECONDS", "not-a-number")
    s = config.load_settings()
    assert s.idle_seconds == 300                 # conversion failed -> default


def test_env_override_affects_in_night_window(clean_env):
    # a same-day daytime window loaded purely from env
    clean_env.setenv("MYDAY_NIGHT_START", "10:00")
    clean_env.setenv("MYDAY_NIGHT_END", "14:00")
    s = config.load_settings()
    assert in_night_window(datetime(2026, 8, 24, 12, 0), s) is True
    assert in_night_window(datetime(2026, 8, 24, 9, 0), s) is False


# --------------------------------------------------------------------------- #
# hh:mm parsing helper
# --------------------------------------------------------------------------- #
def test_hhmm_to_min_parsing():
    assert config._hhmm_to_min("22:00") == 1320
    assert config._hhmm_to_min("06:00") == 360
    assert config._hhmm_to_min("00:00") == 0
    assert config._hhmm_to_min("23:59") == 1439
    # plain integer string -> passthrough minutes
    assert config._hhmm_to_min("1320") == 1320
    assert config._hhmm_to_min(1320) == 1320
    # wrap/clamp via modulo on hours & minutes
    assert config._hhmm_to_min("24:00") == 0          # 24 % 24 -> 0
    assert config._hhmm_to_min("1:5") == 65


# --------------------------------------------------------------------------- #
# paths honour MYDAY_DB (used by the whole suite's isolation)
# --------------------------------------------------------------------------- #
def test_db_path_honours_env(monkeypatch, tmp_path):
    target = tmp_path / "nested" / "planner.db"
    monkeypatch.setenv("MYDAY_DB", str(target))
    assert config.db_path() == str(target)
    # parent dir is created on demand
    assert target.parent.is_dir()
