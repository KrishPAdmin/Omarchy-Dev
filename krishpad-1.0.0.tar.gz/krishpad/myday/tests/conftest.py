"""Shared fixtures for the MyDay frozen-foundation test suite.

Each test gets a *fresh* SQLite database in a unique temp file. We set
``MYDAY_DB`` in the environment BEFORE the repo touches the DB, call
``repo.init()`` to build the schema + seed starter habits, and tear the
files (db + WAL + SHM) down afterwards so no state leaks between tests.

``config.db_path()`` reads ``MYDAY_DB`` fresh on every ``get_conn()`` call,
so pointing the env var per-test is enough to fully isolate each test even
though the modules themselves are imported once.
"""
from __future__ import annotations

import os

import pytest

from myday import repo


@pytest.fixture(autouse=True)
def fresh_db(tmp_path, monkeypatch):
    """Point MYDAY_DB at a unique fresh file per test and init the schema."""
    db_file = tmp_path / "planner.db"
    monkeypatch.setenv("MYDAY_DB", str(db_file))
    # Make sure no config.toml on the host box bleeds into settings-sensitive
    # code paths; tests that need overrides set MYDAY_* explicitly.
    repo.init()
    yield db_file
    # Best-effort cleanup of the sqlite trio (monkeypatch restores the env var).
    for suffix in ("", "-wal", "-shm"):
        p = str(db_file) + suffix
        try:
            os.remove(p)
        except OSError:
            pass
