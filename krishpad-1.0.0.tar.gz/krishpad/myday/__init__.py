"""MyDay - a terminal-native daily planner (neon-green-on-black, Omarchy-ready).

A Textual TUI port of the MyDay web planner. Local SQLite, no server, no login.

Public surface used across the app:
    myday.config   - paths + user settings + the nightly-dark window helper
    myday.db       - sqlite connection + schema
    myday.repo     - the data-access API (CRUD + summary + dashboard helpers)
    myday.dates    - local wall-clock date/time helpers (WEEK STARTS MONDAY)
    myday.palette  - the single colour source (matches krishadmin.com)
    myday.app      - the Textual App (MyDayApp) + screen registry
"""

__version__ = "1.0.0"
