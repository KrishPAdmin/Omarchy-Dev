"""todolist.py - reusable interactive to-do list for a single day.

Shared widget used by the Today dashboard and the Day view. Reads/writes via
myday.repo. Parent calls `reload(day)` whenever the active date changes.

Keys (when focused):
    enter / space  toggle done on the highlighted todo
    a              focus the add box (or just start typing there)
    e              edit highlighted todo text
    d / delete     delete highlighted todo (with confirm)
    J / K          move highlighted todo down / up
    up / down      move highlight (ListView default)
The add box: type text + Enter to append a todo.
"""
from __future__ import annotations

from textual.app import ComposeResult
from textual.containers import Vertical
from textual.message import Message
from textual.widgets import Input, ListItem, ListView, Static

from .. import repo
from ..ui import ConfirmModal, Field, FormModal


class TodoRow(ListItem):
    def __init__(self, todo: dict):
        super().__init__()
        self.todo = todo

    def compose(self) -> ComposeResult:
        done = bool(self.todo["done"])
        box = "[green]✓[/]" if done else "○"
        text = self.todo["text"]
        cls = "done" if done else ""
        yield Static(f"{box} {text}", classes=cls, markup=True)


class TodoList(Vertical):
    DEFAULT_CSS = """
    TodoList { height: auto; }
    TodoList ListView { height: auto; max-height: 16; background: #0c0e10; }
    TodoList #todo-add { margin: 1 0 0 0; }
    TodoList .todo-empty { color: #959595; padding: 1 1; }
    TodoList .todo-count { color: #959595; padding: 0 1; }
    """

    BINDINGS = [
        ("a", "add_focus", "Add"),
        ("e", "edit", "Edit"),
        ("d,delete", "delete", "Delete"),
        ("space,enter", "toggle", "Toggle"),
        ("J", "move(1)", "Down"),
        ("K", "move(-1)", "Up"),
    ]

    def __init__(self, day: str | None = None, show_add: bool = True,
                 max_visible: int | None = None, **kwargs):
        super().__init__(**kwargs)
        self._day = day
        self._show_add = show_add
        self._max_visible = max_visible

    @property
    def day(self) -> str:
        return self._day or self.app.day  # type: ignore[attr-defined]

    def compose(self) -> ComposeResult:
        yield Static("", classes="todo-count", id="todo-count")
        yield ListView(id="todo-list")
        if self._show_add:
            yield Input(placeholder="+ add a task and press Enter", id="todo-add")

    def on_mount(self) -> None:
        self.reload(self.day)

    # --- data ------------------------------------------------------------- #
    def reload(self, day: str | None = None) -> None:
        if day:
            self._day = day
        lv = self.query_one("#todo-list", ListView)
        idx = lv.index
        lv.clear()
        todos = repo.list_todos(day=self.day)
        for t in todos:
            lv.append(TodoRow(t))
        if not todos:
            lv.append(ListItem(Static("nothing yet - add your first task", classes="todo-empty")))
        done = sum(1 for t in todos if t["done"])
        self.query_one("#todo-count", Static).update(
            f"{done}/{len(todos)} done" if todos else "")
        if todos and idx is not None:
            lv.index = min(idx, len(todos) - 1)

    def _current(self) -> dict | None:
        lv = self.query_one("#todo-list", ListView)
        item = lv.highlighted_child
        return getattr(item, "todo", None) if item else None

    # --- add box ---------------------------------------------------------- #
    def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id != "todo-add":
            return
        text = event.value.strip()
        if text:
            try:
                repo.create_todo(self.day, text)
            except repo.ValidationError as e:
                self.app.notify(str(e), severity="error"); return
            event.input.value = ""
            self.reload()
            self._notify_change()

    def action_add_focus(self) -> None:
        try:
            self.query_one("#todo-add", Input).focus()
        except Exception:
            pass

    # --- toggle / edit / delete / move ------------------------------------ #
    def action_toggle(self) -> None:
        t = self._current()
        if not t:
            return
        repo.toggle_todo(t["id"])
        self.reload()
        self._notify_change()

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        t = getattr(event.item, "todo", None)
        if t:
            repo.toggle_todo(t["id"])
            self.reload()
            self._notify_change()

    def action_edit(self) -> None:
        t = self._current()
        if not t:
            return

        def _submit(values):
            txt = values.get("text", "").strip()
            if not txt:
                return "text is required"
            repo.update_todo(t["id"], text=txt)
            self.reload()
            self._notify_change()
            return None

        self.app.push_screen(FormModal(
            "Edit task", [Field("text", "Task", "text", required=True)],
            values={"text": t["text"]}, on_submit=_submit))

    def action_delete(self) -> None:
        t = self._current()
        if not t:
            return

        def _confirm(ok):
            if ok:
                repo.delete_todo(t["id"])
                self.reload()
                self._notify_change()

        self.app.push_screen(ConfirmModal(f"Delete task '{t['text']}'?"), _confirm)

    def action_move(self, direction: int) -> None:
        t = self._current()
        if not t:
            return
        repo.reorder_todo(t["id"], direction)
        self.reload()

    class Changed(Message):
        """Posted after any add/toggle/edit/delete so hosts can refresh rollups."""

    def _notify_change(self) -> None:
        try:
            self.post_message(self.Changed())
        except Exception:
            pass
