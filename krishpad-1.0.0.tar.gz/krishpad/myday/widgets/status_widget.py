"""status_widget.py - the compact always-on MyDay status widget.

`myday widget` launches this: a tiny Textual app meant to live in a Hyprland
scratchpad or a small floating terminal. It is a mini krishadmin dashboard -
neon green on black - showing, at a glance:

    * a live block-digit clock + today's date  (reuses widgets.clock.BigClock)
    * the CURRENT schedule block, big
    * the NEXT block
    * a count of open todos + the next few upcoming items

The clock ticks every second (BigClock owns that). The data (current/next block,
todos, upcoming) is refreshed every ~15s, and also on `r`. Keys: `q`/`esc` quit,
`r` refresh now.
"""
from __future__ import annotations

import os

from textual.app import App, ComposeResult
from textual.containers import Vertical
from textual.widgets import Static

from .. import config, dates, palette, repo
from .clock import BigClock

_HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

_REFRESH_SECONDS = 15.0


def _esc(text) -> str:
    """Escape Rich markup brackets in dynamic text."""
    return str(text).replace("[", r"\[")


def _hhmm(minutes) -> str:
    try:
        return dates.to_hhmm(int(minutes))
    except Exception:
        return "--:--"


class StatusWidget(App):
    """A small, glanceable status dashboard."""

    CSS_PATH = os.path.join(_HERE, "theme.tcss")
    TITLE = "MyDay · now"

    BINDINGS = [
        ("q", "quit", "Quit"),
        ("escape", "quit", "Quit"),
        ("r", "refresh", "Refresh"),
    ]

    DEFAULT_CSS = """
    StatusWidget { background: #000000; }

    #widget-root {
        width: 100%;
        height: 100%;
        padding: 0 1;
    }

    BigClock { height: auto; padding: 0 0 1 0; }

    #cur {
        height: auto;
        padding: 1 1;
        margin: 0 0 1 0;
        background: #0c0e10;
        border: round #2a2f33;
        color: #eeeeee;
    }
    #cur.busy { border: round #20fd14; }

    #nxt {
        height: auto;
        padding: 0 1;
        margin: 0 0 1 0;
        color: #bebebe;
    }

    #todos {
        height: auto;
        padding: 0 1;
        color: #eeeeee;
    }
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        # BigClock reads self.app.settings.clock_24h; give it a real Settings.
        try:
            self.settings = config.load_settings()
        except Exception:
            self.settings = config.Settings()
        self.day = dates.today()
        self._timer = None

    # --- lifecycle -------------------------------------------------------- #
    def compose(self) -> ComposeResult:
        with Vertical(id="widget-root"):
            yield BigClock(day=self.day)
            yield Static("", id="cur")
            yield Static("", id="nxt")
            yield Static("", id="todos")

    def on_mount(self) -> None:
        try:
            repo.init()
        except Exception:
            pass
        self._refresh_data()
        self._timer = self.set_interval(_REFRESH_SECONDS, self._refresh_data)

    # --- actions ---------------------------------------------------------- #
    def action_refresh(self) -> None:
        self._refresh_data()

    # --- data ------------------------------------------------------------- #
    def _refresh_data(self) -> None:
        """Recompute current/next block + todos. Never lets an error escape."""
        try:
            today = dates.today()
            self.day = today
            now = dates.now_min()

            # keep the clock's date line in step across a midnight rollover
            try:
                self.query_one(BigClock).reload(today)
            except Exception:
                pass

            cur, nxt = repo.current_and_next_block(today, now)
            counts = repo.day_counts(today)

            self._render_current(cur, now)
            self._render_next(nxt)
            self._render_todos(today, counts)
        except Exception as e:
            try:
                self.query_one("#cur", Static).update(
                    f"[{palette.MAROON_HI}]status unavailable[/]\n[{palette.TEXT_SUB}]{_esc(e)}[/]")
            except Exception:
                pass

    def _render_current(self, cur, now: int) -> None:
        w = self.query_one("#cur", Static)
        if cur:
            color = cur.get("color") or palette.category_color(cur.get("category"))
            title = _esc(cur.get("title", ""))
            span = f"{_hhmm(cur['start_min'])} - {_hhmm(cur['end_min'])}"
            remain = max(0, int(cur.get("end_min", now)) - now)
            body = [
                f"[{palette.TEXT_SUB}]NOW[/]",
                f"[b {color}]{title}[/]",
                f"[{palette.TEXT_SOFT}]{span}  ·  {remain} min left[/]",
            ]
            note = (cur.get("note") or "").strip()
            if note:
                body.append(f"[{palette.TEXT_SUB}]{_esc(note)}[/]")
            w.update("\n".join(body))
            w.add_class("busy")
        else:
            w.update(
                f"[{palette.TEXT_SUB}]NOW[/]\n[b {palette.ACCENT}]◈ free[/]"
                f"\n[{palette.TEXT_SUB}]no block right now[/]")
            w.remove_class("busy")

    def _render_next(self, nxt) -> None:
        w = self.query_one("#nxt", Static)
        if nxt:
            color = nxt.get("color") or palette.category_color(nxt.get("category"))
            title = _esc(nxt.get("title", ""))
            w.update(
                f"[{palette.TEXT_SUB}]NEXT[/]  "
                f"[b {color}]▶ {_hhmm(nxt['start_min'])}[/] "
                f"[{palette.TEXT}]{title}[/]")
        else:
            w.update(f"[{palette.TEXT_SUB}]NEXT[/]  [{palette.TEXT_SUB}]nothing scheduled[/]")

    def _render_todos(self, today: str, counts: dict) -> None:
        w = self.query_one("#todos", Static)
        open_n = int(counts.get("todos_open", 0))
        done_n = int(counts.get("todos_done", 0))
        total = int(counts.get("todos_total", 0))

        header = (f"[{palette.TEXT_SUB}]TODOS[/]  "
                  f"[b {palette.ACCENT}]{open_n} open[/] "
                  f"[{palette.TEXT_SUB}]/ {total} · {done_n} done[/]")
        lines = [header]

        try:
            items = self._upcoming_items(today)
        except Exception:
            items = []

        if items:
            for label in items[:3]:
                lines.append(f"[{palette.TEXT}]{label}[/]")
        elif open_n == 0:
            lines.append(f"[{palette.ACCENT}]✓ all clear[/]")

        w.update("\n".join(lines))

    def _upcoming_items(self, today: str) -> list[str]:
        """Next few open todos (today first), then upcoming blocks/todos."""
        out: list[str] = []
        seen: set = set()

        # today's open todos first
        for t in repo.list_todos(day=today):
            if not t.get("done"):
                key = ("todo", t.get("id"))
                if key not in seen:
                    seen.add(key)
                    out.append(f"[ ] {_esc(t.get('text', ''))}")

        # then the merged upcoming feed (future blocks + open todos)
        try:
            feed = repo.upcoming(today, 2)
        except Exception:
            feed = []
        for it in feed:
            if it.get("kind") == "block":
                key = ("block", it.get("id"))
                if key in seen:
                    continue
                seen.add(key)
                when = _hhmm(it.get("start_min", 0))
                daylbl = "" if it.get("day") == today else f"{dates.pretty(it['day'], 'md')} "
                out.append(f"▶ {daylbl}{when} {_esc(it.get('title', ''))}")
            else:  # todo
                key = ("todo", it.get("id"))
                if key in seen:
                    continue
                seen.add(key)
                daylbl = "" if it.get("day") == today else f"{dates.pretty(it['day'], 'md')} "
                out.append(f"[ ] {daylbl}{_esc(it.get('text', ''))}")

        return out


def run_widget() -> None:
    """Launch the compact status widget (blocking)."""
    StatusWidget().run()


__all__ = ["StatusWidget", "run_widget"]
