"""clock.py - BigClock: a large, glanceable block-digit clock for the Today view.

Renders the current wall-clock time in oversized ASCII/block glyphs in neon
green (palette.ACCENT), refreshed every second via set_interval. Below the time
it shows the selected day's full date line and a subtle live "now" line.

The block font is a small self-contained dict (0-9, ":", "AM", "PM"); if the
widget is too narrow to fit the big glyphs it degrades gracefully to a plain
one-line clock. Honors app.settings.clock_24h.
"""
from __future__ import annotations

from datetime import datetime

from textual.widgets import Static

from .. import dates, palette

FILL = "█"

# --- block-digit font: each glyph is 5 rows tall -------------------------- #
_FONT: dict[str, list[str]] = {
    "0": ["███", "█ █", "█ █", "█ █", "███"],
    "1": ["  █", "  █", "  █", "  █", "  █"],
    "2": ["███", "  █", "███", "█  ", "███"],
    "3": ["███", "  █", "███", "  █", "███"],
    "4": ["█ █", "█ █", "███", "  █", "  █"],
    "5": ["███", "█  ", "███", "  █", "███"],
    "6": ["███", "█  ", "███", "█ █", "███"],
    "7": ["███", "  █", "  █", "  █", "  █"],
    "8": ["███", "█ █", "███", "█ █", "███"],
    "9": ["███", "█ █", "███", "  █", "███"],
    ":": [" ", "█", " ", "█", " "],
    "AM": ["███ █   █",
           "█ █ ██ ██",
           "███ █ █ █",
           "█ █ █   █",
           "█ █ █   █"],
    "PM": ["███ █   █",
           "█ █ ██ ██",
           "███ █ █ █",
           "█   █   █",
           "█   █   █"],
}
_ROWS = 5


class BigClock(Static):
    """A big block-digit clock + date + live "now" line.

    Reads the date to display from `app.day` (or an explicit day set via
    `set_day`); the time is always the real wall clock.
    """

    DEFAULT_CSS = """
    BigClock {
        height: auto;
        content-align: center top;
        text-align: center;
        color: #20fd14;
        padding: 1 1 0 1;
    }
    """

    def __init__(self, day: str | None = None, **kwargs):
        super().__init__("", **kwargs)
        self._day = day
        self._timer = None

    # --- lifecycle -------------------------------------------------------- #
    def on_mount(self) -> None:
        self._render_clock()
        self._timer = self.set_interval(1.0, self._render_clock)

    @property
    def day(self) -> str:
        return self._day or self.app.day  # type: ignore[attr-defined]

    def set_day(self, day: str | None = None) -> None:
        """Point the date line at `day` (defaults to app.day) and re-render."""
        if day:
            self._day = day
        self._render_clock()

    # alias to match the reload(day) idiom used by the other widgets
    def reload(self, day: str | None = None) -> None:
        self.set_day(day)

    # --- rendering -------------------------------------------------------- #
    def _clock_24h(self) -> bool:
        try:
            return bool(self.app.settings.clock_24h)  # type: ignore[attr-defined]
        except Exception:
            return False

    def _tokens(self, now: datetime, clock_24h: bool) -> list[str]:
        if clock_24h:
            hs = f"{now.hour:02d}"
            ms = f"{now.minute:02d}"
            return list(hs) + [":"] + list(ms)
        h12 = now.hour % 12 or 12
        ms = f"{now.minute:02d}"
        ap = "AM" if now.hour < 12 else "PM"
        return list(str(h12)) + [":"] + list(ms) + [ap]

    def _big_rows(self, tokens: list[str]) -> list[str]:
        rows: list[str] = []
        for i in range(_ROWS):
            rows.append(" ".join(_FONT[t][i] for t in tokens))
        return rows

    def _render_clock(self) -> None:
        now = datetime.now()
        clock_24h = self._clock_24h()

        try:
            date_full = dates.pretty(self.day, "full")
        except Exception:
            date_full = self.day
        now_line = dates.clock_str(clock_24h=clock_24h, seconds=True)

        tokens = self._tokens(now, clock_24h)
        big_rows = self._big_rows(tokens)
        needed = max(len(r) for r in big_rows) if big_rows else 0

        # available inner width; can be 0 before first layout pass
        avail = 0
        try:
            avail = self.content_size.width or self.size.width
        except Exception:
            avail = 0

        parts: list[str] = []
        if avail and avail < needed:
            # too narrow for block glyphs - degrade to a plain large-ish line
            big = dates.clock_str(clock_24h=clock_24h, seconds=False)
            parts.append(f"[b {palette.ACCENT}]{big}[/]")
        else:
            for r in big_rows:
                parts.append(f"[b {palette.ACCENT}]{r}[/]")
        parts.append("")
        parts.append(f"[{palette.TEXT_SOFT}]{_esc(date_full)}[/]")
        parts.append(f"[{palette.TEXT_SUB}]now · {_esc(now_line)}[/]")
        self.update("\n".join(parts))


def _esc(text: str) -> str:
    """Escape Rich markup brackets in dynamic text."""
    return str(text).replace("[", r"\[")


__all__ = ["BigClock"]
