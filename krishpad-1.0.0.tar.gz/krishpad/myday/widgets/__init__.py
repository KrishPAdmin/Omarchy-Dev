"""MyDay reusable widgets (BigClock, agenda, todo list, ...)."""
