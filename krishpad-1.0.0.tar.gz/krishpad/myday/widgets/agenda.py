"""agenda.py - TimedAgenda: a day's schedule as a vertical timeline.

Renders `repo.list_schedule(day=...)` blocks ordered by start_min. Each row
shows the start-end time, a category colour dot, the title and note. The block
containing "now" (only when the day is today) is flagged with the `.now` class
and a "◀ NOW" tag. The current and next block are surfaced prominently at the
top via `repo.current_and_next_block`.

Interaction:
    n           add a new block (FormModal)
    e / click   edit the highlighted / clicked block (same modal + delete)
    click empty add a new block

Call `reload(day)` on date change. Survives empty days.
"""
from __future__ import annotations

from textual.app import ComposeResult
from textual.containers import Vertical
from textual.message import Message
from textual.widgets import ListItem, ListView, Static

from .. import dates, palette, repo
from ..ui import Field, FormModal, category_options


def _esc(text) -> str:
    return str(text).replace("[", r"\[")


class BlockRow(ListItem):
    """One schedule block in the timeline; carries the block dict."""

    def __init__(self, block: dict, is_now: bool = False):
        super().__init__()
        self.block = block
        self._is_now = is_now

    def compose(self) -> ComposeResult:
        b = self.block
        try:
            c24 = bool(self.app.settings.clock_24h)  # type: ignore[attr-defined]
        except Exception:
            c24 = False
        start = dates.pretty_min(b["start_min"], c24)
        end = dates.pretty_min(b["end_min"], c24)
        color = b.get("color") or palette.category_color(b.get("category"))
        title = _esc(b.get("title") or "(untitled)")
        note = (b.get("note") or "").strip()

        tag = "[b #000000 on #20fd14] ◀ NOW [/] " if self._is_now else ""
        line = (f"{tag}[{color}]●[/] "
                f"[{palette.TEXT_SUB}]{_esc(start)} - {_esc(end)}[/]  "
                f"[b {palette.TEXT}]{title}[/]")
        if note:
            line += f"   [{palette.TEXT_SUB}]· {_esc(note)}[/]"
        cls = "now" if self._is_now else ""
        yield Static(line, markup=True, classes=cls)


class TimedAgenda(Vertical):
    DEFAULT_CSS = """
    TimedAgenda { height: 1fr; }
    TimedAgenda #agenda-now {
        height: auto; padding: 0 1 1 1; color: #eeeeee;
    }
    TimedAgenda #agenda-list { height: 1fr; background: #0c0e10; }
    TimedAgenda .agenda-empty { color: #959595; padding: 1 1; }
    """

    BINDINGS = [
        ("n", "add", "New block"),
        ("e", "edit", "Edit"),
    ]

    class Changed(Message):
        """Posted after a block is added/edited/deleted."""

    def __init__(self, day: str | None = None, **kwargs):
        super().__init__(**kwargs)
        self._day = day

    @property
    def day(self) -> str:
        return self._day or self.app.day  # type: ignore[attr-defined]

    def compose(self) -> ComposeResult:
        yield Static("", id="agenda-now", markup=True)
        yield ListView(id="agenda-list")

    def on_mount(self) -> None:
        self.reload(self.day)

    # --- data ------------------------------------------------------------- #
    def reload(self, day: str | None = None) -> None:
        if day:
            self._day = day
        day = self.day
        try:
            c24 = bool(self.app.settings.clock_24h)  # type: ignore[attr-defined]
        except Exception:
            c24 = False

        blocks = repo.list_schedule(day=day)          # ordered by start_min
        is_today = dates.is_today(day)
        cur = nxt = None
        if is_today:
            cur, nxt = repo.current_and_next_block(day, dates.now_min())

        self._render_header(blocks, cur, nxt, is_today, c24)

        lv = self.query_one("#agenda-list", ListView)
        idx = lv.index
        lv.clear()
        cur_id = cur["id"] if cur else None
        for b in blocks:
            lv.append(BlockRow(b, is_now=(b["id"] == cur_id)))
        if not blocks:
            lv.append(ListItem(Static(
                "no blocks yet - press  n  (or click here) to add one",
                classes="agenda-empty")))
        elif idx is not None:
            lv.index = min(idx, len(blocks) - 1)

    def _render_header(self, blocks, cur, nxt, is_today, c24) -> None:
        def brief(b):
            return (f"{dates.pretty_min(b['start_min'], c24)}"
                    f" - {dates.pretty_min(b['end_min'], c24)}  "
                    f"{_esc(b.get('title') or '(untitled)')}")

        lines: list[str] = []
        if is_today:
            if cur:
                lines.append(f"[b {palette.ACCENT}]Now:[/]  {brief(cur)}")
            else:
                lines.append(f"[{palette.TEXT_SUB}]Now:  nothing scheduled right now[/]")
            if nxt:
                lines.append(f"[b {palette.ACCENT_DIM}]Next:[/] {brief(nxt)}")
            else:
                lines.append(f"[{palette.TEXT_SUB}]Next: nothing left today[/]")
        else:
            n = len(blocks)
            if n:
                lines.append(f"[{palette.TEXT_SOFT}]{n} block%s scheduled[/]"
                             % ("" if n == 1 else "s"))
                lines.append(f"[{palette.TEXT_SUB}]first: {brief(blocks[0])}[/]")
            else:
                lines.append(f"[{palette.TEXT_SUB}]nothing scheduled this day[/]")
        self.query_one("#agenda-now", Static).update("\n".join(lines))

    def _current(self) -> dict | None:
        lv = self.query_one("#agenda-list", ListView)
        item = lv.highlighted_child
        return getattr(item, "block", None) if item else None

    # --- interaction ------------------------------------------------------ #
    def on_list_view_selected(self, event: ListView.Selected) -> None:
        b = getattr(event.item, "block", None)
        if b:
            self._open_edit(b)
        else:
            self.action_add()          # empty placeholder tapped

    def action_add(self) -> None:
        day = self.day

        def _submit(values):
            self._save_new(day, values)
            return None

        self.app.push_screen(FormModal(
            "New block",
            self._fields(),
            values={"category": "other", "start": "09:00", "end": "10:00"},
            submit_label="Add",
            on_submit=_submit))

    def action_edit(self) -> None:
        b = self._current()
        if b:
            self._open_edit(b)

    def _open_edit(self, b: dict) -> None:
        bid = b["id"]

        def _submit(values):
            self._save_update(bid, values)
            return None

        def _delete():
            repo.delete_schedule(bid)
            self.reload()
            self._notify_change()

        self.app.push_screen(FormModal(
            "Edit block",
            self._fields(),
            values={
                "title": b.get("title", ""),
                "category": b.get("category", "other"),
                "start": dates.to_hhmm(b["start_min"]),
                "end": dates.to_hhmm(b["end_min"]),
                "note": b.get("note", ""),
            },
            submit_label="Save",
            on_submit=_submit,
            on_delete=_delete))

    # --- helpers ---------------------------------------------------------- #
    def _fields(self) -> list[Field]:
        return [
            Field("title", "Title", "text", required=True,
                  placeholder="What's happening?"),
            Field("category", "Category", "select",
                  options=category_options()),
            Field("start", "Start (HH:MM)", "time", required=True),
            Field("end", "End (HH:MM)", "time", required=True),
            Field("note", "Note", "textarea"),
        ]

    @staticmethod
    def _parse_hhmm(val, label) -> int:
        s = str(val or "").strip()
        try:
            h, m = s.split(":", 1)
            h, m = int(h), int(m)
        except Exception:
            raise repo.ValidationError(f"{label} must look like HH:MM")
        if not (0 <= h <= 23 and 0 <= m <= 59):
            raise repo.ValidationError(f"{label} must be a real time of day")
        return h * 60 + m

    def _save_new(self, day: str, values: dict) -> None:
        start = self._parse_hhmm(values.get("start"), "Start")
        end = self._parse_hhmm(values.get("end"), "End")
        repo.create_schedule(
            day, start, end, values.get("title", ""),
            category=values.get("category") or "other",
            note=values.get("note", "") or "")
        self.reload()
        self._notify_change()

    def _save_update(self, bid: int, values: dict) -> None:
        start = self._parse_hhmm(values.get("start"), "Start")
        end = self._parse_hhmm(values.get("end"), "End")
        repo.update_schedule(
            bid,
            title=values.get("title", ""),
            category=values.get("category") or "other",
            start_min=start, end_min=end,
            note=values.get("note", "") or "")
        self.reload()
        self._notify_change()

    def _notify_change(self) -> None:
        try:
            self.post_message(self.Changed())
        except Exception:
            pass


__all__ = ["TimedAgenda", "BlockRow"]
