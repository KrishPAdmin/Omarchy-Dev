"""registry.py - view & day-panel registries (pure; no Textual import).

Build agents register their view/panel classes with these decorators at import
time; the app collects them in order. Kept Textual-free so pure-logic tests can
import it without the TUI stack.

    from .registry import register_view, register_day_panel

    @register_view
    class DayView(PlannerView): VIEW_ID="day"; VIEW_ORDER=10; ...

    @register_day_panel
    class FoodPanel(DayPanel): PANEL_ID="food"; PANEL_ORDER=30; ...
"""
from __future__ import annotations

_VIEWS: dict[str, type] = {}
_PANELS: dict[str, type] = {}


def register_view(cls):
    """Class decorator: register a PlannerView subclass by its VIEW_ID."""
    vid = getattr(cls, "VIEW_ID", None)
    if not vid:
        raise ValueError(f"{cls.__name__} needs a VIEW_ID")
    _VIEWS[vid] = cls
    return cls


def register_day_panel(cls):
    pid = getattr(cls, "PANEL_ID", None)
    if not pid:
        raise ValueError(f"{cls.__name__} needs a PANEL_ID")
    _PANELS[pid] = cls
    return cls


def get_views() -> list[type]:
    return sorted(_VIEWS.values(), key=lambda c: getattr(c, "VIEW_ORDER", 100))


def get_day_panels() -> list[type]:
    return sorted(_PANELS.values(), key=lambda c: getattr(c, "PANEL_ORDER", 100))


def get_view(view_id: str):
    return _VIEWS.get(view_id)


def clear() -> None:  # for tests
    _VIEWS.clear()
    _PANELS.clear()


__all__ = ["register_view", "register_day_panel", "get_views",
           "get_day_panels", "get_view", "clear"]
