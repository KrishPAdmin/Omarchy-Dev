"""journal.py - the Journal day-panel.

A full-height TextArea bound to the day's single journal entry, with DEBOUNCED
autosave (~0.8s after typing stops) through ``repo.set_journal``. A subtle
status line shows "saving…" / "saved ✓" plus the last-updated local time. The
entry is also flushed immediately on blur, on unmount, and when the active date
changes (the previous day's pending edit is saved before the new day loads).

Programmatic loads (switching days) never trigger a save of the freshly-loaded
text - a guard flag distinguishes user typing from ``load_text``.

Self-registers via ``@register_day_panel``.
"""
from __future__ import annotations

from datetime import datetime, timezone

from textual import events
from textual.app import ComposeResult
from textual.widgets import Static, TextArea

from .. import dates, repo
from ..registry import register_day_panel
from ..ui import DayPanel

_DEBOUNCE = 0.8


def _fmt_updated(updated_at) -> str:
    """UTC 'YYYY-MM-DDTHH:MM:SSZ' -> local 'h:MM AM' (best effort)."""
    if not updated_at:
        return ""
    try:
        dt = datetime.strptime(updated_at, "%Y-%m-%dT%H:%M:%SZ").replace(
            tzinfo=timezone.utc).astimezone()
        return dates.pretty_min(dt.hour * 60 + dt.minute)
    except Exception:
        return ""


class JournalTextArea(TextArea):
    """A TextArea that tells the panel when it loses focus (for blur-save)."""

    def on_blur(self, _event: events.Blur) -> None:
        cb = getattr(self, "blur_callback", None)
        if cb is not None:
            try:
                cb()
            except Exception:
                pass


@register_day_panel
class JournalPanel(DayPanel):
    PANEL_ID = "journal"
    PANEL_TITLE = "Journal"
    PANEL_ORDER = 60

    DEFAULT_CSS = """
    JournalPanel {
        background: #0c0e10;
        border: round #2a2f33;
        padding: 0 1;
        margin: 0 1;
        height: auto;
    }
    JournalPanel:focus-within { border: round #20fd14; }
    JournalPanel .panel-title {
        text-style: bold; color: #20fd14; padding: 0 1; background: #14181b;
    }
    JournalPanel #journal-text {
        height: 10; margin: 1 0 0 0; background: #14181b; border: round #2a2f33;
    }
    JournalPanel #journal-text:focus { border: round #20fd14; }
    JournalPanel #journal-status {
        height: 1; color: #959595; padding: 0 1;
    }
    JournalPanel #journal-status.-saving { color: #e0b020; }
    JournalPanel #journal-status.-saved  { color: #12a00c; }
    """

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self._loaded_day = None
        self._loading = False        # True while load_text runs (suppress save)
        self._dirty = False
        self._timer = None

    def compose(self) -> ComposeResult:
        yield Static(self.PANEL_TITLE, classes="panel-title")
        ta = JournalTextArea(id="journal-text")
        ta.blur_callback = self._flush
        yield ta
        yield Static("", id="journal-status")

    def on_mount(self) -> None:
        day = getattr(self.app, "day", None) or dates.today()
        try:
            self.render_panel(day)
        except Exception:
            pass

    # --- render / load ----------------------------------------------------- #
    def render_panel(self, day: str) -> None:
        # save any pending edit for the day we're leaving first
        if self._loaded_day and self._loaded_day != day:
            self._flush()
        self._cancel_timer()
        self._loaded_day = day
        entry = repo.get_journal(day)
        ta = self.query_one("#journal-text", TextArea)
        self._loading = True
        try:
            ta.load_text(entry.get("content") or "")
        finally:
            self._loading = False
        self._dirty = False
        self._set_status_saved(entry.get("updated_at"))

    # --- typing / debounce ------------------------------------------------- #
    def on_text_area_changed(self, _event: TextArea.Changed) -> None:
        if self._loading:
            return
        self._dirty = True
        self._set_status_saving()
        self._restart_timer()

    def _restart_timer(self) -> None:
        self._cancel_timer()
        self._timer = self.set_timer(_DEBOUNCE, self._save)

    def _cancel_timer(self) -> None:
        if self._timer is not None:
            try:
                self._timer.stop()
            except Exception:
                pass
            self._timer = None

    def _save(self) -> None:
        self._timer = None
        if not self._dirty or not self._loaded_day:
            return
        try:
            content = self.query_one("#journal-text", TextArea).text
        except Exception:
            return
        try:
            res = repo.set_journal(self._loaded_day, content)
            self._dirty = False
            self._set_status_saved(res.get("updated_at"))
        except repo.ValidationError as e:
            self.app.notify(str(e), severity="error")
        except Exception as e:
            self.app.notify(f"journal error: {e}", severity="error")

    def _flush(self) -> None:
        """Synchronous save of any pending edit (blur / unmount / day change)."""
        self._cancel_timer()
        self._save()

    def on_unmount(self) -> None:
        self._flush()

    # --- status ------------------------------------------------------------ #
    def _status(self) -> Static:
        return self.query_one("#journal-status", Static)

    def _set_status_saving(self) -> None:
        try:
            w = self._status()
            w.remove_class("-saved")
            w.add_class("-saving")
            w.update("saving…")
        except Exception:
            pass

    def _set_status_saved(self, updated_at) -> None:
        try:
            w = self._status()
            w.remove_class("-saving")
            when = _fmt_updated(updated_at)
            if when:
                w.add_class("-saved")
                w.update(f"saved ✓ · {when}")
            else:
                w.remove_class("-saved")
                w.update("")
        except Exception:
            pass


__all__ = ["JournalPanel", "JournalTextArea"]
