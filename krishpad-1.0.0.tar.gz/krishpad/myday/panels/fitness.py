"""fitness.py - Fitness / workouts day-panel for MyDay.

Lists the day's workouts (activity, duration, intensity, note) with a total
active-minutes line. Add a workout with `a` or the button; edit/delete an
existing one by selecting its row. Intensity is colour-coded via
palette.INTENSITY_COLORS.
"""
from __future__ import annotations

from textual.app import ComposeResult
from textual.widgets import Button, ListItem, ListView, Static

from .. import palette, repo
from ..registry import register_day_panel
from ..ui import DayPanel, Field, FormModal

_INTENSITY_LABELS = {"low": "Low", "med": "Med", "high": "High"}


class _WorkoutRow(ListItem):
    def __init__(self, workout: dict):
        super().__init__()
        self.workout = workout

    def compose(self) -> ComposeResult:
        w = self.workout
        dur = w.get("duration_min")
        dur_txt = f"  [#20fd14]{dur} min[/]" if dur is not None else ""
        inten = w.get("intensity")
        col = palette.INTENSITY_COLORS.get(inten, palette.TEXT_SUB)
        inten_txt = f"  [{col}]{_INTENSITY_LABELS.get(inten, inten)}[/]" if inten else ""
        note = w.get("note") or ""
        note_txt = f"  [#959595]- {note}[/]" if note else ""
        yield Static(f"  [#eeeeee]{w['activity']}[/]{dur_txt}{inten_txt}{note_txt}",
                     markup=True)


@register_day_panel
class FitnessPanel(DayPanel):
    PANEL_ID = "fitness"
    PANEL_TITLE = "Fitness"
    PANEL_ORDER = 40
    DEFAULT_CLASSES = "panel"

    DEFAULT_CSS = """
    FitnessPanel { height: auto; }
    FitnessPanel ListView { height: auto; max-height: 18; background: #0c0e10; }
    FitnessPanel .fit-empty { color: #959595; padding: 1 1; }
    FitnessPanel #fit-total { color: #20fd14; text-style: bold; padding: 0 1; }
    FitnessPanel #fit-add { margin: 1 1 0 1; }
    """

    BINDINGS = [("a", "add_workout", "Add workout")]

    def compose(self) -> ComposeResult:
        yield Static(self.PANEL_TITLE, classes="panel-title")
        yield ListView(id="fit-list")
        yield Static("", id="fit-total", markup=True)
        yield Button("+ Add workout", id="fit-add")

    def on_mount(self) -> None:
        # Defer first paint until child widgets (ListView) can accept appends.
        self.call_after_refresh(self.render_panel, self.day)

    # --- render ----------------------------------------------------------- #
    def render_panel(self, day: str) -> None:
        if not self.is_mounted:
            return
        lv = self.query_one("#fit-list", ListView)
        idx = lv.index
        lv.clear()
        workouts = repo.list_workouts(day=day)
        if not workouts:
            lv.append(ListItem(Static("no workouts logged - press a to add one",
                                      classes="fit-empty")))
        else:
            for w in workouts:
                lv.append(_WorkoutRow(w))
        total = sum(w["duration_min"] for w in workouts if w.get("duration_min"))
        self.query_one("#fit-total", Static).update(
            f"Active: [#20fd14]{total} min[/]  ·  {len(workouts)} workout"
            f"{'s' if len(workouts) != 1 else ''}" if workouts else "")
        if workouts and idx is not None:
            try:
                lv.index = min(idx, len(workouts) - 1)
            except Exception:
                pass

    # --- interactions ----------------------------------------------------- #
    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "fit-add":
            self.action_add_workout()

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        w = getattr(event.item, "workout", None)
        if w:
            self._edit_workout(w)

    def _workout_fields(self) -> list[Field]:
        # An explicit "None" option (value "") keeps intensity optional while
        # avoiding the blank-Select path (repo maps "" -> None).
        return [
            Field("activity", "Activity", "text", required=True,
                  placeholder="e.g. Running"),
            Field("duration_min", "Duration (min)", "number", placeholder="e.g. 30"),
            Field("intensity", "Intensity", "select",
                  options=[("None", "")]
                  + [(_INTENSITY_LABELS[i], i) for i in repo.VALID_INTENSITIES]),
            Field("note", "Note", "textarea"),
        ]

    def action_add_workout(self) -> None:
        day = self.day

        def _submit(values):
            repo.create_workout(
                day, values.get("activity"),
                duration_min=values.get("duration_min") or None,
                intensity=values.get("intensity") or None,
                note=values.get("note") or "")
            self.render_panel(day)
            return None

        self.app.push_screen(FormModal(
            "Add workout", self._workout_fields(),
            values={"intensity": ""}, on_submit=_submit))

    def _edit_workout(self, w: dict) -> None:
        day = self.day
        wid = w["id"]
        vals = {
            "activity": w["activity"],
            "duration_min": "" if w.get("duration_min") is None else str(w["duration_min"]),
            "intensity": w.get("intensity") or "",
            "note": w.get("note") or "",
        }

        def _submit(values):
            repo.update_workout(
                wid, activity=values.get("activity"),
                duration_min=values.get("duration_min") or None,
                intensity=values.get("intensity") or None,
                note=values.get("note") or "")
            self.render_panel(day)
            return None

        def _delete():
            repo.delete_workout(wid)
            self.render_panel(day)

        self.app.push_screen(FormModal(
            "Edit workout", self._workout_fields(), values=vals,
            on_submit=_submit, on_delete=_delete))
