"""metrics.py - Health metrics day-panel for MyDay.

Edits the day's health metrics: sleep hours, weight, and mood (1..5). Mood is
a 5-way picker (glyphs from palette.MOOD_GLYPHS / MOOD_ASCII) - click a face or
press 1-5. Sleep and weight are edited via a small number form (`e` or button).
Values persist through repo.get_metrics / repo.set_metrics.
"""
from __future__ import annotations

from textual.app import ComposeResult
from textual.containers import Horizontal
from textual.widgets import Button, Static

from .. import palette, repo
from ..registry import register_day_panel
from ..ui import DayPanel, Field, FormModal


@register_day_panel
class MetricsPanel(DayPanel):
    PANEL_ID = "metrics"
    PANEL_TITLE = "Health"
    PANEL_ORDER = 45
    DEFAULT_CLASSES = "panel"

    DEFAULT_CSS = """
    MetricsPanel { height: auto; }
    MetricsPanel #met-vals { padding: 1 1 0 1; }
    MetricsPanel #met-mood-lbl { color: #959595; padding: 1 1 0 1; }
    MetricsPanel #met-mood { height: auto; padding: 0 1; }
    MetricsPanel #met-mood Button {
        min-width: 6; margin: 0 1 0 0; border: round #2a2f33;
    }
    MetricsPanel #met-mood Button.-sel {
        border: round #20fd14; text-style: bold;
    }
    MetricsPanel #met-edit { margin: 1 1 0 1; }
    """

    BINDINGS = [
        ("e", "edit", "Edit sleep/weight"),
        ("1", "mood(1)", "Mood 1"),
        ("2", "mood(2)", "Mood 2"),
        ("3", "mood(3)", "Mood 3"),
        ("4", "mood(4)", "Mood 4"),
        ("5", "mood(5)", "Mood 5"),
    ]

    def compose(self) -> ComposeResult:
        yield Static(self.PANEL_TITLE, classes="panel-title")
        yield Static("", id="met-vals", markup=True)
        yield Static("Mood", id="met-mood-lbl")
        with Horizontal(id="met-mood"):
            for n in range(1, 6):
                glyph = palette.MOOD_GLYPHS.get(n) or palette.MOOD_ASCII.get(n, str(n))
                yield Button(f"{n} {glyph}", id=f"met-mood-{n}")
        yield Button("Edit sleep / weight", id="met-edit")

    def on_mount(self) -> None:
        self.call_after_refresh(self.render_panel, self.day)

    # --- render ----------------------------------------------------------- #
    def render_panel(self, day: str) -> None:
        if not self.is_mounted:
            return
        try:
            m = repo.get_metrics(day)
        except Exception:
            m = {"sleep_hours": None, "weight": None, "mood": None}

        sleep = m.get("sleep_hours")
        weight = m.get("weight")
        mood = m.get("mood")
        sleep_txt = f"[#20fd14]{sleep:g} h[/]" if sleep is not None else "[#959595]-[/]"
        weight_txt = f"[#20fd14]{weight:g}[/]" if weight is not None else "[#959595]-[/]"
        if mood:
            mcol = palette.mood_color(mood)
            mglyph = palette.MOOD_GLYPHS.get(mood) or palette.MOOD_ASCII.get(mood, "")
            mood_txt = f"[{mcol}]{mglyph} ({mood}/5)[/]"
        else:
            mood_txt = "[#959595]not set[/]"
        self.query_one("#met-vals", Static).update(
            f"[#959595]Sleep[/]  {sleep_txt}     "
            f"[#959595]Weight[/]  {weight_txt}     "
            f"[#959595]Mood[/]  {mood_txt}")

        # highlight the selected mood face
        for n in range(1, 6):
            btn = self.query_one(f"#met-mood-{n}", Button)
            if mood and n == mood:
                btn.add_class("-sel")
            else:
                btn.remove_class("-sel")

    # --- interactions ----------------------------------------------------- #
    def on_button_pressed(self, event: Button.Pressed) -> None:
        bid = event.button.id or ""
        if bid == "met-edit":
            self.action_edit()
        elif bid.startswith("met-mood-"):
            try:
                self.action_mood(int(bid.rsplit("-", 1)[1]))
            except ValueError:
                pass

    def action_mood(self, n: int) -> None:
        try:
            repo.set_metrics(self.day, mood=n)
        except repo.ValidationError as e:
            self.app.notify(str(e), severity="error"); return
        self.render_panel(self.day)

    def action_edit(self) -> None:
        day = self.day
        try:
            m = repo.get_metrics(day)
        except Exception:
            m = {"sleep_hours": None, "weight": None}
        vals = {
            "sleep_hours": "" if m.get("sleep_hours") is None else str(m["sleep_hours"]),
            "weight": "" if m.get("weight") is None else str(m["weight"]),
        }

        def _submit(values):
            repo.set_metrics(
                day,
                sleep_hours=values.get("sleep_hours") or None,
                weight=values.get("weight") or None)
            self.render_panel(day)
            return None

        self.app.push_screen(FormModal(
            "Sleep & weight",
            [Field("sleep_hours", "Sleep (hours)", "number", placeholder="e.g. 7.5"),
             Field("weight", "Weight", "number", placeholder="e.g. 165")],
            values=vals, on_submit=_submit))
