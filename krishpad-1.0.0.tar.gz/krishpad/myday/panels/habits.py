"""habits.py - the Habits day-panel.

Shows the day's active habits as toggle rows: a glyph for whether the habit is
done today, the habit name in its colour, and the current streak ("🔥 5"). A
row toggles on click / space / enter. Management (add / rename / recolour /
delete) is reachable via the Manage button or the per-row keys:

    space / enter   toggle today
    e               edit (rename / recolour)
    d               delete (with confirm)
    a / m           add a new habit

Self-registers via ``@register_day_panel``. Reads/writes go through ``repo``;
``repo.ValidationError`` surfaces as an error toast (or inline in the modal).
"""
from __future__ import annotations

from rich.markup import escape

from textual.app import ComposeResult
from textual.containers import Horizontal, VerticalScroll
from textual.message import Message
from textual.widgets import Button, Static

from .. import dates, palette, repo
from ..registry import register_day_panel
from ..ui import ConfirmModal, DayPanel, Field, FormModal


# --------------------------------------------------------------------------- #
# one habit row
# --------------------------------------------------------------------------- #
class HabitRow(Static):
    """A single focusable, clickable habit toggle line."""

    can_focus = True

    BINDINGS = [
        ("space", "toggle", "Toggle"),
        ("enter", "toggle", "Toggle"),
        ("e", "edit", "Edit"),
        ("d", "delete", "Delete"),
        ("a", "add", "Add"),
        ("m", "add", "Manage"),
    ]

    class Toggle(Message):
        def __init__(self, habit_id: int) -> None:
            super().__init__()
            self.habit_id = habit_id

    class Edit(Message):
        def __init__(self, habit: dict) -> None:
            super().__init__()
            self.habit = habit

    class Delete(Message):
        def __init__(self, habit: dict) -> None:
            super().__init__()
            self.habit = habit

    class Add(Message):
        pass

    def __init__(self, habit: dict, index: int) -> None:
        super().__init__()
        self.habit = habit
        self.index = index

    def color(self) -> str:
        return self.habit.get("color") or palette.habit_color(self.index)

    def refresh_content(self, day: str) -> None:
        """Recompute done-state + streak for `day` and repaint the line."""
        logs = {l["habit_id"]: l["done"] for l in repo.list_habit_logs(day=day)}
        done = bool(logs.get(self.habit["id"], 0))
        streak = repo.habit_streak(self.habit["id"], day)
        col = self.color()
        box = "[b #20fd14]◉[/]" if done else "[#5a5f63]○[/]"
        name = f"[{col}]{escape(self.habit['name'])}[/]"
        if streak > 0:
            tail = f"  [#e0b020]🔥 {streak}[/]"
        else:
            tail = "  [#5a5f63]· 0[/]"
        self.set_class(done, "-done")
        self.update(f"{box}  {name}{tail}")

    # --- input ------------------------------------------------------------- #
    def on_click(self) -> None:
        self.focus()
        self.post_message(self.Toggle(self.habit["id"]))

    def action_toggle(self) -> None:
        self.post_message(self.Toggle(self.habit["id"]))

    def action_edit(self) -> None:
        self.post_message(self.Edit(self.habit))

    def action_delete(self) -> None:
        self.post_message(self.Delete(self.habit))

    def action_add(self) -> None:
        self.post_message(self.Add())


# --------------------------------------------------------------------------- #
# the panel
# --------------------------------------------------------------------------- #
@register_day_panel
class HabitsPanel(DayPanel):
    PANEL_ID = "habits"
    PANEL_TITLE = "Habits"
    PANEL_ORDER = 50

    DEFAULT_CSS = """
    HabitsPanel {
        background: #0c0e10;
        border: round #2a2f33;
        padding: 0 1;
        margin: 0 1;
        height: auto;
    }
    HabitsPanel:focus-within { border: round #20fd14; }
    HabitsPanel .panel-title {
        text-style: bold; color: #20fd14; padding: 0 1; background: #14181b;
    }
    HabitsPanel #habit-actions { height: auto; padding: 0 0 1 0; }
    HabitsPanel #habit-actions Button { margin: 0 2 0 0; min-width: 8; }
    HabitsPanel #habit-hint { color: #5a5f63; padding: 1 0 0 1; }
    HabitsPanel #habit-rows { height: auto; max-height: 16; }
    HabitsPanel HabitRow { height: 1; padding: 0 1; color: #eeeeee; }
    HabitsPanel HabitRow:focus { background: #14181b; text-style: bold; }
    HabitsPanel HabitRow:hover { background: #0e1113; }
    HabitsPanel .habits-empty { color: #959595; padding: 1; }
    """

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self._current_day = None
        self._rows: dict[int, HabitRow] = {}

    def compose(self) -> ComposeResult:
        yield Static(self.PANEL_TITLE, classes="panel-title", id="habit-title")
        with Horizontal(id="habit-actions"):
            yield Button("+ Add", id="habit-add", classes="-primary")
            yield Button("Manage", id="habit-manage")
        yield VerticalScroll(id="habit-rows")

    def on_mount(self) -> None:
        day = getattr(self.app, "day", None) or dates.today()
        try:
            self.render_panel(day)
        except Exception:
            pass

    # --- render ------------------------------------------------------------ #
    def render_panel(self, day: str) -> None:
        self._current_day = day
        rows = self.query_one("#habit-rows", VerticalScroll)
        rows.remove_children()          # deferred; rows carry no fixed IDs
        self._rows = {}
        habits = repo.list_habits()
        title = self.query_one("#habit-title", Static)
        if not habits:
            title.update(f"{self.PANEL_TITLE}")
            rows.mount(Static(
                "No habits yet. Press [b #20fd14]+ Add[/] to create one.",
                classes="habits-empty"))
            return
        logs = {l["habit_id"]: l["done"] for l in repo.list_habit_logs(day=day)}
        done_n = sum(1 for h in habits if logs.get(h["id"], 0))
        title.update(f"{self.PANEL_TITLE}  [#5a5f63]{done_n}/{len(habits)}[/]")
        for i, h in enumerate(habits):
            row = HabitRow(h, i)
            rows.mount(row)
            self._rows[h["id"]] = row
            row.refresh_content(day)

    def _day(self) -> str:
        return self._current_day or (getattr(self.app, "day", None) or "")

    def _refresh_row(self, habit_id: int) -> None:
        row = self._rows.get(habit_id)
        if row is None:
            return
        try:
            row.refresh_content(self._day())
        except Exception:
            pass

    def _refresh_title(self) -> None:
        try:
            habits = repo.list_habits()
            logs = {l["habit_id"]: l["done"]
                    for l in repo.list_habit_logs(day=self._day())}
            done_n = sum(1 for h in habits if logs.get(h["id"], 0))
            self.query_one("#habit-title", Static).update(
                f"{self.PANEL_TITLE}  [#5a5f63]{done_n}/{len(habits)}[/]")
        except Exception:
            pass

    # --- messages from rows ----------------------------------------------- #
    def on_habit_row_toggle(self, msg: HabitRow.Toggle) -> None:
        try:
            repo.toggle_habit(msg.habit_id, self._day())
        except repo.ValidationError as e:
            self.app.notify(str(e), severity="error")
            return
        except Exception as e:
            self.app.notify(f"habit error: {e}", severity="error")
            return
        self._refresh_row(msg.habit_id)
        self._refresh_title()

    def on_habit_row_edit(self, msg: HabitRow.Edit) -> None:
        self._open_edit(msg.habit)

    def on_habit_row_delete(self, msg: HabitRow.Delete) -> None:
        self._open_delete(msg.habit)

    def on_habit_row_add(self, _msg: HabitRow.Add) -> None:
        self._open_add()

    # --- buttons ----------------------------------------------------------- #
    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id in ("habit-add", "habit-manage"):
            self._open_add()

    # --- modals ------------------------------------------------------------ #
    def _open_add(self) -> None:
        idx = len(repo.list_habits())
        suggested = palette.habit_color(idx)

        def _submit(values):
            repo.create_habit(values.get("name", ""), values.get("color") or "")
            self.render_panel(self._day())
            return None

        self.app.push_screen(FormModal(
            "New habit",
            [Field("name", "Name", "text", required=True),
             Field("color", "Colour", "color")],
            values={"color": suggested},
            submit_label="Add", on_submit=_submit))

    def _open_edit(self, habit: dict) -> None:
        def _submit(values):
            repo.update_habit(habit["id"], name=values.get("name", ""),
                              color=values.get("color") or "")
            self.render_panel(self._day())
            return None

        self.app.push_screen(FormModal(
            f"Edit habit",
            [Field("name", "Name", "text", required=True),
             Field("color", "Colour", "color")],
            values={"name": habit["name"], "color": habit.get("color") or ""},
            submit_label="Save", on_submit=_submit))

    def _open_delete(self, habit: dict) -> None:
        def _done(confirmed: bool) -> None:
            if not confirmed:
                return
            try:
                repo.delete_habit(habit["id"])
            except Exception as e:
                self.app.notify(f"habit error: {e}", severity="error")
                return
            self.render_panel(self._day())

        self.app.push_screen(ConfirmModal(
            f"Delete habit “{habit['name']}” and all its logs?",
            yes_label="Delete", danger=True), _done)


__all__ = ["HabitsPanel", "HabitRow"]
