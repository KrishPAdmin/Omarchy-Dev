"""MyDay Today/Day sub-panels (self-register via register_day_panel)."""
