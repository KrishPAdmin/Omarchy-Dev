"""food.py - Food / nutrition day-panel for MyDay.

Shows the day's meals grouped by type (breakfast/lunch/dinner/snack) with a
total-calories line, plus a water-cups stepper. Add a meal with `a` or the
button; edit/delete an existing meal by selecting its row. Water goes up/down
with the +/- buttons (or keys) and calls repo.add_water.
"""
from __future__ import annotations

from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical
from textual.widgets import Button, ListItem, ListView, Static

from .. import dates, repo
from ..registry import register_day_panel
from ..ui import DayPanel, Field, FormModal

_MEAL_LABELS = {"breakfast": "Breakfast", "lunch": "Lunch",
                "dinner": "Dinner", "snack": "Snack"}


def _parse_time(val) -> int | None:
    """'HH:MM' -> minutes, '' -> None; bad input raises ValidationError."""
    v = (val or "").strip()
    if not v:
        return None
    try:
        m = dates.to_min(v)
    except Exception:
        raise repo.ValidationError("time must be HH:MM")
    if not (0 <= m <= 1439):
        raise repo.ValidationError("meal time must be within the day")
    return m


class _MealRow(ListItem):
    def __init__(self, meal: dict, clock_24h: bool = False):
        super().__init__()
        self.meal = meal
        self._clock_24h = clock_24h

    def compose(self) -> ComposeResult:
        m = self.meal
        cal = m.get("calories")
        cal_txt = f"  [#20fd14]{cal} kcal[/]" if cal is not None else ""
        t = m.get("time_min")
        t_txt = f"  [#959595]{dates.pretty_min(t, self._clock_24h)}[/]" if t is not None else ""
        note = m.get("note") or ""
        note_txt = f"  [#959595]- {note}[/]" if note else ""
        yield Static(f"  [#eeeeee]{m['name']}[/]{cal_txt}{t_txt}{note_txt}", markup=True)


@register_day_panel
class FoodPanel(DayPanel):
    PANEL_ID = "food"
    PANEL_TITLE = "Food"
    PANEL_ORDER = 30
    DEFAULT_CLASSES = "panel"

    DEFAULT_CSS = """
    FoodPanel { height: auto; }
    FoodPanel #food-water { height: auto; padding: 0 1; }
    FoodPanel #food-water Static { width: 1fr; content-align: left middle; }
    FoodPanel #food-water Button { min-width: 5; margin: 0 0 0 1; }
    FoodPanel ListView { height: auto; max-height: 18; background: #0c0e10; }
    FoodPanel .food-head { color: #20fd14; text-style: bold; padding: 1 0 0 0; }
    FoodPanel .food-empty { color: #959595; padding: 1 1; }
    FoodPanel #food-total { color: #20fd14; text-style: bold; padding: 0 1; }
    FoodPanel #food-add { margin: 1 1 0 1; }
    """

    BINDINGS = [
        ("a", "add_meal", "Add meal"),
        ("plus", "water(1)", "Water +"),
        ("minus", "water(-1)", "Water -"),
    ]

    def compose(self) -> ComposeResult:
        yield Static(self.PANEL_TITLE, classes="panel-title")
        with Horizontal(id="food-water"):
            yield Static("", id="food-water-lbl", markup=True)
            yield Button("- cup", id="food-water-dec")
            yield Button("+ cup", id="food-water-inc")
        yield ListView(id="food-list")
        yield Static("", id="food-total", markup=True)
        yield Button("+ Add meal", id="food-add")

    def on_mount(self) -> None:
        # Defer first paint until child widgets (ListView) can accept appends.
        self.call_after_refresh(self.render_panel, self.day)

    # --- render ----------------------------------------------------------- #
    def render_panel(self, day: str) -> None:
        if not self.is_mounted:
            return
        c24 = getattr(getattr(self, "app", None), "settings", None)
        c24 = bool(getattr(c24, "clock_24h", False))
        # water
        try:
            cups = repo.get_metrics(day)["water_cups"] or 0
        except Exception:
            cups = 0
        drops = "".join("~" for _ in range(min(cups, 12)))
        self.query_one("#food-water-lbl", Static).update(
            f"[#3aa0c9]Water[/]  [#20fd14]{cups}[/] cups  [#3aa0c9]{drops}[/]")

        # meals grouped by type
        lv = self.query_one("#food-list", ListView)
        idx = lv.index
        lv.clear()
        meals = repo.list_meals(day=day)
        by_type: dict[str, list[dict]] = {t: [] for t in repo.VALID_MEAL_TYPES}
        for m in meals:
            by_type.setdefault(m["meal_type"], []).append(m)
        n_rows = 0
        if not meals:
            lv.append(ListItem(Static("nothing logged yet - press a to add a meal",
                                      classes="food-empty")))
        else:
            for t in repo.VALID_MEAL_TYPES:
                group = by_type.get(t) or []
                if not group:
                    continue
                gcal = sum(g["calories"] for g in group if g.get("calories"))
                head = f"{_MEAL_LABELS[t]}"
                if gcal:
                    head += f"  ({gcal} kcal)"
                lv.append(ListItem(Static(head, classes="food-head")))
                for g in group:
                    lv.append(_MealRow(g, c24))
                    n_rows += 1
        total = sum(m["calories"] for m in meals if m.get("calories"))
        self.query_one("#food-total", Static).update(
            f"Total: [#20fd14]{total} kcal[/]  ·  {len(meals)} item"
            f"{'s' if len(meals) != 1 else ''}" if meals else "")
        if n_rows and idx is not None:
            try:
                lv.index = min(idx, len(lv.children) - 1)
            except Exception:
                pass

    # --- interactions ----------------------------------------------------- #
    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "food-add":
            self.action_add_meal()
        elif event.button.id == "food-water-inc":
            self.action_water(1)
        elif event.button.id == "food-water-dec":
            self.action_water(-1)

    def action_water(self, delta: int) -> None:
        try:
            repo.add_water(self.day, delta)
        except repo.ValidationError as e:
            self.app.notify(str(e), severity="error"); return
        self.render_panel(self.day)

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        meal = getattr(event.item, "meal", None)
        if meal:
            self._edit_meal(meal)

    def _meal_fields(self) -> list[Field]:
        return [
            Field("meal_type", "Type", "select", required=True,
                  options=[(_MEAL_LABELS[t], t) for t in repo.VALID_MEAL_TYPES]),
            Field("name", "Name", "text", required=True),
            Field("calories", "Calories", "number", placeholder="e.g. 450"),
            Field("time", "Time (HH:MM)", "time"),
            Field("note", "Note", "textarea"),
        ]

    def action_add_meal(self) -> None:
        day = self.day

        def _submit(values):
            repo.create_meal(
                day, values.get("meal_type"), values.get("name"),
                calories=values.get("calories") or None,
                time_min=_parse_time(values.get("time")),
                note=values.get("note") or "")
            self.render_panel(day)
            return None

        self.app.push_screen(FormModal(
            "Add meal", self._meal_fields(),
            values={"meal_type": "breakfast"}, on_submit=_submit))

    def _edit_meal(self, meal: dict) -> None:
        day = self.day
        mid = meal["id"]
        t = meal.get("time_min")
        vals = {
            "meal_type": meal["meal_type"],
            "name": meal["name"],
            "calories": "" if meal.get("calories") is None else str(meal["calories"]),
            "time": "" if t is None else dates.to_hhmm(t),
            "note": meal.get("note") or "",
        }

        def _submit(values):
            repo.update_meal(
                mid, meal_type=values.get("meal_type"), name=values.get("name"),
                calories=values.get("calories") or None,
                time_min=_parse_time(values.get("time")),
                note=values.get("note") or "")
            self.render_panel(day)
            return None

        def _delete():
            repo.delete_meal(mid)
            self.render_panel(day)

        self.app.push_screen(FormModal(
            "Edit meal", self._meal_fields(), values=vals,
            on_submit=_submit, on_delete=_delete))
