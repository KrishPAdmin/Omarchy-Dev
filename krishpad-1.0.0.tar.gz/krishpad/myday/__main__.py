"""myday CLI entry point.

    myday                 launch the full planner (Today view)
    myday day|week|month|year|plan
                          launch on a specific view
    myday widget          compact always-on status widget (small terminal)
    myday status          print ONE line of status (for waybar/tmux/scripts)
    myday screensaver     run the pixel screensaver standalone (test it)
    myday --version

Subcommands beyond the core app are provided by build agents (statusline.py,
widgets/status_widget.py, screensaver/engine.py) and imported lazily so the
core app still runs if one is absent.
"""
from __future__ import annotations

import sys

from . import __version__

_VIEWS = {"day", "week", "month", "year", "plan", "today"}


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)

    if argv and argv[0] in ("--version", "-V"):
        print(f"myday {__version__}")
        return 0
    if argv and argv[0] in ("--help", "-h", "help"):
        print(__doc__)
        return 0

    cmd = argv[0] if argv else "app"

    # one-line status for status bars / scripts
    if cmd == "status":
        try:
            from .statusline import print_status
            print_status(argv[1:])
            return 0
        except Exception as e:
            print(f"myday: {e}")
            return 1

    # standalone screensaver
    if cmd == "screensaver":
        try:
            from .screensaver.engine import run_standalone
            run_standalone()
            return 0
        except Exception as e:
            print(f"myday screensaver unavailable: {e}")
            return 1

    # compact widget mode
    if cmd == "widget":
        try:
            from .widgets.status_widget import run_widget
            run_widget()
            return 0
        except Exception as e:
            print(f"myday widget unavailable: {e}")
            return 1

    # full app, optionally on a named view
    start_view = None
    if cmd in _VIEWS:
        start_view = "day" if cmd == "today" else cmd
    from .app import MyDayApp
    MyDayApp(start_view=start_view).run()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
