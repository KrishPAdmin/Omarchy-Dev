"""statusline.py - ONE line of "right now" for a status bar / tmux / prompt.

`myday status` dispatches here. The whole point is to be *fast* and to *never
throw*: a status bar polls this many times a minute, and a crash would leave a
hole in the user's bar. Every code path is wrapped; on any error we still print
a safe fallback line (or a valid JSON object in --json mode) and return cleanly.

Plain text examples::

      Deep work · ends 10:30 · 3 tasks
    ◈ free · 3 tasks · ▶ 14:00 Standup
    ◈ all clear

Flags::

    --json            waybar object {"text","tooltip","class"} (tooltip = agenda)
    --icon/--no-icon  nerd-font glyphs vs pure ascii
    --width N         truncate the text to N columns (…)

No Textual import lives here - pure repo/dates/config + json, so it starts fast.
"""
from __future__ import annotations

import json

# --------------------------------------------------------------------------- #
# glyph sets
# --------------------------------------------------------------------------- #
# icon mode: nerd-font / unicode symbols (a waybar bar has a nerd font loaded).
_ICON = {
    "busy":  "",   # nf hourglass-half
    "free":  "◈",   # ◈ diamond-in-square
    "night": "",   # nf moon
    "next":  "▶",   # ▶
    "task":  "",   # nf tasks
    "clear": "",   # nf check
    "sep":   "·",   # ·
}
# ascii mode: nothing outside 7-bit, safe on any font/terminal.
_ASCII = {
    "busy":  "*",
    "free":  "o",
    "night": "(",
    "next":  ">",
    "task":  "-",
    "clear": "*",
    "sep":   "-",
}


def _glyphs(icon: bool) -> dict:
    return _ICON if icon else _ASCII


# --------------------------------------------------------------------------- #
# arg parsing (must never throw)
# --------------------------------------------------------------------------- #
def _parse_args(args) -> dict:
    opts = {"json": False, "icon": True, "width": 0}
    try:
        it = iter(list(args or []))
        for a in it:
            if a == "--json":
                opts["json"] = True
            elif a == "--icon":
                opts["icon"] = True
            elif a == "--no-icon":
                opts["icon"] = False
            elif a == "--width":
                try:
                    opts["width"] = max(0, int(next(it)))
                except Exception:
                    opts["width"] = 0
            elif a.startswith("--width="):
                try:
                    opts["width"] = max(0, int(a.split("=", 1)[1]))
                except Exception:
                    opts["width"] = 0
    except Exception:
        pass
    return opts


# --------------------------------------------------------------------------- #
# helpers
# --------------------------------------------------------------------------- #
def _plural(n: int, word: str) -> str:
    return f"{n} {word}" if n == 1 else f"{n} {word}s"


def _truncate(text: str, width: int) -> str:
    if width and len(text) > width:
        if width <= 1:
            return text[:width]
        return text[: width - 1].rstrip() + "…"   # …
    return text


def _hhmm(minutes) -> str:
    from . import dates
    try:
        return dates.to_hhmm(int(minutes))
    except Exception:
        return "--:--"


# --------------------------------------------------------------------------- #
# core: assemble text + tooltip + class
# --------------------------------------------------------------------------- #
def _build(opts: dict) -> dict:
    from . import config, dates, repo, db

    # cheapest possible "ensure the tables exist" - no seeding, no writes.
    try:
        db.init_db()
    except Exception:
        pass

    g = _glyphs(opts["icon"])
    sep = f" {g['sep']} "

    today = dates.today()
    now = dates.now_min()

    cur, nxt = repo.current_and_next_block(today, now)
    counts = repo.day_counts(today)
    open_tasks = int(counts.get("todos_open", 0))

    try:
        night = config.in_night_window()
    except Exception:
        night = False

    # ---- one-line text ---------------------------------------------------- #
    if cur:
        lead = g["night"] if night else g["busy"]
        parts = [f"{lead} {cur['title']}", f"ends {_hhmm(cur['end_min'])}"]
        if open_tasks:
            parts.append(_plural(open_tasks, "task"))
        text = sep.join(parts)
        klass = "night" if night else "busy"
    else:
        lead = g["night"] if night else g["free"]
        if not open_tasks and not nxt:
            text = f"{lead} all clear"
        else:
            parts = [f"{lead} free"]
            if open_tasks:
                parts.append(_plural(open_tasks, "task"))
            if nxt:
                parts.append(f"{g['next']} {_hhmm(nxt['start_min'])} {nxt['title']}")
            text = sep.join(parts)
        klass = "night" if night else "free"

    text = _truncate(text, opts["width"])

    # ---- tooltip: today's agenda ----------------------------------------- #
    tooltip = _tooltip(today, now, cur)

    return {"text": text, "tooltip": tooltip, "class": klass}


def _tooltip(today: str, now: int, cur) -> str:
    from . import dates, repo
    lines = [dates.pretty(today, "full")]

    try:
        blocks = repo.list_schedule(day=today)
    except Exception:
        blocks = []
    lines.append("")
    if blocks:
        cur_id = cur.get("id") if isinstance(cur, dict) else None
        for b in blocks:
            marker = "▸ " if b.get("id") == cur_id else "  "   # ▸ current
            past = b.get("end_min", 0) <= now and b.get("id") != cur_id
            title = b.get("title", "")
            row = f"{marker}{_hhmm(b['start_min'])}-{_hhmm(b['end_min'])}  {title}"
            if past:
                row += "  (done)"
            lines.append(row)
    else:
        lines.append("  no schedule blocks")

    try:
        todos = [t for t in repo.list_todos(day=today) if not t.get("done")]
    except Exception:
        todos = []
    lines.append("")
    if todos:
        lines.append(f"Open todos ({len(todos)}):")
        for t in todos:
            lines.append(f"  [ ] {t.get('text', '')}")
    else:
        lines.append("No open todos")

    return "\n".join(lines)


# --------------------------------------------------------------------------- #
# entry point
# --------------------------------------------------------------------------- #
def print_status(args) -> None:
    """Print exactly one status line (or one JSON object). Never raises."""
    opts = _parse_args(args)
    try:
        data = _build(opts)
    except Exception:
        # absolute last-resort fallback - keep the bar alive.
        g = _glyphs(opts.get("icon", True))
        data = {"text": f"{g['free']} myday", "tooltip": "myday", "class": "free"}

    if opts["json"]:
        try:
            print(json.dumps(data, ensure_ascii=False))
        except Exception:
            print('{"text": "myday", "tooltip": "", "class": "free"}')
    else:
        # guarantee a single line even if data somehow carried a newline.
        print(str(data.get("text", "")).replace("\n", " "))


__all__ = ["print_status"]
