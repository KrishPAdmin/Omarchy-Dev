"""palette.py - the single source of colour truth for MyDay.

These values are lifted straight from krishadmin.com's CSS custom properties
so the terminal app reads as the same brand:

    --accent      #20fd14   (signature neon green)
    --bg          #000000   (pure black)
    --glassBg     rgba(12,14,16,0.78)  -> ~#0c0e10 on black
    --glassBorder rgba(255,255,255,0.10)
    --textOnGlass #eeeeee
    --textSoft    #bebebe
    --textSub     #959595
    secondary     #69021b   (deep maroon accent)

theme.tcss hardcodes the same hexes for Textual widgets; screensaver effects
and category chips import from here so Rich renders match exactly. Keep the two
in sync (see docs/THEME.md).
"""
from __future__ import annotations

# --- brand core ------------------------------------------------------------ #
ACCENT      = "#20fd14"   # neon green
ACCENT_DIM  = "#12a00c"   # muted green for inactive / trails
ACCENT_DEEP = "#0a5406"   # darkest green for faint screensaver trails
BG          = "#000000"   # pure black
PANEL       = "#0c0e10"   # glass panel background on black
PANEL_HI    = "#14181b"   # slightly lifted panel
BORDER      = "#2a2f33"   # ~ rgba(255,255,255,0.10) flattened on black
BORDER_HI   = "#3a4147"
TEXT        = "#eeeeee"    # primary text on glass
TEXT_SOFT   = "#bebebe"
TEXT_SUB    = "#959595"
MAROON      = "#69021b"   # secondary accent (warnings / "danger")
MAROON_HI   = "#a4102f"

# --- semantic --------------------------------------------------------------- #
OK      = ACCENT
WARN    = "#e0b020"
ERROR   = MAROON_HI
INFO    = "#3aa0c9"

# --- schedule category colours (keyed to repo.CATEGORY_IDS) ----------------- #
# Chosen to stay legible on black while keeping green as the hero.
CATEGORY_COLORS = {
    "work":     "#20fd14",   # hero green
    "personal": "#3aa0c9",   # cyan-blue
    "health":   "#2f9e6b",   # jade
    "focus":    "#6d5efc",   # indigo
    "break":    "#e0b020",   # amber
    "errand":   "#c98a3a",   # tan
    "other":    "#959595",   # grey
}

# --- habit default palette (cycled when the user adds habits) ---------------- #
HABIT_PALETTE = ["#20fd14", "#3aa0c9", "#2f9e6b", "#e08a2f", "#6d5efc",
                 "#c94f8a", "#e0b020", "#7fd4ff"]

# --- mood 1..5 -> colour + glyph -------------------------------------------- #
MOOD_COLORS = {1: "#a4102f", 2: "#c98a3a", 3: "#e0b020", 4: "#7fd47f", 5: "#20fd14"}
MOOD_GLYPHS = {1: "😞", 2: "🙁", 3: "😐", 4: "🙂", 5: "😄"}
MOOD_ASCII  = {1: "x_x", 2: ":(", 3: ":|", 4: ":)", 5: ":D"}

# --- intensity -------------------------------------------------------------- #
INTENSITY_COLORS = {"low": "#7fd47f", "med": "#e0b020", "high": "#a4102f", None: "#959595"}


def category_color(cat: str | None) -> str:
    return CATEGORY_COLORS.get(cat or "other", CATEGORY_COLORS["other"])


def habit_color(index: int) -> str:
    return HABIT_PALETTE[index % len(HABIT_PALETTE)]


def mood_color(mood: int | None) -> str:
    return MOOD_COLORS.get(mood or 0, TEXT_SUB)


# A ramp of greens for pixel/plasma screensaver effects (dark -> bright).
GREEN_RAMP = ["#031d02", "#0a5406", "#0e7a08", "#12a00c", "#18cf10", "#20fd14", "#9dffa0"]

__all__ = [
    "ACCENT", "ACCENT_DIM", "ACCENT_DEEP", "BG", "PANEL", "PANEL_HI", "BORDER",
    "BORDER_HI", "TEXT", "TEXT_SOFT", "TEXT_SUB", "MAROON", "MAROON_HI",
    "OK", "WARN", "ERROR", "INFO", "CATEGORY_COLORS", "HABIT_PALETTE",
    "MOOD_COLORS", "MOOD_GLYPHS", "MOOD_ASCII", "INTENSITY_COLORS",
    "category_color", "habit_color", "mood_color", "GREEN_RAMP",
]
