"""repo.py - MyDay data access API (the model layer the TUI calls).

A faithful port of the web app's FastAPI endpoints into plain, synchronous
Python functions returning dicts (same shapes the JSON API returned). No HTTP,
no async - screens/widgets call these directly.

Validation raises `ValidationError` (a ValueError) with a human message; the
UI catches it and shows a toast. Reads return dicts / lists of dicts; missing
single rows return a zero-value object (metrics/journal) or None where noted.

All writes go through db.immediate_txn. `day` is 'YYYY-MM-DD'; `*_min` are
0..1439 minutes from local midnight.
"""
from __future__ import annotations

import re
from datetime import datetime, timezone
from typing import Optional

from . import db as _db
from . import dates

_DAY_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")

VALID_MEAL_TYPES = ("breakfast", "lunch", "dinner", "snack")
VALID_INTENSITIES = ("low", "med", "high")

# Schedule categories (ids + labels are data; colors live in palette.py).
CATEGORIES = (
    {"id": "work",     "label": "Work"},
    {"id": "personal", "label": "Personal"},
    {"id": "health",   "label": "Health"},
    {"id": "focus",    "label": "Focus"},
    {"id": "break",    "label": "Break"},
    {"id": "errand",   "label": "Errand"},
    {"id": "other",    "label": "Other"},
)
CATEGORY_IDS = tuple(c["id"] for c in CATEGORIES)


class ValidationError(ValueError):
    """Raised for bad user input; message is safe to show in the UI."""


class NotFound(LookupError):
    """Raised when an id/day target does not exist."""


# --------------------------------------------------------------------------- #
# helpers
# --------------------------------------------------------------------------- #
def _utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _today() -> str:
    return dates.today()


def _need_day(day: str, label: str = "day") -> None:
    if not isinstance(day, str) or not _DAY_RE.match(day) or not dates.is_valid(day):
        raise ValidationError(f"{label} must be a real YYYY-MM-DD date")


def _range(day: Optional[str], start: Optional[str], end: Optional[str]):
    if day:
        _need_day(day)
        return day, day
    if start and end:
        _need_day(start, "start")
        _need_day(end, "end")
        return start, end
    t = _today()
    return t, t


def _rows(rs) -> list[dict]:
    return [dict(r) for r in rs]


def _int_or_none(val, label):
    if val is None or val == "":
        return None
    try:
        return int(val)
    except (TypeError, ValueError):
        raise ValidationError(f"{label} must be an integer")


def _float_or_none(val, label):
    if val is None or val == "":
        return None
    try:
        return float(val)
    except (TypeError, ValueError):
        raise ValidationError(f"{label} must be a number")


def init() -> None:
    """Create tables (idempotent) and seed starter habits. Call once at boot."""
    _db.init_db()
    from . import seed as _seed
    _seed.seed()


# --------------------------------------------------------------------------- #
# schedule blocks
# --------------------------------------------------------------------------- #
def _validate_times(start_min: int, end_min: int) -> None:
    if not (0 <= start_min <= 1439):
        raise ValidationError("start time must be within the day")
    if not (0 <= end_min <= 1439):
        raise ValidationError("end time must be within the day")
    if end_min <= start_min:
        raise ValidationError("end time must be after start time")


def list_schedule(day=None, start=None, end=None) -> list[dict]:
    s, e = _range(day, start, end)
    conn = _db.get_conn()
    try:
        return _rows(conn.execute(
            "SELECT * FROM schedule_blocks WHERE day>=? AND day<=? "
            "ORDER BY day, start_min, id", (s, e)))
    finally:
        conn.close()


def get_block(block_id: int) -> Optional[dict]:
    conn = _db.get_conn()
    try:
        r = conn.execute("SELECT * FROM schedule_blocks WHERE id=?", (block_id,)).fetchone()
        return dict(r) if r else None
    finally:
        conn.close()


def create_schedule(day, start_min, end_min, title, category="other",
                    note="", color="") -> dict:
    _need_day(day)
    if start_min is None or end_min is None:
        raise ValidationError("start and end time are required")
    start_min = _int_or_none(start_min, "start time")
    end_min = _int_or_none(end_min, "end time")
    _validate_times(start_min, end_min)
    if not str(title).strip():
        raise ValidationError("title is required")
    if category not in CATEGORY_IDS:
        category = "other"
    ts = _utc_now()
    conn = _db.get_conn()
    try:
        with _db.immediate_txn(conn):
            cur = conn.execute(
                "INSERT INTO schedule_blocks (day,start_min,end_min,title,category,note,color,created_at)"
                " VALUES (?,?,?,?,?,?,?,?)",
                (day, start_min, end_min, title, category, note, color, ts))
            r = conn.execute("SELECT * FROM schedule_blocks WHERE id=?", (cur.lastrowid,)).fetchone()
        return dict(r)
    finally:
        conn.close()


def update_schedule(block_id: int, **fields) -> dict:
    conn = _db.get_conn()
    try:
        ex = conn.execute("SELECT * FROM schedule_blocks WHERE id=?", (block_id,)).fetchone()
        if not ex:
            raise NotFound("schedule block not found")
        ex = dict(ex)
        day = fields.get("day", ex["day"])
        start_min = _int_or_none(fields.get("start_min", ex["start_min"]), "start time")
        end_min = _int_or_none(fields.get("end_min", ex["end_min"]), "end time")
        title = fields.get("title", ex["title"])
        category = fields.get("category", ex["category"])
        note = fields.get("note", ex["note"])
        color = fields.get("color", ex["color"])
        _need_day(day)
        _validate_times(start_min, end_min)
        if not str(title).strip():
            raise ValidationError("title is required")
        if category not in CATEGORY_IDS:
            category = "other"
        with _db.immediate_txn(conn):
            conn.execute(
                "UPDATE schedule_blocks SET day=?,start_min=?,end_min=?,title=?,"
                "category=?,note=?,color=? WHERE id=?",
                (day, start_min, end_min, title, category, note, color, block_id))
            r = conn.execute("SELECT * FROM schedule_blocks WHERE id=?", (block_id,)).fetchone()
        return dict(r)
    finally:
        conn.close()


def delete_schedule(block_id: int) -> None:
    conn = _db.get_conn()
    try:
        if not conn.execute("SELECT id FROM schedule_blocks WHERE id=?", (block_id,)).fetchone():
            raise NotFound("schedule block not found")
        with _db.immediate_txn(conn):
            conn.execute("DELETE FROM schedule_blocks WHERE id=?", (block_id,))
    finally:
        conn.close()


# --------------------------------------------------------------------------- #
# todos
# --------------------------------------------------------------------------- #
def list_todos(day=None, start=None, end=None) -> list[dict]:
    s, e = _range(day, start, end)
    conn = _db.get_conn()
    try:
        return _rows(conn.execute(
            "SELECT * FROM todos WHERE day>=? AND day<=? ORDER BY sort_order, id", (s, e)))
    finally:
        conn.close()


def create_todo(day, text) -> dict:
    _need_day(day)
    if not str(text).strip():
        raise ValidationError("todo text is required")
    ts = _utc_now()
    conn = _db.get_conn()
    try:
        with _db.immediate_txn(conn):
            # append to the end of the day's list
            nxt = conn.execute(
                "SELECT COALESCE(MAX(sort_order)+1, 0) AS n FROM todos WHERE day=?",
                (day,)).fetchone()["n"]
            cur = conn.execute(
                "INSERT INTO todos (day,text,done,sort_order,created_at) VALUES (?,?,0,?,?)",
                (day, text, nxt, ts))
            r = conn.execute("SELECT * FROM todos WHERE id=?", (cur.lastrowid,)).fetchone()
        return dict(r)
    finally:
        conn.close()


def update_todo(todo_id: int, **fields) -> dict:
    conn = _db.get_conn()
    try:
        ex = conn.execute("SELECT * FROM todos WHERE id=?", (todo_id,)).fetchone()
        if not ex:
            raise NotFound("todo not found")
        ex = dict(ex)
        text = fields.get("text", ex["text"])
        done = int(fields["done"]) if "done" in fields else ex["done"]
        sort_order = int(fields["sort_order"]) if "sort_order" in fields else ex["sort_order"]
        with _db.immediate_txn(conn):
            conn.execute("UPDATE todos SET text=?, done=?, sort_order=? WHERE id=?",
                         (text, done, sort_order, todo_id))
            r = conn.execute("SELECT * FROM todos WHERE id=?", (todo_id,)).fetchone()
        return dict(r)
    finally:
        conn.close()


def toggle_todo(todo_id: int) -> dict:
    cur = None
    conn = _db.get_conn()
    try:
        r = conn.execute("SELECT done FROM todos WHERE id=?", (todo_id,)).fetchone()
        if not r:
            raise NotFound("todo not found")
        cur = r["done"]
    finally:
        conn.close()
    return update_todo(todo_id, done=0 if cur else 1)


def delete_todo(todo_id: int) -> None:
    conn = _db.get_conn()
    try:
        if not conn.execute("SELECT id FROM todos WHERE id=?", (todo_id,)).fetchone():
            raise NotFound("todo not found")
        with _db.immediate_txn(conn):
            conn.execute("DELETE FROM todos WHERE id=?", (todo_id,))
    finally:
        conn.close()


def reorder_todo(todo_id: int, direction: int) -> None:
    """Swap a todo with its neighbour within the same day (direction -1/+1)."""
    conn = _db.get_conn()
    try:
        me = conn.execute("SELECT * FROM todos WHERE id=?", (todo_id,)).fetchone()
        if not me:
            raise NotFound("todo not found")
        me = dict(me)
        op = "<" if direction < 0 else ">"
        order = "DESC" if direction < 0 else "ASC"
        nb = conn.execute(
            f"SELECT * FROM todos WHERE day=? AND (sort_order,id) {op} (?,?) "
            f"ORDER BY sort_order {order}, id {order} LIMIT 1",
            (me["day"], me["sort_order"], me["id"])).fetchone()
        if not nb:
            return
        nb = dict(nb)
        with _db.immediate_txn(conn):
            conn.execute("UPDATE todos SET sort_order=? WHERE id=?", (nb["sort_order"], me["id"]))
            conn.execute("UPDATE todos SET sort_order=? WHERE id=?", (me["sort_order"], nb["id"]))
    finally:
        conn.close()


# --------------------------------------------------------------------------- #
# meals
# --------------------------------------------------------------------------- #
def list_meals(day=None, start=None, end=None) -> list[dict]:
    s, e = _range(day, start, end)
    conn = _db.get_conn()
    try:
        return _rows(conn.execute(
            "SELECT * FROM meals WHERE day>=? AND day<=? "
            "ORDER BY day, CASE WHEN time_min IS NULL THEN 1 ELSE 0 END, time_min, id", (s, e)))
    finally:
        conn.close()


def create_meal(day, meal_type, name, calories=None, time_min=None, note="") -> dict:
    _need_day(day)
    if meal_type not in VALID_MEAL_TYPES:
        raise ValidationError(f"meal type must be one of {', '.join(VALID_MEAL_TYPES)}")
    if not str(name).strip():
        raise ValidationError("meal name is required")
    calories = _int_or_none(calories, "calories")
    time_min = _int_or_none(time_min, "time")
    if time_min is not None and not (0 <= time_min <= 1439):
        raise ValidationError("meal time must be within the day")
    ts = _utc_now()
    conn = _db.get_conn()
    try:
        with _db.immediate_txn(conn):
            cur = conn.execute(
                "INSERT INTO meals (day,meal_type,name,calories,time_min,note,created_at)"
                " VALUES (?,?,?,?,?,?,?)", (day, meal_type, name, calories, time_min, note, ts))
            r = conn.execute("SELECT * FROM meals WHERE id=?", (cur.lastrowid,)).fetchone()
        return dict(r)
    finally:
        conn.close()


def update_meal(meal_id: int, **fields) -> dict:
    conn = _db.get_conn()
    try:
        ex = conn.execute("SELECT * FROM meals WHERE id=?", (meal_id,)).fetchone()
        if not ex:
            raise NotFound("meal not found")
        ex = dict(ex)
        day = fields.get("day", ex["day"])
        meal_type = fields.get("meal_type", ex["meal_type"])
        name = fields.get("name", ex["name"])
        note = fields.get("note", ex["note"])
        _need_day(day)
        if meal_type not in VALID_MEAL_TYPES:
            raise ValidationError(f"meal type must be one of {', '.join(VALID_MEAL_TYPES)}")
        calories = _int_or_none(fields["calories"], "calories") if "calories" in fields else ex["calories"]
        time_min = _int_or_none(fields["time_min"], "time") if "time_min" in fields else ex["time_min"]
        if time_min is not None and not (0 <= time_min <= 1439):
            raise ValidationError("meal time must be within the day")
        with _db.immediate_txn(conn):
            conn.execute(
                "UPDATE meals SET day=?,meal_type=?,name=?,calories=?,time_min=?,note=? WHERE id=?",
                (day, meal_type, name, calories, time_min, note, meal_id))
            r = conn.execute("SELECT * FROM meals WHERE id=?", (meal_id,)).fetchone()
        return dict(r)
    finally:
        conn.close()


def delete_meal(meal_id: int) -> None:
    conn = _db.get_conn()
    try:
        if not conn.execute("SELECT id FROM meals WHERE id=?", (meal_id,)).fetchone():
            raise NotFound("meal not found")
        with _db.immediate_txn(conn):
            conn.execute("DELETE FROM meals WHERE id=?", (meal_id,))
    finally:
        conn.close()


# --------------------------------------------------------------------------- #
# workouts
# --------------------------------------------------------------------------- #
def _norm_intensity(val):
    if val in (None, ""):
        return None
    if val not in VALID_INTENSITIES:
        raise ValidationError(f"intensity must be one of {', '.join(VALID_INTENSITIES)}")
    return val


def list_workouts(day=None, start=None, end=None) -> list[dict]:
    s, e = _range(day, start, end)
    conn = _db.get_conn()
    try:
        return _rows(conn.execute(
            "SELECT * FROM workouts WHERE day>=? AND day<=? ORDER BY day, id", (s, e)))
    finally:
        conn.close()


def create_workout(day, activity, duration_min=None, intensity=None, note="") -> dict:
    _need_day(day)
    if not str(activity).strip():
        raise ValidationError("activity is required")
    duration_min = _int_or_none(duration_min, "duration")
    intensity = _norm_intensity(intensity)
    ts = _utc_now()
    conn = _db.get_conn()
    try:
        with _db.immediate_txn(conn):
            cur = conn.execute(
                "INSERT INTO workouts (day,activity,duration_min,intensity,note,created_at)"
                " VALUES (?,?,?,?,?,?)", (day, activity, duration_min, intensity, note, ts))
            r = conn.execute("SELECT * FROM workouts WHERE id=?", (cur.lastrowid,)).fetchone()
        return dict(r)
    finally:
        conn.close()


def update_workout(workout_id: int, **fields) -> dict:
    conn = _db.get_conn()
    try:
        ex = conn.execute("SELECT * FROM workouts WHERE id=?", (workout_id,)).fetchone()
        if not ex:
            raise NotFound("workout not found")
        ex = dict(ex)
        day = fields.get("day", ex["day"])
        activity = fields.get("activity", ex["activity"])
        note = fields.get("note", ex["note"])
        _need_day(day)
        duration_min = _int_or_none(fields["duration_min"], "duration") if "duration_min" in fields else ex["duration_min"]
        intensity = _norm_intensity(fields["intensity"]) if "intensity" in fields else ex["intensity"]
        with _db.immediate_txn(conn):
            conn.execute(
                "UPDATE workouts SET day=?,activity=?,duration_min=?,intensity=?,note=? WHERE id=?",
                (day, activity, duration_min, intensity, note, workout_id))
            r = conn.execute("SELECT * FROM workouts WHERE id=?", (workout_id,)).fetchone()
        return dict(r)
    finally:
        conn.close()


def delete_workout(workout_id: int) -> None:
    conn = _db.get_conn()
    try:
        if not conn.execute("SELECT id FROM workouts WHERE id=?", (workout_id,)).fetchone():
            raise NotFound("workout not found")
        with _db.immediate_txn(conn):
            conn.execute("DELETE FROM workouts WHERE id=?", (workout_id,))
    finally:
        conn.close()


# --------------------------------------------------------------------------- #
# day metrics (water / sleep / weight / mood) - upsert, one row per day
# --------------------------------------------------------------------------- #
def _metrics_obj(r, day) -> dict:
    if r is None:
        return {"day": day, "water_cups": 0, "sleep_hours": None,
                "weight": None, "mood": None, "updated_at": None}
    r = dict(r)
    return {"day": r["day"], "water_cups": r["water_cups"] or 0,
            "sleep_hours": r["sleep_hours"], "weight": r["weight"],
            "mood": r["mood"], "updated_at": r["updated_at"]}


def get_metrics(day) -> dict:
    _need_day(day)
    conn = _db.get_conn()
    try:
        r = conn.execute("SELECT * FROM day_metrics WHERE day=?", (day,)).fetchone()
        return _metrics_obj(r, day)
    finally:
        conn.close()


def list_metrics(start, end) -> list[dict]:
    _need_day(start, "start")
    _need_day(end, "end")
    conn = _db.get_conn()
    try:
        rows = conn.execute("SELECT * FROM day_metrics WHERE day>=? AND day<=? ORDER BY day",
                            (start, end)).fetchall()
        return [_metrics_obj(r, r["day"]) for r in rows]
    finally:
        conn.close()


def set_metrics(day, **fields) -> dict:
    """Partial upsert: only keys present in `fields` are written."""
    _need_day(day)
    mood = fields.get("mood")
    if "mood" in fields and mood is not None:
        mood = _int_or_none(mood, "mood")
        if mood is not None and not (1 <= mood <= 5):
            raise ValidationError("mood must be 1..5")
    sleep = _float_or_none(fields.get("sleep_hours"), "sleep") if "sleep_hours" in fields else "___"
    weight = _float_or_none(fields.get("weight"), "weight") if "weight" in fields else "___"
    water = _int_or_none(fields.get("water_cups"), "water") if "water_cups" in fields else "___"
    ts = _utc_now()
    conn = _db.get_conn()
    try:
        with _db.immediate_txn(conn):
            ex = conn.execute("SELECT * FROM day_metrics WHERE day=?", (day,)).fetchone()
            if ex:
                ex = dict(ex)
                nw = water if water != "___" else ex["water_cups"]
                ns = sleep if sleep != "___" else ex["sleep_hours"]
                ng = weight if weight != "___" else ex["weight"]
                nm = mood if "mood" in fields else ex["mood"]
                conn.execute(
                    "UPDATE day_metrics SET water_cups=?,sleep_hours=?,weight=?,mood=?,updated_at=? WHERE day=?",
                    (nw if nw is not None else 0, ns, ng, nm, ts, day))
            else:
                conn.execute(
                    "INSERT INTO day_metrics (day,water_cups,sleep_hours,weight,mood,updated_at) VALUES (?,?,?,?,?,?)",
                    (day, (water if water not in ("___", None) else 0),
                     sleep if sleep != "___" else None,
                     weight if weight != "___" else None,
                     mood if "mood" in fields else None, ts))
            r = conn.execute("SELECT * FROM day_metrics WHERE day=?", (day,)).fetchone()
        return _metrics_obj(r, day)
    finally:
        conn.close()


def add_water(day, delta: int = 1) -> dict:
    cur = get_metrics(day)["water_cups"]
    return set_metrics(day, water_cups=max(0, cur + delta))


# --------------------------------------------------------------------------- #
# habits + habit logs
# --------------------------------------------------------------------------- #
def list_habits(include_inactive: bool = False) -> list[dict]:
    conn = _db.get_conn()
    try:
        if include_inactive:
            rows = conn.execute("SELECT * FROM habits ORDER BY sort_order, id").fetchall()
        else:
            rows = conn.execute("SELECT * FROM habits WHERE active=1 ORDER BY sort_order, id").fetchall()
        return _rows(rows)
    finally:
        conn.close()


def create_habit(name, color="") -> dict:
    if not str(name).strip():
        raise ValidationError("habit name is required")
    ts = _utc_now()
    conn = _db.get_conn()
    try:
        with _db.immediate_txn(conn):
            nxt = conn.execute("SELECT COALESCE(MAX(sort_order)+1,0) AS n FROM habits").fetchone()["n"]
            cur = conn.execute(
                "INSERT INTO habits (name,color,active,sort_order,created_at) VALUES (?,?,1,?,?)",
                (name, color, nxt, ts))
            r = conn.execute("SELECT * FROM habits WHERE id=?", (cur.lastrowid,)).fetchone()
        return dict(r)
    finally:
        conn.close()


def update_habit(habit_id: int, **fields) -> dict:
    conn = _db.get_conn()
    try:
        ex = conn.execute("SELECT * FROM habits WHERE id=?", (habit_id,)).fetchone()
        if not ex:
            raise NotFound("habit not found")
        ex = dict(ex)
        name = fields.get("name", ex["name"])
        color = fields.get("color", ex["color"])
        active = int(fields["active"]) if "active" in fields else ex["active"]
        sort_order = int(fields["sort_order"]) if "sort_order" in fields else ex["sort_order"]
        with _db.immediate_txn(conn):
            conn.execute("UPDATE habits SET name=?,color=?,active=?,sort_order=? WHERE id=?",
                         (name, color, active, sort_order, habit_id))
            r = conn.execute("SELECT * FROM habits WHERE id=?", (habit_id,)).fetchone()
        return dict(r)
    finally:
        conn.close()


def delete_habit(habit_id: int) -> None:
    conn = _db.get_conn()
    try:
        if not conn.execute("SELECT id FROM habits WHERE id=?", (habit_id,)).fetchone():
            raise NotFound("habit not found")
        with _db.immediate_txn(conn):
            conn.execute("DELETE FROM habit_logs WHERE habit_id=?", (habit_id,))
            conn.execute("DELETE FROM habits WHERE id=?", (habit_id,))
    finally:
        conn.close()


def list_habit_logs(start=None, end=None, day=None) -> list[dict]:
    s, e = _range(day, start, end)
    conn = _db.get_conn()
    try:
        rows = conn.execute(
            "SELECT habit_id, day, done FROM habit_logs WHERE day>=? AND day<=? ORDER BY day, habit_id",
            (s, e)).fetchall()
        return [{"habit_id": r["habit_id"], "day": r["day"], "done": r["done"]} for r in rows]
    finally:
        conn.close()


def set_habit_log(habit_id: int, day: str, done: int = 1) -> dict:
    _need_day(day)
    habit_id = int(habit_id)
    done = 1 if int(done) else 0
    conn = _db.get_conn()
    try:
        if not conn.execute("SELECT id FROM habits WHERE id=?", (habit_id,)).fetchone():
            raise NotFound("habit not found")
        with _db.immediate_txn(conn):
            conn.execute(
                "INSERT INTO habit_logs (habit_id,day,done) VALUES (?,?,?) "
                "ON CONFLICT(habit_id,day) DO UPDATE SET done=excluded.done",
                (habit_id, day, done))
        return {"habit_id": habit_id, "day": day, "done": done}
    finally:
        conn.close()


def toggle_habit(habit_id: int, day: str) -> dict:
    logs = {(l["habit_id"], l["day"]): l["done"] for l in list_habit_logs(day=day)}
    cur = logs.get((int(habit_id), day), 0)
    return set_habit_log(habit_id, day, 0 if cur else 1)


def habit_streak(habit_id: int, day: str) -> int:
    """Count consecutive done days ending at (and including) `day`."""
    conn = _db.get_conn()
    try:
        rows = conn.execute(
            "SELECT day FROM habit_logs WHERE habit_id=? AND done=1 AND day<=? ORDER BY day DESC",
            (int(habit_id), day)).fetchall()
    finally:
        conn.close()
    done_days = {r["day"] for r in rows}
    streak = 0
    cur = day
    while cur in done_days:
        streak += 1
        cur = dates.add(cur, -1)
    return streak


# --------------------------------------------------------------------------- #
# journal (one entry per day, upsert)
# --------------------------------------------------------------------------- #
def get_journal(day) -> dict:
    _need_day(day)
    conn = _db.get_conn()
    try:
        r = conn.execute("SELECT * FROM journal WHERE day=?", (day,)).fetchone()
        if not r:
            return {"day": day, "content": "", "updated_at": None}
        r = dict(r)
        return {"day": r["day"], "content": r["content"], "updated_at": r["updated_at"]}
    finally:
        conn.close()


def set_journal(day, content) -> dict:
    _need_day(day)
    ts = _utc_now()
    conn = _db.get_conn()
    try:
        with _db.immediate_txn(conn):
            conn.execute(
                "INSERT INTO journal (day,content,updated_at) VALUES (?,?,?) "
                "ON CONFLICT(day) DO UPDATE SET content=excluded.content, updated_at=excluded.updated_at",
                (day, content, ts))
        return {"day": day, "content": content, "updated_at": ts}
    finally:
        conn.close()


# --------------------------------------------------------------------------- #
# summary (powers Week/Month/Year overviews) - faithful port
# --------------------------------------------------------------------------- #
def summary(start, end) -> list[dict]:
    _need_day(start, "start")
    _need_day(end, "end")
    conn = _db.get_conn()
    try:
        habits_total = conn.execute("SELECT COUNT(*) AS n FROM habits WHERE active=1").fetchone()["n"]

        sched = {r["day"]: (r["blocks"], r["scheduled_min"]) for r in conn.execute(
            "SELECT day, COUNT(*) blocks, COALESCE(SUM(end_min-start_min),0) scheduled_min "
            "FROM schedule_blocks WHERE day>=? AND day<=? GROUP BY day", (start, end))}
        todo = {r["day"]: (r["tt"], r["td"] or 0) for r in conn.execute(
            "SELECT day, COUNT(*) tt, SUM(done) td FROM todos WHERE day>=? AND day<=? GROUP BY day",
            (start, end))}
        meal = {r["day"]: (r["m"], r["cal"]) for r in conn.execute(
            "SELECT day, COUNT(*) m, COALESCE(SUM(COALESCE(calories,0)),0) cal "
            "FROM meals WHERE day>=? AND day<=? GROUP BY day", (start, end))}
        wk = {r["day"]: (r["w"], r["wm"]) for r in conn.execute(
            "SELECT day, COUNT(*) w, COALESCE(SUM(COALESCE(duration_min,0)),0) wm "
            "FROM workouts WHERE day>=? AND day<=? GROUP BY day", (start, end))}
        met = {r["day"]: dict(r) for r in conn.execute(
            "SELECT * FROM day_metrics WHERE day>=? AND day<=?", (start, end))}
        hlog = {r["day"]: (r["hd"] or 0) for r in conn.execute(
            "SELECT day, SUM(done) hd FROM habit_logs WHERE day>=? AND day<=? GROUP BY day",
            (start, end))}
        jset = {r["day"] for r in conn.execute(
            "SELECT day FROM journal WHERE day>=? AND day<=? AND content!=''", (start, end))}
    finally:
        conn.close()

    all_days = set(sched) | set(todo) | set(meal) | set(wk) | set(met) | set(hlog) | jset
    out = []
    for d in sorted(all_days):
        b, sm = sched.get(d, (0, 0))
        tt, td = todo.get(d, (0, 0))
        m, cal = meal.get(d, (0, 0))
        w, wm = wk.get(d, (0, 0))
        mx = met.get(d, {})
        out.append({
            "day": d, "blocks": b, "scheduled_min": sm,
            "todos_total": tt, "todos_done": td,
            "meals": m, "calories": cal,
            "workouts": w, "workout_min": wm,
            "water_cups": mx.get("water_cups", 0),
            "sleep_hours": mx.get("sleep_hours"), "weight": mx.get("weight"),
            "mood": mx.get("mood"),
            "habits_total": habits_total, "habits_done": hlog.get(d, 0),
            "journal": d in jset,
        })
    return out


# --------------------------------------------------------------------------- #
# dashboard helpers (Today / Plan screens)
# --------------------------------------------------------------------------- #
def current_and_next_block(day: str, now_minutes: int):
    """Return (current_block_or_None, next_block_or_None) for `day`.

    current = block whose [start,end) contains now; next = earliest block
    that starts at/after now."""
    blocks = list_schedule(day=day)
    current = None
    nxt = None
    for b in blocks:
        if b["start_min"] <= now_minutes < b["end_min"] and current is None:
            current = b
        if b["start_min"] >= now_minutes and nxt is None:
            nxt = b
    return current, nxt


def upcoming(from_day: str, days: int = 14) -> list[dict]:
    """A merged, date-sorted feed of future schedule blocks and open todos in
    [from_day, from_day+days]. Each item: {kind:'block'|'todo', day, ...row}."""
    _need_day(from_day)
    end = dates.add(from_day, max(0, days))
    items: list[dict] = []
    for b in list_schedule(start=from_day, end=end):
        items.append({"kind": "block", **b})
    for t in list_todos(start=from_day, end=end):
        if not t["done"]:
            items.append({"kind": "todo", **t})
    items.sort(key=lambda x: (x["day"], x.get("start_min", 24 * 60), x.get("id", 0)))
    return items


def day_counts(day: str) -> dict:
    """Small rollup for status widgets: todos open/total + blocks + habits."""
    todos = list_todos(day=day)
    blocks = list_schedule(day=day)
    habits = list_habits()
    logs = {l["habit_id"]: l["done"] for l in list_habit_logs(day=day)}
    return {
        "todos_total": len(todos),
        "todos_done": sum(1 for t in todos if t["done"]),
        "todos_open": sum(1 for t in todos if not t["done"]),
        "blocks": len(blocks),
        "habits_total": len(habits),
        "habits_done": sum(1 for h in habits if logs.get(h["id"], 0)),
    }
