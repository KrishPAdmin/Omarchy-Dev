# krishpad

A terminal daily planner plus an Omarchy theming, screensaver and touch kit,
all styled to match **krishadmin.com** (neon green `#20fd14` on pure black).

krishpad is a self-contained bundle. Copy it to your Omarchy (Arch/Hyprland)
laptop, run one installer, and you get **MyDay**, a fast keyboard-and-touch
friendly planner that lives in your terminal, with optional desktop theming to
match.

## Quickstart (3 steps)

1. **Copy** this whole folder to the laptop (see the docs for scp/USB/tar):
   ```bash
   scp -r krishpad krishadmin@LAPTOP:~/
   ```
2. **Install** (creates an isolated venv, adds a `myday` command):
   ```bash
   cd ~/krishpad
   ./install.sh
   ```
3. **Run** it:
   ```bash
   myday
   ```

That is it. To also apply the desktop theme, autostart and waybar module:

```bash
./install.sh --all
```

## What you get

MyDay planner (the `myday` command):

- Day / Week / Month / Year views, all keyboard-first and touch-friendly
- A **Today** dashboard with schedule blocks, todos, meals, workouts,
  water/sleep/weight/mood metrics, habits and a journal
- A compact always-on **widget** (`myday widget`) for a small terminal
- A one-line **status** (`myday status`) for waybar, tmux or scripts
- A pixel **screensaver** (`myday screensaver`) with idle and night-dark modes
- Local SQLite storage in `~/.local/share/myday/planner.db`. No server, no
  login, no network.

Omarchy extras (optional flags on `install.sh`):

- `--theme` the krishadmin Omarchy theme (colors + wallpaper)
- `--waybar` a waybar module wired to `myday status`
- `--autostart` launch the dashboard and widget on login
- `--screen-off-never` keep the display awake (kiosk / always-on)
- `--touch` Surface touchscreen setup (kernel-level, asks first)
- `--all` shorthand for theme + waybar + autostart

## Commands

| Command             | What it does                                  |
| ------------------- | --------------------------------------------- |
| `myday`             | Launch the planner on the Today view          |
| `myday week`        | Start on Week (also `day`, `month`, `year`, `plan`) |
| `myday widget`      | Compact always-on status widget               |
| `myday status`      | Print one line of status (for status bars)    |
| `myday screensaver` | Run the pixel screensaver standalone          |
| `myday --version`   | Print the version                             |

## Directory map

```
krishpad/
  install.sh         one-command installer (start here)
  uninstall.sh       clean removal (keeps your data unless --purge)
  bin/myday          portable launcher template (alternative to install)
  pyproject.toml     packaging metadata for the myday package
  requirements.txt   the single runtime dep: textual>=8,<9
  VERSION            1.0.0
  myday/             the planner (Python / Textual TUI)
  omarchy/           Omarchy theme, apply-theme.sh, wallpaper, waybar/
  scripts/           screen-off, Surface touch, autostart, doctor helpers
  docs/              guides (start with docs/INSTALL.md)
```

## What to read next

- **`docs/INSTALL.md`** - full install guide: every flag, manual fallback,
  copying the bundle to the laptop, updating, uninstalling, and troubleshooting.
- Other guides in **`docs/`** cover the planner, theming and the extras.
- Run **`scripts/doctor.sh`** any time for an environment health check.

## Requirements

- An Omarchy / Arch (Hyprland) laptop for the full experience. The planner
  itself runs on any Linux with **python 3.11+**; use `./install.sh --force`
  to install off Arch.
- One Python dependency, `textual` (8.x), installed into a private venv at
  `~/.local/share/myday/venv`. Nothing is installed system-wide.
